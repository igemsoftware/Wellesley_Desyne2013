﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HtmlAgilityPack;
using System.IO;
using System.Net;
using System.Text.RegularExpressions;
using System.Diagnostics;
using System.Windows.Media.Imaging;

namespace Eugenie.Pigeon
{
    class PigeonRunner
    {
        //using wget
        //from here: http://www.ehow.com/how_10054131_use-wget-windows.html
        //http://sourceforge.net/projects/gnuwin32/files/wget/1.11.4-1/wget-1.11.4-1-setup.exe/download?use_mirror=iweb&r=http%3A%2F%2Fsourceforge.net%2Fprojects%2Fgnuwin32%2Ffiles%2Fwget%2F1.11.4-1%2F&use_mirror=iweb


        //get cookie from response look for session id
        //set as cookie on next req


        private const string _PIGEONURL1 = @"http://cidar1.bu.edu:5801/pigeon1.php";
        private const string _PIGEONURL2 = @"http://cidar1.bu.edu:5801/pigeon.php";
        private const string _IMAGESTARTERURL = @"http://cidar1.bu.edu:5801/";
        private List<string> _pigeonURLSList = new List<string>();

        public PigeonRunner()
        {
            
        }

        public BitmapImage ManuallySetTheCookieMethod(string textFile)
        {   
            string result = "";
            WebRequest pigeon1WebRequest;
            WebRequest actualWebRequest;
            WebResponse cookieWebResponse;
            WebResponse pigeonImageWebResponse2;

            try
            {
                pigeon1WebRequest = WebRequest.Create(_PIGEONURL1); //going to pigeon1.php
                cookieWebResponse = pigeon1WebRequest.GetResponse(); //getting response checking for cookies
                string sessionID = cookieWebResponse.Headers.Get("Set-Cookie");

                //extract the goods 
                int start = sessionID.IndexOf("=");
                int stop = sessionID.IndexOf(";");                
                sessionID = sessionID.Substring(start, stop-start);
                //set up cookie for next request
                sessionID = "PHPSESSID" + sessionID;

                //set up proper request with sessionID
                actualWebRequest = WebRequest.Create(_PIGEONURL2);
                actualWebRequest.Method = "POST";
                actualWebRequest.Headers.Set("Cookie", sessionID);

                StreamReader readPigeonFile = new StreamReader(textFile);

                string toWrite = "desc=" + readPigeonFile.ReadToEnd();
                // Create POST data and convert it to a byte array.
                byte[] byteArray = Encoding.UTF8.GetBytes(toWrite);
                // Set the ContentType property of the WebRequest.
                actualWebRequest.ContentType = "application/x-www-form-urlencoded";
                // Set the ContentLength property of the WebRequest.
                actualWebRequest.ContentLength = byteArray.Length;
                // Get the request stream.
                Stream dataStream = actualWebRequest.GetRequestStream();
                // Write the data to the request stream.
                dataStream.Write(byteArray, 0, byteArray.Length);
                // Close the Stream object.
                dataStream.Close();
                
                
                // Send the data to the webserver
                pigeonImageWebResponse2 = actualWebRequest.GetResponse();
                // Get the response.               
                Stream streamResponse2 = pigeonImageWebResponse2.GetResponseStream();//return the data stream from the internet
                
                StreamReader sreader2 = new StreamReader(streamResponse2);//reads the data stream
                result = sreader2.ReadToEnd();//reads it to the end

                start = result.IndexOf("scratch");
               
                result = result.Substring(start);
                stop = result.IndexOf("alt");
                result = result.Substring(0,stop);
                //return result;
                return new BitmapImage(new Uri(_IMAGESTARTERURL+result));

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return new BitmapImage();
            }
        }
        
    }
}
