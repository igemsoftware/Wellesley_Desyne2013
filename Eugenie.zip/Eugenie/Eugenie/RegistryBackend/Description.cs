﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace Eugenie
{
    public class Description
    {
        private List<bool> _assemCompat;
        private List<string> _assembIncomp10; //"index" 0
        private List<string> _assembIncomp12; //"index" 1
        private List<string> _assembIncomp21; //"index" 2
        private List<string> _assembIncomp23; //"index" 3
        private List<string> _assembIncomp25; //"index" 4
        private List<string> _chassis;

        //For custom parts only
        private String _desc;

        //redone variables based on xml files from Registry API
        private String direction;
        private String chassis;
        private String function;
        private String descriptionName;
        #region Properties
        public String Desc
        {
            get { return _desc; }
            set { _desc = value; }
        }

        public List<bool> AssemblyCompatibility
        {
            get { return _assemCompat; }
            set { _assemCompat = value; }
        }

        public List<string> AssemblyIncompatibiltiy10
        {
            get { return _assembIncomp10; }
            set { _assembIncomp10 = value; }
        }

        public List<string> AssemblyIncompatibiltiy12
        {
            get { return _assembIncomp12; }
            set { _assembIncomp12 = value; }
        }

        public List<string> AssemblyIncompatibiltiy21
        {
            get { return _assembIncomp21; }
            set { _assembIncomp21 = value; }
        }

        public List<string> AssemblyIncompatibiltiy23
        {
            get { return _assembIncomp23; }
            set { _assembIncomp23 = value; }
        }

        public List<string> AssemblyIncompatibiltiy25
        {
            get { return _assembIncomp25; }
            set { _assembIncomp25 = value; }
        }

        public string Direction
        {
            get { return direction; }
            set { direction = value; }
        }

        public string Chassis
        {
            get { return chassis; }
            set { chassis = value; }
        }

        public string Function
        {
            get {return function; }
            set { function = value; }
            }

        #endregion

        public Description()
        {
            _assemCompat = new List<bool>();
            _assembIncomp10 = new List<string>();
            _assembIncomp12 = new List<string>();
            _assembIncomp21 = new List<string>();
            _assembIncomp23 = new List<string>();
            _assembIncomp25 = new List<string>();
            _chassis = new List<string>();

        }

        /// <summary>
        /// 6/22/2012
        /// Links to Parts Registry pages and parses source code in order to obtain description information 
        /// for a particular part
        /// @ Nicole Francisco & Veronica Lin
        /// </summary>
        /// <param name="sourceCode">Source code of a particular page</param>

        public Description(String sourceCode)
        {
            _assemCompat = new List<bool>();
            _assembIncomp10 = new List<string>();
            _assembIncomp12 = new List<string>();
            _assembIncomp21 = new List<string>();
            _assembIncomp23 = new List<string>();
            _assembIncomp25 = new List<string>();
            _chassis = new List<string>();

            int index = 0;
            string sc = sourceCode;
            //string assembCompInd = "Assembly Compatibility:";
            //string assembRed = "<LI class='boxctrl box_red'>";
            //string compatMsg = ">COMPATIBLE WITH RFC[";
            //string categoriesBox = "<categories>";
            string chassis = "No information";
            string direction = "No information";
            string function = "No information";
            string tempString = sourceCode;

            if (sc.Contains("<direction>"))
            {
                index = sc.IndexOf("<direction>");
                sc = sc.Substring(index);
                direction = sc.Substring(0, sc.IndexOf("</direction>"));
        
            }

            if (sc.Contains("/chassis/"))
            {
                index = sc.IndexOf("/chassis/");
                sc = sc.Substring(index);
                chassis = sc.Substring(0, sc.IndexOf("</category>"));
            }

            if (sc.Contains("/function/"))
            {
                index = sc.IndexOf("/function/");
                sc = sc.Substring(index);
                function = sc.Substring(0, sc.IndexOf("</category>"));
            }

        }
    }
}
