﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.IO;


namespace Eugenie
{
    public class BasicInfo
    {
        private string _sbolImg;
        private string _availability;
        private string _usefulness;
        private string _sequence;
        private int _length;
        private string _twins;
        private string _descriptionName;
        private string _direction;
        private string _function;
        private string _chassis;
        private string _partType;
        private string _partAuthor;

        #region Properties
        public string SbolImg
        {
            get{ return _sbolImg;}
            set{ _sbolImg = value;}
        }

        public string Availability
        {
            get { return _availability; }
            set { _availability = value; }
        }

        public string Usefulness
        {
            get { return _usefulness; }
            set { _usefulness = value; }
        }

        public string Sequence
        {
            get { return _sequence; }
            set { _sequence = value; }
        }

        public int Length
        {
            get { return _length; }
            set { _length = value; }
        }

        public string DescriptionName
        {
            get { return _descriptionName; }
            set { _descriptionName = value; }
        }

        public string Direction
        {
            get { return _direction; }
            set { _direction = value; }
        }

        public string Function
        {
            get { return _function; }
            set { _function = value; }
        }

        public string Chassis
        {
            get { return _chassis; }
            set { _chassis = value; }
        }

        public string PartType
        {
            get { return _partType; }
            set { _partType = value; }
        }

        public string PartAuthor
        {
            get { return _partAuthor; }
            set { _partAuthor = value; }
        }

        public string Twins
        {
            get { return _twins; }
            set { _twins = value; }
        }






        #endregion

        //for generic parts
        public BasicInfo()
        {
            _sbolImg = "";
            _availability = "";
            _usefulness = "";
            _sequence = "";
            _length = 0;
            _twins = "";
            _descriptionName = "Add description if desired";
            _direction = "forward";
            _chassis = "";
            _function = "";
            _partType = "";
            _partAuthor = "";
        }

        public BasicInfo(String sourceCode, String type, String name)
        {
            _sbolImg = "No information";
            _availability = "No information";
            _usefulness = "No information";
            _sequence = "No information";
            _length = 0;
            _twins = "No information";
            _descriptionName = "No information";
            _direction = "No information";
            _chassis = "No information";
            _function = "No information";
            _partType = "No information";
            _partAuthor = "No information";
            int index = 0;
            string sc = sourceCode;

            if (sc.Contains("<part_short_desc>"))
            {
                index = sc.IndexOf("<part_short_desc>");
                sc = sc.Substring(index);
                _descriptionName = sc.Substring(0, sc.IndexOf("</part_short_desc>"));
                _descriptionName = cleanUp(_descriptionName);
                
            }

                if (sc.Contains("<part_type>"))
            {
                index = sc.IndexOf("<part_type>");
                sc = sc.Substring(index);
                _partType = sc.Substring(0, sc.IndexOf("</part_type"));
                
            }

            if (sc.Contains("<sample_status>"))
            {
                index = sc.IndexOf("<sample_status>");
                sc = sc.Substring(index);
                _availability = sc.Substring(0, sc.IndexOf("</sample_status>"));
                _availability = cleanUp(_availability);
            }

            if (sc.Contains("<part_results>"))
            {
                index = sc.IndexOf("<part_results>");
                sc = sc.Substring(index);
                _usefulness = sc.Substring(0, sc.IndexOf("</part_results>"));
                _usefulness = cleanUp(_usefulness);
            }

                if (sc.Contains("<part_author>"))
            {
                index = sc.IndexOf("<part_author>");
                sc = sc.Substring(index);
                _partAuthor = sc.Substring(0, sc.IndexOf("</part_author>"));
                _partAuthor = cleanUp(_partAuthor);
              
                
            }
                if (sc.Contains("<seq_data>"))
                {
                    index = sc.IndexOf("<seq_data>");
                    sc = sc.Substring(index);
                    _sequence = sc.Substring(0, sc.IndexOf("</seq_data>"));
                    _sequence = cleanUp(_sequence);
                    _length = _sequence.Length;
                    
                
                }


                if (sc.Contains("/direction/"))
                {
                    index = sc.IndexOf("//direction/");
                    sc = sc.Substring(index);
                    _direction = sc.Substring(0, sc.IndexOf("</category>"));
                    string[] SplitLine = _direction.Split('/');
                    _direction = SplitLine[3];
                }

            if (sc.Contains("/chassis/"))
            {
                index = sc.IndexOf("/chassis/");
                sc = sc.Substring(index);
                _chassis = sc.Substring(0, sc.IndexOf("</category>"));
                string[] SplitLine = _chassis.Split('/');
                _chassis = SplitLine[2] + "," + SplitLine[3];
            }

           

      


            if (sc.Contains("<twins>"))
            {
                index = sc.IndexOf("<twins>");
                sc = sc.Substring(index);
                _twins = sc.Substring(0, sc.IndexOf("</twins>"));
                string[] stringSeparators = new string[] { "<twin>", "</twin>", "<twins>" };
                string[] result = _twins.Split(stringSeparators,
                          StringSplitOptions.None);
                _twins = "";
                for (int i = 0; i < result.Length; i++)
                {
                    _twins = _twins + result[i];
                }
            
            }
         

            # region HTML WebRequest (Crawler goes into Designs Page for each part)

            //Go to part design page in Parts Registry
            // used to build entire input
            StringBuilder sb = new StringBuilder();

            // used on each read operation
            byte[] buf = new byte[8192];

            // prepare the web page we will be asking for
            HttpWebRequest request =
                (HttpWebRequest)WebRequest.Create("http://parts.igem.org/xml/part." + name + ":Design");
            // enters the part name in the link to produce the part design page

            // execute the request
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();

            // we will read data via the response stream
            Stream resStream = response.GetResponseStream();
            string tempString = null;
            int count = 0;
            do
            {
                // fill the buffer with data
                count = resStream.Read(buf, 0, buf.Length);

                // make sure we read some data
                if (count != 0)
                {
                    // translate from bytes to ASCII text
                    tempString = Encoding.ASCII.GetString(buf, 0, count);

                    // continue building the string
                    sb.Append(tempString);
                }
            } 
            while (count > 0);
             //finds sequence and length of the part (on the design page for each part)
            index = 0;
            String htmlText = sb.ToString();
            resStream.Close();
            response.Close();

        }

        public string cleanUp(string string1)
        {
            string[] SplitLine = string1.Split('>');
            string1 = SplitLine[1];
            return string1;
        }

            #endregion


        //returns all of the basic info parsed from each part page's source code
        public override string ToString()
        {
     
            return "{0}Image:" + _sbolImg  + "{0}Sequence:" + "{0}Description Name:" + DescriptionName + _sequence + "{0}Length:" + _length + "{0}Availability:" + _availability + "{0}Usefulness:"
                + _usefulness + "twins" + _twins ;
    
        }

    }
}
