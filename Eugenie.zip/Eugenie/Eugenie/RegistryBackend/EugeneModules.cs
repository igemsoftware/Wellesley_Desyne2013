﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;

namespace Eugenie
{
    class EugeneModules
    {
        public String _SelectedProm; //take in the selected promoters previously chosen
        public String _SelectedRBS; //take in seleted RBS
        public String _SelectedCDS; //take in selected CDS
        public String _SelectedTerm; //take in selected terminator

        private StreamReader sr;

        ProcessStartInfo properties;
        Process process;

        public EugeneModules()
        {
            //this.properties = new ProcessStartInfo("cmd.exe");  // run Command executable
            //this.properties.CreateNoWindow = true;              // suppress opening of a UI
            //this.properties.UseShellExecute = false;
            //this.properties.RedirectStandardError = true;       // redirect the input, output, and errors through the Surface UI
            //this.properties.RedirectStandardInput = true;
            //this.properties.RedirectStandardOutput = true;
            
            //this.process = new Process();
        }

        /// <summary>
        /// Generates and prints device permutations from all available parts.  
        /// Obeys set permutation rules.
        /// </summary>
        /// <param name="?"></param>
        /// <param name="?"></param>
        /// <returns> All available device permutations from the parts given. </returns>
       
        //public List<Level2Design> Permute(List<L1Module> ListModulesToPermute)
        //{
        //    List<Level2Design> Level2DesignsToReturn = new List<Level2Design>();

        //    //Get current working directory
        //    string file = Directory.GetCurrentDirectory();
        //    //change directory to EugeneFiles directory and read text file based on ListModulesToPermute count
        //    file = file.Substring(0,file.IndexOf("bin")) + @"Resources\EugeneFiles\permute" + ListModulesToPermute.Count + ".txt";     
        //    string text = "";
        //    StreamReader sr = new StreamReader(file);
        //    while (!sr.EndOfStream) //read to end of file
        //    {
        //        text = sr.ReadLine().ToString();
        //    }
        //    sr.Close();

        //    text = text.Replace("Device hybridDevice_", "");
        //    text = text.Replace("absDevice", "");
        //    //parsing text file and adding permutations to the L2 module
        //    string[] textminusparentheses = text.Split(new char[]{'(',')'});

        //    foreach (string numberasstringcomma in textminusparentheses)
        //    {                
        //        if (numberasstringcomma.Replace(" ", "").Length > 2) //go through each individual permutation
        //        {
        //            string[] permOrderArray = numberasstringcomma.Split(new char[] { ',' });
        //            //clean--> to do
        //            Level2Design tempLevel2Design = new Level2Design();
        //            foreach (string permNumberString in permOrderArray)
        //            {
        //                int index = Convert.ToInt32(permNumberString) -1;

        //                L1Module childToAdd = ListModulesToPermute.ElementAt(index).clone();

        //                tempLevel2Design.L2M.Children.Add(childToAdd);
        //            }
        //            Level2DesignsToReturn.Add(tempLevel2Design);
        //        }
                
        //    }

        //    return Level2DesignsToReturn;
        //}   
    
        


        }
    }    
//}
