﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Windows;
using System.Windows.Media.Imaging;
using Microsoft.Surface;
using Microsoft.Surface.Presentation;
using Microsoft.Surface.Presentation.Controls;
using Microsoft.Surface.Presentation.Input;
using System.Threading;
using System.Threading.Tasks;
using System.ComponentModel;
using System.IO;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Text;
using Eugenie.Model;
using System.Windows.Threading;




namespace Eugenie


{
    class RegistrySearch
    {
        private Reference _reference;
        private bool none; //is not the type of part we want
        private String filterText;
        private String _partTypeSelected; //What type is displayed
        private RegDataSheet myRegDS; //RegDataSheet containing information about this Part for searches
        private String[][] partsFilters; //Holds filter names (and other info not yet added)
        private String partCategory;
        private String name;
        private String direction;
        
        private Thread _currentSearch;
        private int storedFilterIndex = -1;
        private SurfaceWindow1 sw1;
        private string searchString;

        

       //string  searchString = SurfaceWindow1.searchtextbox.Text;
        public RegistrySearch(SurfaceWindow1 sw1, string searchString)
        {
            this.sw1 = sw1;
            this.searchString = searchString;

            //if (String.Equals(searchString,"Promoter",StringComparison.OrdinalIgnoreCase))
            //{
            //    searchString = "Promoter";
            //}
            //else if(String.Equals(searchString,"Terminator",StringComparison.OrdinalIgnoreCase))
            //{
            //    searchString = "Terminator";
            //} else if(String.Equals(searchString,"CDS",StringComparison.OrdinalIgnoreCase))
            //{
            //    searchString = "CDS";
            //}
            //else if (String.Equals(searchString, "RBS", StringComparison.OrdinalIgnoreCase))
            //{
            //    searchString = "RBS";
            //}

            //sw1.SearchResults.Clear();
            //Populate_results(sw1, searchString);
            ////change below line laterrrrr
            //Populate_results(sw1, searchString + "2");
            ////searchString = searchString + ".txt";
        }

        //Reads in Part Registry ID and type from text file
        private NotifiableCollection<Part> Populate_results(SurfaceWindow1 sw1, string FilePath) 
        {
            String path = Directory.GetCurrentDirectory();
                 path = path.Substring(0, path.Length - "bin\\debug\\".Length);
                 path += "\\"+FilePath + ".txt";

             NotifiableCollection<Part> results = sw1.SearchResults;
             NotifiableCollection<Part> r = new NotifiableCollection<Part>();
           
               // String[] files = Directory.GetFiles( @"C:\Users\MAC4\Documents\GitHub\Eugenie\Surface\Eugenie\Eugenie\", SearchOption.AllDirectories);
            
            //StreamReader reader = new StreamReader(System.IO.Path.Combine(Directory.GetCurrentDirectory(), @"C:\Users\MAC4\Documents\GitHub\Eugenie\Surface\Eugenie\Eugenie\"+FilePath+".txt"));
             try
             {
            StreamReader reader = new StreamReader(path);


            while (reader.EndOfStream != true)
           

                while (reader.EndOfStream != true)
                {
                    //Read in data
                    string ThisLine = reader.ReadLine();

                    if (!ThisLine.Substring(0).Equals("P"))
                    {
                        //Determine if reading custom Part data
                        //if (!ThisLine.Substring(0, 3).Equals("P |"))
                        //{
                        string[] SplitLine = ThisLine.Split(',');
                        //string CategorySplit = SplitLine[1].Trim();
                        //string CommonNameSplit = (SplitLine[2].Trim()).Replace("&amp;", "");


                        Part p = new Part(name, FilePath, partCategory, direction, true, true); //change bool values later
                        //only works when user types in promoter/terminator/rbs....change later for sure
                        p.Type = FilePath;
                        p.Name = SplitLine[0];
                        direction = SplitLine[1];
                        p.Direction = direction;
                   
                        //System.Windows.Application.Current.Dispatcher.Invoke(DispatcherPriority.Normal, (Action)delegate(){
                        //    results.Add(p);
                        //});
                        r.Add(p);
                        
                    }
                    //else
                    //{
                    //    //come back to searching for custom parts later-specificially myRegDS
                    ////    string[] SplitLine = ThisLine.Split('|');
                    ////    Part p = new Part(SplitLine[1].Trim(), true, true);
                    ////    p.Type = SplitLine[1].Trim();
                    ////    p.PartCategory = SplitLine[2].Trim();

                    ////    //Enter information in RegDataSheet: description, sequence, associated with
                    ////    p.myRegDS = new RegDataSheet(SplitLine);
                    ////    SurfaceWindow1.SearchResults.Items.Add(p);
                    ////    //p.Center = SurfaceWindow1.SetPosition(p);
                    //}

                }
            }
            catch (Exception e)
            {
                Console.WriteLine("This broke it wahh");
            }
             try
             {
                 System.Windows.Application.Current.Dispatcher.Invoke(DispatcherPriority.Normal, (Action)delegate()
                 {
                     foreach (Part p in r)
                         results.Add(p);
                     //results.Add(p);
                 });
             }
             catch (Exception e)
             {
             }

            return results;
        }

        public static void threadedsearch(SurfaceWindow1 sw, string query)
        {
            RegistrySearch r = new RegistrySearch(sw, query);
        }

        public void threadedsearch()
        {
            if (String.Equals(searchString, "Promoter", StringComparison.OrdinalIgnoreCase))
            {
                searchString = "Promoter";
            }
            else if (String.Equals(searchString, "Terminator", StringComparison.OrdinalIgnoreCase))
            {
                searchString = "Terminator";
            }
            else if (String.Equals(searchString, "CDS", StringComparison.OrdinalIgnoreCase))
            {
                searchString = "CDS";
            }
            else if (String.Equals(searchString, "RBS", StringComparison.OrdinalIgnoreCase))
            {
                searchString = "RBS";
            }


            System.Windows.Application.Current.Dispatcher.Invoke(
                DispatcherPriority.Normal, (Action)delegate()
            {

                sw1.SearchResults.Clear();
            });
            
            Populate_results(sw1, searchString);
            //change below line laterrrrr
            Populate_results(sw1, searchString + "2");
            //searchString = searchString + ".txt";
        }

    }
}
