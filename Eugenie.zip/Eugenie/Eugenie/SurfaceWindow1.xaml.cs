using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Surface;
using Microsoft.Surface.Presentation;
using Microsoft.Surface.Presentation.Controls;
using Microsoft.Surface.Presentation.Input;
using System.Threading;
using System.Collections.ObjectModel;
using Eugenie.Model;
using System.ComponentModel;
using Eugenie;
using Eugenie.Views;
using System.IO;
using System.Net;

namespace Eugenie
{
    /// <summary>
    /// Interaction logic for SurfaceWindow1.xaml
    /// </summary>
    public partial class SurfaceWindow1 : SurfaceWindow, INotifyPropertyChanged
    {
        #region Variables
        private ProgressBarWrapper _progressBarWrapper;
        private Thread _currentSearch;
        private ScatterView DropTarget1;
        //private ScatterView DropTarget;
        private SurfaceListBox DropTarget;
        private NotifiableCollection<Part> _clothoResults = new NotifiableCollection<Part>();
        private NotifiableCollection<Part> _searchResults = new NotifiableCollection<Part>();
        private NotifiableCollection<Part> _designParts = new NotifiableCollection<Part>();
        private NotifiableCollection<Part> _designpartsviewParts = new NotifiableCollection<Part>();
        public NotifiableCollection<Relationship> _relationships = new NotifiableCollection<Relationship>();
        private Collection<List<Part>> _devices = new Collection<List<Part>>();
        private Collection<List<Part>> _resultsDevices = new Collection<List<Part>>();
        private double _windowHeight;
        private double _windowWidth;
        private double _panelCenterY;

        public string eugenecode;


        double Random = 150.0;

        #endregion

        #region Sizing
        public Point ShutterPanelCenter
        {
            set
            {
                
                OnPropertyChanged("ShutterPanelCenter");
            }

            get
            {
                return new Point(Shutters.ActualWidth/2,Shutters.ActualHeight/2);
            }
        }

        public Point TreePanelCenter
        {
            set
            {

                OnPropertyChanged("TreeCenter");
            }

            get
            {
                return new Point(Shutters.ActualWidth / 2, Shutters.ActualHeight / 2);
            }
        }

        public Point FlowPanelCenter
        {
            set
            {

                OnPropertyChanged("FlowCenter");
            }

            get
            {
                return new Point(Shutters.ActualWidth / 2, Shutters.ActualHeight / 2);
            }
        }

        public Point CodePanelCenter
        {
            set
            {

                OnPropertyChanged("PanelCenter");
            }

            get
            {
                return new Point(Shutters.ActualWidth / 2, Shutters.ActualHeight / 2);
            }
        }

        public Point ResultsPanelCenter
        {
            set
            {

                OnPropertyChanged("PanelCenter");
            }

            get
            {
                return new Point(Shutters.ActualWidth / 2, Shutters.ActualHeight / 2);
            }
        }

        public double WindowHeight
        {
            set
            {
                _windowHeight = value;
                OnPropertyChanged("WindowHeight");
            }

            get
            {
                return _windowHeight;
            }
        }

        public double WindowWidth
        {
            set
            {
                _windowWidth = value;
                OnPropertyChanged("WindowWidth");
            }

            get
            {
                return _windowHeight;
            }
        }

        public double ShutterSVWidth
        {   
            get
            {
                return _windowHeight - 400;
            }
        }
        #endregion

        public Collection<List<Part>> ResultsDevices
        {
            get
            {
                if (_resultsDevices == null)
                {
                    _resultsDevices = new Collection<List<Part>>();
                }
                return _resultsDevices;
            }
        }
        
        public Collection<List<Part>> DevicesList
        {
            get
            {
                if (_devices == null)
                {
                    _devices = new Collection<List<Part>>();
                } 
                return _devices;
            }

        }

        public NotifiableCollection<Relationship> rules
        {
            get
            {
                if (_relationships == null)
                {
                    _relationships = new NotifiableCollection<Relationship>();
                }
                return _relationships;
            }

        }

        

        #region Collections
        
             
        public NotifiableCollection<Part> SearchResults
        {
            get
            {
                if (_searchResults == null)
                {
                    _searchResults = new NotifiableCollection<Part>();
                }
                return _searchResults;
            }

            
        }

        public NotifiableCollection<Part> DesignParts
        {
            get
            {
                if (_designParts == null)
                {
                    _designParts = new NotifiableCollection<Part>();
                }
                return _designParts;
            }
        }

        public NotifiableCollection<Part> ClothoParts
        {
            get
            {
                if (_clothoResults == null)
                    _clothoResults = new NotifiableCollection<Part>();
                return _clothoResults;
            }
        }

        public NotifiableCollection<Part> DPViewParts
        {
            get
            {
                if (_designpartsviewParts == null)
                    _designpartsviewParts = new NotifiableCollection<Part>();
                return _designpartsviewParts;
            }
        }

        #endregion
        #region eventhandlers

      


        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string propertyName)
        {
            var handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }
        # endregion

        /// <summary>
        /// Default constructor.
        /// </summary>
        public SurfaceWindow1()
        {
            InitializeComponent();
            this.DragEnter += new DragEventHandler(DropTarget_DragEnter);
            DataContext = this;
          
            MyTreeView.sw1 = this;
            MyResultsView.sw1 = this;
            MyFlowView.sw1 = this;
            MyDesignPartsView.sw1 = this;

            generateEugene();
            MyCodeView.code.Text = eugenecode;

            _windowHeight = System.Windows.SystemParameters.PrimaryScreenHeight-50;
            _windowWidth= System.Windows.SystemParameters.PrimaryScreenWidth - 50;
            _panelCenterY = _windowHeight / 2 ;



        }


        private void showProgressBar()
        {
            ProgressIndicator.Visibility = Visibility.Visible;
        }

        private void hideProgressBar()
        {
            ProgressIndicator.Visibility = Visibility.Collapsed;
        }


        #region Default methods

        protected override void OnInitialized(EventArgs e)
        {
            base.OnInitialized(e);
            DataContext = this;


            

            //Initialize progress bar
            _progressBarWrapper = new ProgressBarWrapper(new Action(showProgressBar), new Action(hideProgressBar));

            //Data bind views to DesignParts collection
            MyDesignPartsView.DesignPartsViewScatterView.DataContext = DPViewParts;
            this.DropTarget = MyDesignPartsView.DesignPartsViewScatterView;
            MyDesignPartsView.DesignPartsViewScatterView.ItemsSource = DPViewParts;

            MyTreeView.TreeViewScatterView.DataContext = DesignParts;
            this.DropTarget1 = MyTreeView.TreeViewScatterView;
            MyTreeView.TreeViewScatterView.ItemsSource = DesignParts;

            SurfaceDragDrop.AddDragEnterHandler(MyTreeView.TreeViewScatterView, DropTarget1_DragEnter);
            SurfaceDragDrop.AddDropHandler(MyTreeView.TreeViewScatterView, DropTarget1_Drop);
            SurfaceDragDrop.AddDragLeaveHandler(MyTreeView.TreeViewScatterView, DropTarget1_DragLeave);
            SurfaceDragDrop.AddDragCompletedHandler(MyTreeView.TreeViewScatterView, DropTarget1_DragCompleted);
            SurfaceDragDrop.AddDragCanceledHandler(MyTreeView.TreeViewScatterView, DropTarget1_DragCanceled);

            SurfaceDragDrop.AddDragEnterHandler(MyDesignPartsView.DesignPartsViewScatterView, DropTarget_DragEnter);
            SurfaceDragDrop.AddDropHandler(MyDesignPartsView.DesignPartsViewScatterView, DropTarget_Drop);
            SurfaceDragDrop.AddDragLeaveHandler(MyDesignPartsView.DesignPartsViewScatterView, DropTarget_DragLeave);
            SurfaceDragDrop.AddDragCompletedHandler(MyDesignPartsView.DesignPartsViewScatterView, DropTarget_DragCompleted);
            SurfaceDragDrop.AddDragCanceledHandler(MyDesignPartsView.DesignPartsViewScatterView, DropTarget_DragCanceled);

            MyFlowView.FlowViewScatterView.DataContext = DesignParts;
            MyFlowView.FlowViewScatterView.ItemsSource = DesignParts;
        }

        private void SurfaceWindow_Loaded(object sender, RoutedEventArgs e)
        {

        }

        /// <summary>
        /// Occurs when the window is about to close. 
        /// </summary>
        /// <param name="e"></param>
        protected override void OnClosed(EventArgs e)
        {
            base.OnClosed(e);

            // Remove handlers for window availability events
            RemoveWindowAvailabilityHandlers();
        }

        /// <summary>
        /// Adds handlers for window availability events.
        /// </summary>
        private void AddWindowAvailabilityHandlers()
        {
            // Subscribe to surface window availability events
            ApplicationServices.WindowInteractive += OnWindowInteractive;
            ApplicationServices.WindowNoninteractive += OnWindowNoninteractive;
            ApplicationServices.WindowUnavailable += OnWindowUnavailable;
        }

        /// <summary>
        /// Removes handlers for window availability events.
        /// </summary>
        private void RemoveWindowAvailabilityHandlers()
        {
            // Unsubscribe from surface window availability events
            ApplicationServices.WindowInteractive -= OnWindowInteractive;
            ApplicationServices.WindowNoninteractive -= OnWindowNoninteractive;
            ApplicationServices.WindowUnavailable -= OnWindowUnavailable;
        }

        /// <summary>
        /// This is called when the user can interact with the application's window.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnWindowInteractive(object sender, EventArgs e)
        {
            //TODO: enable audio, animations here
        }

        /// <summary>
        /// This is called when the user can see but not interact with the application's window.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnWindowNoninteractive(object sender, EventArgs e)
        {
            //TODO: Disable audio here if it is enabled

            //TODO: optionally enable animations here
        }

        /// <summary>
        /// This is called when the application's window is not visible or interactive.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnWindowUnavailable(object sender, EventArgs e)
        {
            //TODO: disable audio, animations here
        }

        #endregion

        //Look at dragdrop here if it doesnt work
        //http://msdn.microsoft.com/en-us/library/ee804892(v=surface.10).aspx

        private void DragSource_DragCompleted(object sender, SurfaceDragCompletedEventArgs e)
        {
            if (e.Cursor.Effects == DragDropEffects.Move)
            {
                //SearchResults.Remove(e.Cursor.Data as Part);
            }
        }



        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DragSource_PreviewTouchDown(object sender, TouchEventArgs e)
        {
            FrameworkElement findSource = e.OriginalSource as FrameworkElement;
            SurfaceListBoxItem draggedElement = null;

            // Find the ScatterViewitem object that is being touched.
            while (draggedElement == null && findSource != null)
            {
                if ((draggedElement = findSource as SurfaceListBoxItem) == null)
                {
                    findSource =
                     VisualTreeHelper.GetParent(findSource) as FrameworkElement;
                }
            }

            if (draggedElement == null)
            {
                return;
            }

            Part data = draggedElement.Content as Part;

            if (data == null || !data.CanDrag)
            {
                return;
            }

            data.DraggedElement = draggedElement;



            // Create the cursor visual
            ContentControl cursorVisual = new ContentControl()
            {
                Content = draggedElement.DataContext,
                Style = FindResource("CursorStyle") as Style
            };
            
            //Enable the application to change the visual cues.
            SurfaceDragDrop.AddTargetChangedHandler(cursorVisual, OnTargetChanged);
            SurfaceDragDrop.AddPreviewDragEnterHandler(cursorVisual, DropTarget_DragEnter);
            SurfaceDragDrop.AddDropHandler(cursorVisual, DropTarget_Drop);
            SurfaceDragDrop.AddPreviewDropHandler(cursorVisual, DropTarget_Drop);

            // Create a list of input devices. Add the touches that
            // are currently captured within the dragged element and
            // the current touch (if it isn't already in the list).
            List<InputDevice> devices = new List<InputDevice>();
           //devices.Add(e.TouchDevice);
            devices.Add(e.TouchDevice);
            foreach (InputDevice touch in draggedElement.TouchesCapturedWithin)
            {
                if (touch != e.TouchDevice)
                {
                    devices.Add(touch);
                }
            }

            ItemsControl dragSource = ItemsControl.ItemsControlFromItemContainer(draggedElement);
            
           
            
            SurfaceDragCursor startDragOkay =
                
            SurfaceDragDrop.BeginDragDrop(
                          dragSource,                     // The ScatterView object that the cursor is dragged out from.
                          draggedElement,                 // The ScatterViewItem object that is dragged from the drag source.
                          cursorVisual,                   // The visual element of the cursor.
                          draggedElement.DataContext,     // The data attached with the cursor.
                          devices,                        // The input devices that start dragging the cursor.
                          DragDropEffects.Move);          // The allowed drag-and-drop effects of this operation.


 
            if (startDragOkay != null)
            {
           
                e.Handled = true;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnTargetChanged(object sender, TargetChangedEventArgs e) 
        {
            if (e.Cursor.CurrentTarget != null)
            {
                Part data = e.Cursor.Data as Part;
                e.Cursor.Visual.Tag = (data.CanDrop) ? "CanDrop" : "CannotDrop";
            }
            else
            {
                e.Cursor.Visual.Tag = null;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DropTarget1_DragEnter(object sender, SurfaceDragDropEventArgs e)
        {
           
            ScatterView svi = sender as ScatterView;
            string temp = svi.Name;
          
            Part data = e.Cursor.Data as Part;
            if (!data.CanDrop)
            {
                e.Effects = DragDropEffects.None;
            }
            else
            {
                e.Effects = DragDropEffects.Move;
            }
        }

        //for DPView
        private void DropTarget_DragEnter(object sender, SurfaceDragDropEventArgs e)
        {

           
            Part data = e.Cursor.Data as Part;
            if (!data.CanDrop)
            {
                e.Effects = DragDropEffects.None;
            }
            else
            {
                e.Effects = DragDropEffects.Move;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DropTarget1_DragLeave(object sender, SurfaceDragDropEventArgs e)
        {
            e.Cursor.Visual.Tag = null;
        }

        //for DPView
        private void DropTarget_DragLeave(object sender, SurfaceDragDropEventArgs e)
        {
            e.Cursor.Visual.Tag = null;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DropTarget1_Drop(object sender, SurfaceDragDropEventArgs e)
        {
            Part temp = e.Cursor.Data as Part;//model
            Part newPart = temp.clonePart;
            
            newPart.Coordinates = new Point(Random, 150.0);
            DesignParts.Add(newPart as Part);
            List<Part> newList = new List<Part>();
            newList.Add(newPart as Part);
            DevicesList.Add(newList);
                ScatterViewItem svi =
    DropTarget1.ItemContainerGenerator.ContainerFromItem(newPart) as ScatterViewItem;//view container
                //svi.Center = newPart.Coordinates;
                MyCodeView.code.Text = generateEugene();
                e.Handled = true;
               // Random = Random + (svi.Width);
        }

        //for DPView
        private void DropTarget_Drop(object sender, SurfaceDragDropEventArgs e)
        {
            Part temp = e.Cursor.Data as Part;//model
            Part newPart = temp.clonePart;
            newPart.Coordinates = new Point(Random, 150.0);
            Console.WriteLine("newPart coordinates: " + newPart.Coordinates);
            DPViewParts.Add(newPart as Part);
            SurfaceListBoxItem svi =
DropTarget.ItemContainerGenerator.ContainerFromItem(newPart) as SurfaceListBoxItem;//view container
            //svi.Center = newPart.Coordinates;
            e.Handled = true;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DropTarget1_DragCompleted(object sender, SurfaceDragCompletedEventArgs e)
        {
            if (e.Cursor.CurrentTarget != DropTarget1 &&
            e.Cursor.Effects == DragDropEffects.Move)
            {
               e.Handled = true;
            }
        }

        //for DPView
        private void DropTarget_DragCompleted(object sender, SurfaceDragCompletedEventArgs e)
        {
            if (e.Cursor.CurrentTarget != DropTarget &&
            e.Cursor.Effects == DragDropEffects.Move)
            {
                e.Handled = true;
            }
        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DropTarget1_DragCanceled(object sender, SurfaceDragDropEventArgs e)
        {
            Part data = e.Cursor.Data as Part;
            //ScatterViewItem svi =
             //DropTarget.ItemContainerGenerator.ContainerFromItem(data) as ScatterViewItem;
            SurfaceListBoxItem svi = data.DraggedElement as SurfaceListBoxItem;
            if (svi != null)
            {
                svi.Visibility = Visibility.Visible;
            }
        }

        //for DPView
        private void DropTarget_DragCanceled(object sender, SurfaceDragDropEventArgs e)
        {
            Part data = e.Cursor.Data as Part;
            //ScatterViewItem svi =
            //DropTarget.ItemContainerGenerator.ContainerFromItem(data) as ScatterViewItem;
            SurfaceListBoxItem svi = data.DraggedElement as SurfaceListBoxItem;
            if (svi != null)
            {
                svi.Visibility = Visibility.Visible;
            }
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DropTarget1_DragEnter(object sender, DragEventArgs e)
        {
            DesignParts.Add((Part)e.Data);
        }

        //for DPView
        private void DropTarget_DragEnter(object sender, DragEventArgs e)
        {
            DPViewParts.Add((Part)e.Data);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DropTarget_Drop(object sender, DragEventArgs e)
        {
            //If itisn't already there, add it

            if (!DesignParts.Contains((Part)e.Data))
            {
                DesignParts.Add((Part)e.Data as Part);
            }
        
        }

        
       

        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {

        }
    

        #region shutters

        //more vars!
        private Point left;
        private Point right;
        private double snapThreshold = 100.00;
        private double windowSnapThreshold = 50.00;
        public static SurfaceWindow1 sw1;

        private void CodeView_ContainerManipulationCompleted(object sender, ContainerManipulationCompletedEventArgs e)
        {
            ScatterViewItem CV = (ScatterViewItem)MyCodeView;
            ScatterViewItem FV = (ScatterViewItem)MyFlowView;
            left = new Point(400.0, 150.0);
            right = new Point(730, 150.0);
            //If its center is within the threshold of low.Y or high.Y or L2
            if (CV.Center.X < left.X + snapThreshold)
                CV.Center = new Point(left.X, CV.Center.Y);
            if (CV.Center.X > right.X - snapThreshold)
                CV.Center = new Point(right.X, CV.Center.Y);
            if (CV.Center.X < (FV.Center.X - windowSnapThreshold))
                CV.Center = new Point(FV.Center.X + windowSnapThreshold, CV.Center.Y);          
        }

        private void FlowView_ContainerManipulationCompleted(object sender, ContainerManipulationCompletedEventArgs e)
        {
            ScatterViewItem CV = (ScatterViewItem)MyCodeView;
            ScatterViewItem FV = (ScatterViewItem)MyFlowView;
            ScatterViewItem TV = (ScatterViewItem)MyTreeView;
            left = new Point(350.0, 150.0);
            right = new Point(480, 150.0);
            //If its center is within the threshold of low.Y or high.Y or L2
            if (FV.Center.X < left.X + snapThreshold)
                FV.Center = new Point(left.X, FV.Center.Y);
            if (FV.Center.X > right.X - snapThreshold)
                FV.Center = new Point(right.X, FV.Center.Y);
            if (FV.Center.X < (TV.Center.X - windowSnapThreshold))
                FV.Center = new Point(TV.Center.X + windowSnapThreshold, FV.Center.Y);
            if (FV.Center.X > (CV.Center.X - windowSnapThreshold))
                FV.Center = new Point(CV.Center.X - windowSnapThreshold, FV.Center.Y);
        }

        private void TreeView_ContainerManipulationCompleted(object sender, ContainerManipulationCompletedEventArgs e)
        {
            ScatterViewItem FV = (ScatterViewItem)MyFlowView;
            ScatterViewItem TV = (ScatterViewItem)MyTreeView; 
            ScatterViewItem DV = (ScatterViewItem)MyDesignPartsView;
            //left = new Point(300.0, 150.0);
            //right = new Point(1430, 150.0);
            //If its center is within the threshold of low.Y or high.Y or L2
            double strip = TV.ActualWidth / 10;


            if (TV.Center.X < left.X + snapThreshold)
                TV.Center = new Point(left.X, TV.Center.Y);
            if (TV.Center.X > right.X - snapThreshold)
                TV.Center = new Point(right.X, TV.Center.Y);
            if (TV.Center.X > (FV.Center.X - windowSnapThreshold))
                TV.Center = new Point(FV.Center.X - windowSnapThreshold, TV.Center.Y);
        }

        private void ResultsView_ContainerManipulationCompleted(object sender, ContainerManipulationCompletedEventArgs e)
        {
            ScatterViewItem CV = (ScatterViewItem)MyCodeView;
            ScatterViewItem RV = (ScatterViewItem)MyResultsView;
            left = new Point(450.0, 150.0);
            right = new Point(580, 150.0);
            //If its center is within the threshold of low.Y or high.Y or L2
            if (RV.Center.X < left.X + snapThreshold)
                RV.Center = new Point(left.X, RV.Center.Y);
            if (RV.Center.X > right.X - snapThreshold)
                RV.Center = new Point(right.X, RV.Center.Y);
            if (RV.Center.X < (CV.Center.X - windowSnapThreshold))
                RV.Center = new Point(CV.Center.X + windowSnapThreshold, RV.Center.Y);
            
        }

        private void ShutterView_ContainerManipulationDelta(object sender, ContainerManipulationDeltaEventArgs e)
        {
            ScatterViewItem View = sender as ScatterViewItem;

            if (View.Center.X < 50 || View.Center.X > Shutters.Width - 100)
                View.CancelManipulation();

            View.Center = new Point(View.Center.X, ShutterPanelCenter.Y);


        }

       

        private void DragSource_MouseDown(object sender, MouseButtonEventArgs e)
        {
            FrameworkElement findSource = e.OriginalSource as FrameworkElement;
            SurfaceListBoxItem draggedElement = null;

            // Find the ScatterViewitem object that is being touched.
            while (draggedElement == null && findSource != null)
            {
                if ((draggedElement = findSource as SurfaceListBoxItem) == null)
                {
                    findSource =
                     VisualTreeHelper.GetParent(findSource) as FrameworkElement;
                }
            }

            if (draggedElement == null)
            {
                return;
            }

            Part data = draggedElement.Content as Part;

            if (data == null || !data.CanDrag)
            {
                return;
            }

            data.DraggedElement = draggedElement;



            // Create the cursor visual
            ContentControl cursorVisual = new ContentControl()
            {
                Content = draggedElement.DataContext,
                Style = FindResource("CursorStyle") as Style
            };

            //Enable the application to change the visual cues.
            SurfaceDragDrop.AddTargetChangedHandler(cursorVisual, OnTargetChanged);
            SurfaceDragDrop.AddPreviewDragEnterHandler(cursorVisual, DropTarget_DragEnter);
            SurfaceDragDrop.AddDropHandler(cursorVisual, DropTarget_Drop);
            SurfaceDragDrop.AddPreviewDropHandler(cursorVisual, DropTarget_Drop);

            // Create a list of input devices. Add the touches that
            // are currently captured within the dragged element and
            // the current touch (if it isn't already in the list).
            List<InputDevice> devices = new List<InputDevice>();
            //devices.Add(e.TouchDevice);
            devices.Add(e.Device);
            foreach (InputDevice touch in draggedElement.TouchesCapturedWithin)
            {
                if (touch != e.Device)
                {
                    devices.Add(touch);
                }
            }

            ItemsControl dragSource = ItemsControl.ItemsControlFromItemContainer(draggedElement);



            SurfaceDragCursor startDragOkay =

            SurfaceDragDrop.BeginDragDrop(
                          dragSource,                     // The ScatterView object that the cursor is dragged out from.
                          draggedElement,                 // The ScatterViewItem object that is dragged from the drag source.
                          cursorVisual,                   // The visual element of the cursor.
                          draggedElement.DataContext,     // The data attached with the cursor.
                          devices,                        // The input devices that start dragging the cursor.
                          DragDropEffects.Move);          // The allowed drag-and-drop effects of this operation.


            if (startDragOkay != null)
            {
            
                e.Handled = true;
            }
        }
        #endregion

       

        
        public string generateEugene()
        {

            string eugtxt = "Property name(txt);\nProperty sequence(txt);\nProperty description(txt);\nProperty represses(txt);\nProperty type(txt);\nProperty repressedby(txt);\nProperty LFS(txt);\nProperty RFS(txt);\n\n";
            eugtxt += "Part Promoter(sequence, represses, name); \nPart RBS(sequence, represses, name); \nPart Gene(sequence, represses, name); \nPart Terminator(sequence, represses, name);\nPart CDS(sequence, represses, name); \nPart undef(sequence, represses, name);\n\n";

            eugtxt += "//parts\n";
            foreach (Part p in MyTreeView.TreeViewScatterView.Items){
                eugtxt += p.Type + " p" + MyTreeView.TreeViewScatterView.Items.IndexOf(p) +"(.sequence(\"" + p.sequence + "\"), .represses(\""+p.Represses+ "\"), .name(\""+p.Name+"\"));\n";
                p.eugenename = "p" + MyTreeView.TreeViewScatterView.Items.IndexOf(p);
            }
            eugtxt += "\n";

            eugtxt += "//rules\n";
            foreach (Relationship r in _relationships)
            {
                eugtxt += "Rule r" + _relationships.IndexOf(r)+ "(" + r.ToString() + ");\n";
            }
            
            eugtxt += "\n//devices\n";

            foreach (List<Part> device in _devices)
            {
                eugtxt += "Device d" + _devices.IndexOf(device) + " (";

                foreach (Part p in device)
                {
                    eugtxt += "p" + MyTreeView.TreeViewScatterView.Items.IndexOf(p) + ",";
                }
                eugtxt = eugtxt.Substring(0, eugtxt.Length - 1);

                eugtxt += ");\n";
                
                eugtxt += "Device[] perm" + _devices.IndexOf(device) + " =permute(d" + _devices.IndexOf(device) + ", flexible);\n";
             

                eugtxt += "for (num x = 0; x < perm" + _devices.IndexOf(device) + ".size() ; x++)\n{\nprintln(perm" + _devices.IndexOf(device) + "[x]);\n}\n\n";
            }



            eugenecode = eugtxt;
            MyCodeView.code.Text = eugenecode;
            return eugtxt;
        }

        
        public string generateLimitedEugene(int numResults)
        {
            string eugtxt = "Property name(txt);\nProperty sequence(txt);\nProperty description(txt);\nProperty represses(txt);\nProperty type(txt);\nProperty repressedby(txt);\nProperty LFS(txt);\nProperty RFS(txt);\n\n";
            eugtxt += "Part Promoter(sequence, represses, name); \nPart RBS(sequence, represses, name); \nPart Gene(sequence, represses, name); \nPart Terminator(sequence, represses, name);\nPart CDS(sequence, represses, name); \nPart undef(sequence, represses, name);\n\n";

            eugtxt += "//parts\n";
            foreach (Part p in MyTreeView.TreeViewScatterView.Items)
            {
                eugtxt += p.Type + " p" + MyTreeView.TreeViewScatterView.Items.IndexOf(p) + "(.sequence(\"" + p.sequence + "\"), .represses(\"" + p.Represses + "\"), .name(\"" + p.Name + "\"));\n";
                p.eugenename = "p" + MyTreeView.TreeViewScatterView.Items.IndexOf(p);
            }
            eugtxt += "\n";

            eugtxt += "//rules\n";
            foreach (Relationship r in _relationships)
            {
                eugtxt += "Rule r" + _relationships.IndexOf(r) + "(" + r.ToString() + ");\n";
            }

            eugtxt += "\n//devices\n";

            foreach (List<Part> device in _devices)
            {
                eugtxt += "Device d" + _devices.IndexOf(device) + " (";

                foreach (Part p in device)
                {
                    eugtxt += "p" + MyTreeView.TreeViewScatterView.Items.IndexOf(p) + ",";
                }
                eugtxt = eugtxt.Substring(0, eugtxt.Length - 1);

                eugtxt += ");\n";
                
                eugtxt += "Device[] perm" + _devices.IndexOf(device) + " =permute(d" + _devices.IndexOf(device) + ", flexible, " +numResults.ToString()+");\n";
               

                eugtxt += "for (num x = 0; x < perm" + _devices.IndexOf(device) + ".size() ; x++)\n{\nprintln(perm" + _devices.IndexOf(device) + "[x]);\n}\n\n";
            }



            eugenecode = eugtxt;
        
            return eugtxt;
        }


        private void MyResultsView_ContainerManipulationCompleted(object sender, ContainerManipulationCompletedEventArgs e)
        {

        }

        private void SurfaceButton_Click(object sender, RoutedEventArgs e)
        {

        }

        private void PermuteButton_Click(object sender, RoutedEventArgs e)
        {

        }

    }

        

    /// <summary>
    /// Taken from http://www.sieena.com/blog/archive/2011/01/25/extending-observablecollection-lt-t-gt-to-notify-when-an-item-has-changed-.aspx
    /// </summary>
    public class NotifyCollectionChangeEventArgs : PropertyChangedEventArgs
    {
        public int Index { get; set; }

        public NotifyCollectionChangeEventArgs(int index, string propertyName)
            : base(propertyName)
        {
            Index = index;
        }
    }

    public class NotifiableCollection<T> : ObservableCollection<T> where T : class, INotifyPropertyChanged
    {
        public event EventHandler<NotifyCollectionChangeEventArgs> ItemChanged;

        protected override void ClearItems()
        {
            foreach (var item in this.Items)
            {
                item.PropertyChanged -= ItemPropertyChanged;
            }
            base.ClearItems();
        }

        protected override void SetItem(int index, T item)
        {
            this.Items[index].PropertyChanged -= ItemPropertyChanged;
            base.SetItem(index, item);
            this.Items[index].PropertyChanged += ItemPropertyChanged;
        }

        protected override void RemoveItem(int index)
        {
            this.Items[index].PropertyChanged -= ItemPropertyChanged;
            base.RemoveItem(index);
        }

        protected override void InsertItem(int index, T item)
        {
            base.InsertItem(index, item);
            item.PropertyChanged += ItemPropertyChanged;
        }

        private void ItemPropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            T changedItem = sender as T;
            OnItemChanged(this.IndexOf(changedItem), e.PropertyName);
        }

        private void OnItemChanged(int index, string propertyName)
        {
            if (ItemChanged != null)
            {
                this.ItemChanged(this, new NotifyCollectionChangeEventArgs(index, propertyName));

            }
        }



    }


} 
