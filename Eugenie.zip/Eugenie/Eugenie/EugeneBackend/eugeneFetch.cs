﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Diagnostics;

namespace Eugenie.EugeneBackend
{
    class eugeneFetch
    {
        public static string EugeneCrunch(String Filename)
        {
             String output = "";

             try
             {
                 String path = Directory.GetCurrentDirectory();
                 String dir = path.Substring(0, path.Length - ("\\bin\\debug".Length));
                 String eugpath = dir + "\\EugeneBackend\\eugene.jar";
                 string javapath = dir + "\\EugeneBackend\\java.exe";
                 string filepath = dir + "\\EugeneBackend\\" + Filename;

                 Process p = new Process();


                 //ProcessStartInfo processInfo = new ProcessStartInfo();
                 p.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                 p.StartInfo.FileName = javapath;
                 //p.StartInfo.FileName = eugpath;
                 p.StartInfo.WorkingDirectory = Path.GetDirectoryName(eugpath);
                 //p.StartInfo.Arguments = "/c START " + Path.GetFileName(phppath) + " " + ipaddress + " " + username + " " + password + " " + dbname;
                 p.StartInfo.Arguments = "-jar " + eugpath + " " + filepath;
                 p.StartInfo.RedirectStandardOutput = true;
                 p.StartInfo.UseShellExecute = false;
                 p.Start();
                 output = p.StandardOutput.ReadToEnd();
                 //p.WaitForExit();
             }
             catch (Exception e)
             {
                 output = e.ToString();
             }
             return output;
        }

        public static void makeEugFile(String filename, string content){


            String path = Directory.GetCurrentDirectory();
            String dir = path.Substring(0, path.Length - ("\\bin\\debug".Length));
            string filepath = dir + "\\EugeneBackend\\" + filename;
            System.IO.File.WriteAllText(filepath, content);
        }

    }
}
