﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Diagnostics;
using MySql.Data.MySqlClient;
using Eugenie.Model;

namespace Eugenie.MySQLBackend
{
    class clothofetch
    {
        public static void main(String[] args)
        {
        }

        //retrieves data from clotho db, and returns json string via clothodatabase.txt
        public static string fetchData(String ipaddress, String username, String password, String dbname)
        {
            string result = "";
            string cs= "server="+ipaddress+";userid="+username+";password="+password+";database="+dbname;

            MySqlConnection conn = null;
            MySqlDataReader read = null;

            try
            {
                conn = new MySqlConnection(cs);
                conn.Open();

                string stm = "SELECT * FROM PartTable,  NucseqTable,  PersonTable, LabTable,  InstitutionTable where nucseqid=idnucseq and authorid=idperson and institutionid=idinstitution and labid=idlab";
                MySqlCommand cmd = new MySqlCommand(stm, conn);

                read = cmd.ExecuteReader();


                while (read.Read())
                {
                    result += read.GetString("formatId");
                }

            }
            catch (MySqlException e)
            {
                Console.WriteLine(e);
            }
            finally
            {
                if (conn != null)
                    conn.Close();
            }

            return result;


        
        }



        public static NotifiableCollection<Part> fetchparts(String ipaddress, String username, String password, String dbname)
        {
            NotifiableCollection<Part> result = new NotifiableCollection<Part>();
            string cs = "server=" + ipaddress + ";userid=" + username + ";password=" + password + ";database=" + dbname;

            MySqlConnection conn = null;
            MySqlDataReader read = null;

            try
            {
                conn = new MySqlConnection(cs);
                conn.Open();

                string stm = "SELECT * FROM PartTable,  NucseqTable,  PersonTable, LabTable,  InstitutionTable where nucseqid=idnucseq and authorid=idperson and institutionid=idinstitution and labid=idlab";
                MySqlCommand cmd = new MySqlCommand(stm, conn);

                read = cmd.ExecuteReader();


                while (read.Read())
                {
                    Part p = new Part(read.GetString("name"), true, true);
                    p.idPart = read.GetString("idPart");
                    p.description = read.GetString("description");
                    p.format = read.GetString("formatId");

                    try
                    {
                        p.sequence = read.GetString("sequence");
                    }
                    catch (Exception e)
                    {
                        p.sequence = "undef";
                    }


                    p.riskGroup = read.GetString("riskGroup");
                    result.Add(p);
                }

            }
            catch (MySqlException e)
            {
                Console.WriteLine(e);
            }
            finally
            {
                if (conn != null)
                    conn.Close();
            }

            return result;

        }
    }
}
