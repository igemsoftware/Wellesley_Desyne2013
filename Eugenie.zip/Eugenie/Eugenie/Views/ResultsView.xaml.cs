﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Surface;
using Microsoft.Surface.Presentation;
using Microsoft.Surface.Presentation.Controls;
using Microsoft.Surface.Presentation.Input;
using Eugenie;
using Eugenie.Views;
using Eugenie.Model;
using System.IO;
using System.Threading;
using System.Windows.Threading;

namespace Eugenie.Views
{

    
    /// <summary>
    /// Interaction logic for CodeView.xaml
    /// </summary>
    public partial class ResultsView : ScatterViewItem
    {

        public SurfaceWindow1 sw1;
       
        string eugeneCode;
        List<result> resultlist = new List<result>();
        result dev = new result();

        public ResultsView()
        {
            InitializeComponent();
        }

        protected override void OnInitialized(EventArgs e)
        {
            base.OnInitialized(e);
            DataContext = this;

            Pigeon.PigeonRunner myPigeonRunner = new Pigeon.PigeonRunner();

            String path = Directory.GetCurrentDirectory();
            String dir = path.Substring(0, path.Length - ("\\bin\\debug".Length));
            string filepath = dir + "\\Pigeon\\";


            Eugenie.Views.result dev3 = new result();
            dev3.PigeonImg.Source = myPigeonRunner.ManuallySetTheCookieMethod(filepath + "1.txt");
            ResultsSurfaceListBox.Items.Add(dev3);
            
        }
    

    

    #region snapping

    //vars
        private Point left;
        private Point right;
        private double snapThreshold;
        private double snapThreshold_flow;

        private void CodeView_ContainerManipulationCompleted(object sender, ContainerManipulationCompletedEventArgs e)
        {
            ScatterViewItem RV = (ScatterViewItem)sender;
            //If its center is within the threshold of low.Y or high.Y or L2
            if (RV.Center.Y < left.Y + snapThreshold)
                RV.Center = new Point(right.X, left.Y);
            if (RV.Center.Y > right.Y - snapThreshold)
                RV.Center = new Point(right.X, right.Y);
            if (RV.Center.Y > (sw1.MyFlowView.Center.Y - snapThreshold_flow))
                RV.Center = new Point(right.X, sw1.MyFlowView.Center.Y - snapThreshold_flow);
        }





    #endregion

  



        //get results button


        internal void populateresults(string s)
        {

           
            String[] results = s.Split('\n');
            char[] parens = new char[2];
            parens[0] = '('; parens[1] = ')';


            //only process first 10 results for display
            if (results.Length > 11)
            {
                String[] truncated = new string[10];
                for (int i = 0; i < results.Length; i++)
                    truncated[i] = results[i];
                results = truncated;
            }



            for (int i = 0; i < results.Length; i++)
            {
                try
                {
                    results[i] = results[i].Split(parens)[1];
                }
                catch (Exception e)
                {
                    Console.Out.Write(e);
                }
            }

            foreach (string device in results)
            {
                String[] parts = device.Split(',');

                dev = new result();


                foreach (string part in parts)
                {
                    Part p = new Part(part, "undef", "undef", "undef", "undef", "undef");
                    foreach (Part q in sw1.DesignParts)
                    {
                        
                        if (q.eugenename.Equals(part))
                            p = q;
                    }
                  

                    dev.scroll.Items.Add(p);

                    ResultsSurfaceListBox.Items.Add(dev);


                    


                }
            }
        }

        private void SurfaceButton_Click_1(object sender, RoutedEventArgs e)
        {

            ResultsSurfaceListBox.Items.Clear();
           
            eugeneCode = sw1.generateEugene();

            EugeneBackend.eugeneFetch.makeEugFile("myeugene.eug", eugeneCode);

            String eugeneresults = EugeneBackend.eugeneFetch.EugeneCrunch("myeugene.eug");

            populateresults(eugeneresults);


            generatedResultsResults.Content = "";
        }

        public void threadedGenerateResults()
        {
            System.Windows.Application.Current.Dispatcher.Invoke(
                DispatcherPriority.Normal, (Action)delegate()
                {

                    ResultsSurfaceListBox.Items.Clear();
                });


            EugeneBackend.eugeneFetch.makeEugFile("myeugene.eug", eugeneCode);

            String eugeneresults = EugeneBackend.eugeneFetch.EugeneCrunch("myeugene.eug");
            populateresults(eugeneresults);
        }


        //exports eugene results to eugenebackend/myresults.csv; does not require that results were generated previously
        private void SurfaceButton_Click_2(object sender, RoutedEventArgs e)
        {
            string output = "";

            int numResults = 0;

            EugeneBackend.eugeneFetch.makeEugFile("myeugene.eug", sw1.eugenecode);
          
            String eugeneresults = EugeneBackend.eugeneFetch.EugeneCrunch("myeugene.eug");

            String[] results = eugeneresults.Split('\n');
            char[] parens = new char[2];
            parens[0] = '('; parens[1] = ')';

            for (int i = 0; i < results.Length; i++)
            {
                try
                {
                    results[i] = results[i].Split(parens)[1];
                }
                catch (Exception ex)
                {
                    Console.Out.Write(e);
                }
            }

            foreach (string device in results)
            {
                if (!device.Trim().Equals(""))
                {
                    String[] parts = device.Split(',');

                    


                    foreach (string part in parts)
                    {
                        Part p = new Part(part, "undef", "undef", "undef", "undef", "undef");
                        foreach (Part q in sw1.DesignParts)
                        {
                            
                            if (q.eugenename.Equals(part))
                                p = q;
                        }
                        
                        output += p.Name + ",";
                    }

                    output = output.Substring(0, output.Length - 1);


                    output += "\n";

                    numResults++;
                }
            }

            try
            {
                String path = Directory.GetCurrentDirectory();
                String dir = path.Substring(0, path.Length - ("\\bin\\debug".Length));
                string filepath = dir + "\\EugeneBackend\\" + "myresults.csv";
                System.IO.File.WriteAllText(filepath, output);

                updateResultsResultsLabel(numResults);
            }
            catch(Exception x){
                Console.Out.WriteLine(x);
            }


        }

        private void updateResultsResultsLabel(int numResults)
        {
            int prom = 0; int rbs = 0; int cds = 0; int term = 0; int other = 0;

            foreach (Part p in sw1.DesignParts)
            {

               
                other++;
            }


            generatedResultsResults.Content = "...\n" + numResults + (numResults == 1 ? " result" : " results") + " generated from " + sw1.DesignParts.Count + (sw1.DesignParts.Count == 1 ? " part " : " parts ") +
                ":\n" + prom + (prom == 1 ? " promoter " : " promoters ") + rbs + " RBS " + cds + " CDS " + term + (term == 1 ? " terminator " : " terminators ") + other + (other == 1 ? " other" : " others");

        }

        private void SnapLeft_Click(object sender, RoutedEventArgs e)
        {

        }

        private void SnapRight_Click(object sender, RoutedEventArgs e)
        {

        }


    }
}
