﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Surface;
using Microsoft.Surface.Presentation;
using Microsoft.Surface.Presentation.Controls;
using Microsoft.Surface.Presentation.Input; 
using Eugenie.Model;


namespace Eugenie.Views
{
    /// <summary>
    /// Interaction logic for UserControl1.xaml
    /// </summary>
    /// 
    #region default methods

    public partial class TreeView : ScatterViewItem
    {
        Dictionary<int, Line> _lineDictionary = new Dictionary<int, Line>();
        int key = 1;
        public SurfaceWindow1 sw1;
       
        Dictionary<int, Line> lineDictionary = new Dictionary<int, Line>();

        int count = 0;
       

        public TreeView()
        {
            InitializeComponent();
        }
        

    #endregion 

        #region helpermethods


        #region Snapping
        //snapping method
        private void SnapDevice(Part p, Part compareTo)
        {
            
            List<Part> ListWhichContainsP = new List<Part>();
            List<Part> ListWhichContainsCompareTo = new List<Part>();
            foreach (List<Part> Device in sw1.DevicesList.ToList())
            {
                foreach (Part pa in Device)
                {
                    if (p.Equals(pa))
                    {
                        ListWhichContainsP = Device;
                        sw1.DevicesList.Remove(Device);
                    }

                    if (compareTo.Equals(pa))
                    {
                        ListWhichContainsCompareTo = Device;
                        sw1.DevicesList.Remove(Device);
                    }
                }
            }
            Part firstP = ListWhichContainsP[0];
            Part firstCompareTo = ListWhichContainsCompareTo[0];
            double firstPX = firstP.Coordinates.X;
            double firstCompareToX = firstCompareTo.Coordinates.X;

            if (firstPX < firstCompareToX)
            {
                IEnumerable<Part> newlist = ((List<Part>)ListWhichContainsP).Concat((List<Part>)ListWhichContainsCompareTo);
                //add that list to devices
                sw1.DevicesList.Add(newlist.ToList());
              
            }
            else
            {
                IEnumerable<Part> newlist = ((List<Part>)ListWhichContainsCompareTo).Concat((List<Part>)ListWhichContainsP);
                //add that list to devices
                sw1.DevicesList.Add(newlist.ToList());
               
            }

            sw1.generateEugene();
           
        }

        //line drawing 
        private void snapping(Part p, Part compareTo)
        {
            
            Point endPt = new Point(250, 125);
            p.BorderColor = Brushes.DarkSlateGray;
            compareTo.BorderColor = Brushes.DarkSlateGray;
            SnapDevice(p, compareTo);
            List<Part> tempD = DeviceSearch(p);
            foreach (Part part in tempD)
            {
                if (part.LineKey != 0 && _lineDictionary.ContainsKey(part.LineKey))
                {
                    Line temp = _lineDictionary[part.LineKey];
                    temp.Opacity = 0.0;
                    _lineDictionary.Remove(part.LineKey);
                }
                part.LineKey = key;
                ScatterViewItem partSVI = TreeViewScatterView.ItemContainerGenerator.ContainerFromItem(part) as ScatterViewItem;
                partSVI.SetRelativeZIndex(RelativeScatterViewZIndex.Topmost);
            }
            DrawLine(findMidpoint(tempD), endPt);

        }

        //takes care of aesthetic issues with two devices snapping together
        private void snappingDeviceSVIs(Part p, Part compareTo, string direction)
        {
            
            List<Part> pDevice = DeviceSearch(p);
          
            if (direction.Equals("left"))
            {
                int index = 1;
                foreach (Part part in pDevice)
                {
                    ScatterViewItem partSVI = TreeViewScatterView.ItemContainerGenerator.ContainerFromItem(part) as ScatterViewItem;
                    partSVI.Center = new Point(compareTo.Coordinates.X - (partSVI.Width * index), compareTo.Coordinates.Y);
                    p.Coordinates = partSVI.Center;
                    index++;
                }
            }
            else if (direction.Equals("right"))
            {
                
                int index = 1;
               
                foreach (Part part in pDevice)
                {
                    ScatterViewItem partSVI = TreeViewScatterView.ItemContainerGenerator.ContainerFromItem(part) as ScatterViewItem;
                    partSVI.Center = new Point(compareTo.Coordinates.X + (partSVI.Width * index), compareTo.Coordinates.Y);
                    p.Coordinates = partSVI.Center;
                    
                }
                snapping(p, compareTo);
                
            }


        }

        #endregion

        #region DeviceSearch

        //returns List<Part> that part p is in
        private List<Part> DeviceSearch(Part p)
        {
           
            List<Part> ListWhichContainsP = new List<Part>();
            foreach (List<Part> Device in sw1.DevicesList.ToList())
            {
                foreach (Part pa in Device)
                    if (p.Equals(pa))
                    {
                        ListWhichContainsP = Device;
                    }
            }
            return ListWhichContainsP;
        }

        #endregion

        #region LineDrawing

        //line drawing commands
        private void DrawLine(Point start, Point end)
        {
           
            Line line = new Line();
            line.StrokeThickness = 4;
            line.Stroke = Brushes.Black;

            //line start and end
            line.X1 = start.X;
            line.Y1 = start.Y;
            line.X2 = end.X;
            line.Y2 = end.Y;

            LineHost.Children.Add(line);
            _lineDictionary.Add(key, line);
            key++;
        }

     

        //returns midpoint of device (from whence the line shall be drawn) 
        private Point findMidpoint(List<Part> device)
        {
            
            Point result = new Point();
            Part firstPart = device[0];
            double leftmost = firstPart.Coordinates.X;
            double rightmost = firstPart.Coordinates.X;
           

            foreach (Part p in device)
            {
                if (p != firstPart)
                {
                    if (p.Coordinates.X < leftmost)
                    {
                        leftmost = p.Coordinates.X;
                       
                    }
                    else if (p.Coordinates.X > rightmost)
                    {
                        rightmost = p.Coordinates.X;
                       
                    }
                }
            }
            double midPoint = (leftmost + rightmost) / 2;
            ScatterViewItem firstPartSVI = TreeViewScatterView.ItemContainerGenerator.ContainerFromItem(firstPart) as ScatterViewItem;
            double height = firstPartSVI.ActualHeight / 2;
            result = new Point(midPoint, firstPart.Coordinates.Y - height);
            return result;
        }

        #endregion

        #region Bounds
        private Boolean withinBounds(List<Part> tempD, double leftBound, double rightBound, double topBound, double bottomBound)
        {
           
            bool result = true;
            foreach (Part p in tempD)
            {
                if (p.Coordinates.X < leftBound || p.Coordinates.X > rightBound || p.Coordinates.Y > topBound || p.Coordinates.Y < bottomBound)
                {
                    result = false;
                }
            }
            return result;
        }

        //prevents SVIs from flying off the screen when dragging is completed
        private void setWithinBounds(List<Part> tempD)
        {
           
            Part firstPart = tempD[0];
            Point firstPoint = firstPart.Coordinates;
            int listLength = tempD.Count;
            int lastIndex = listLength - 1;
            Part lastPart = tempD[lastIndex];
            Point lastPoint = lastPart.Coordinates;
            ScatterViewItem firstPartSVI = TreeViewScatterView.ItemContainerGenerator.ContainerFromItem(firstPart) as ScatterViewItem;
            double partWidth = firstPartSVI.ActualWidth;
            double partHeight = firstPartSVI.ActualHeight;
            int index = 0;

            if (firstPoint.X <= 0)
            {
                foreach (Part p in tempD)
                {
                    p.Coordinates = new Point((partWidth / 2 + (partWidth * index)), p.Coordinates.Y);
                    ScatterViewItem partSVI = TreeViewScatterView.ItemContainerGenerator.ContainerFromItem(p) as ScatterViewItem;
                    partSVI.Center = p.Coordinates;
                    index++;
                }
            }
            else if (lastPoint.X >= TreeViewScatterView.ActualWidth)
            {
                foreach (Part p in tempD)
                {
                    p.Coordinates = new Point((TreeViewScatterView.ActualWidth - (partWidth / 2 + (partWidth*index))), p.Coordinates.Y);
                    ScatterViewItem partSVI = TreeViewScatterView.ItemContainerGenerator.ContainerFromItem(p) as ScatterViewItem;
                    partSVI.Center = p.Coordinates;
                    index++;
                }
            }
            else if (firstPoint.Y <= 0)
            {
                foreach (Part p in tempD)
                {
                    p.Coordinates = new Point(p.Coordinates.X, (partHeight / 2));
                    ScatterViewItem partSVI = TreeViewScatterView.ItemContainerGenerator.ContainerFromItem(p) as ScatterViewItem;
                    partSVI.Center = p.Coordinates;
                    index++;
                }
            }
            else if (firstPoint.Y >= TreeViewScatterView.ActualHeight)
            {
                foreach (Part p in tempD)
                {
                    p.Coordinates = new Point(p.Coordinates.X, (TreeViewScatterView.ActualHeight - (partHeight / 2)));
                    ScatterViewItem partSVI = TreeViewScatterView.ItemContainerGenerator.ContainerFromItem(p) as ScatterViewItem;
                    partSVI.Center = p.Coordinates;
                    index++;
                }
            }
        }


        private Point returnWithinBounds(Point outOfBounds)
        {
            
            Point newPoint = outOfBounds;
            if (outOfBounds.X < 0)
            {
                newPoint.X = outOfBounds.X + 5;
            }
            else if (outOfBounds.X > TreeViewScatterView.ActualWidth)
            {
                newPoint.X = outOfBounds.X - 5;
            }

            if (outOfBounds.Y < 0)
            {
                newPoint.Y = outOfBounds.Y + 5;
            }
            else if (outOfBounds.Y > TreeViewScatterView.ActualHeight)
            {
                newPoint.Y = outOfBounds.Y - 5;
            }

            return newPoint;
        }

        #endregion

        #endregion

        #region containermanipulation

        #region containermanipulationcompleted
        private void ScatterViewItem_ContainerManipulationCompleted(object sender, ContainerManipulationCompletedEventArgs e)
        {                        
            ScatterViewItem movedPart = sender as ScatterViewItem;
            Part p = movedPart.DataContext as Part;
            p.Coordinates = movedPart.Center;
            List<Part> tempDevice = DeviceSearch(p);

            double snapFieldX = movedPart.Width;
            double snapFieldY = movedPart.Height / 2;
            if (withinBounds(tempDevice, 0, TreeViewScatterView.ActualWidth, TreeViewScatterView.Height, 0))
            {
                for (int i = 0; i < TreeViewScatterView.Items.Count; i++)
                {
                    Part compareTo = TreeViewScatterView.Items.GetItemAt(i) as Part;

                    if (!compareTo.Equals(p))
                    {

                        if (p.Coordinates.X > (compareTo.Coordinates.X - snapFieldX) &&
                            p.Coordinates.X < compareTo.Coordinates.X &&
                            p.Coordinates.Y > (compareTo.Coordinates.Y - snapFieldY) &&
                            p.Coordinates.Y < (compareTo.Coordinates.Y + snapFieldY))
                        {
                            
                            if (p.checkTypes(compareTo) == true)
                            {
                                snappingDeviceSVIs(p, compareTo, "left");
                                snapping(p, compareTo);
                            }
                            else
                            {
                                p.BorderColor = Brushes.Gray;
                                compareTo.BorderColor = Brushes.Gray;
                            }

                        }
                        else
                        {
                            if (p.Coordinates.X < (compareTo.Coordinates.X + snapFieldX) &&
                                p.Coordinates.X > compareTo.Coordinates.X &&
                                p.Coordinates.Y > (compareTo.Coordinates.Y - snapFieldY) &&
                                p.Coordinates.Y < (compareTo.Coordinates.Y + snapFieldY))
                            {
                                
                                if (p.checkTypes(compareTo) == true)//snap
                                {
                                    
                                    snappingDeviceSVIs(p, compareTo, "right");
                                   
                                }
                                else
                                {
                                    p.BorderColor = Brushes.Gray;
                                    compareTo.BorderColor = Brushes.Gray;
                                }

                            }
                        }
                    }
                }
            }
            else
            {
                
                setWithinBounds(tempDevice);
                if (_lineDictionary.ContainsKey(p.LineKey))
                {
                    Line tempLine = _lineDictionary[p.LineKey];
                    tempLine.X1 = findMidpoint(tempDevice).X;
                    tempLine.Y1 = findMidpoint(tempDevice).Y;
                }
            }
        }
#endregion

        #region containermanipulationdelta

        private void ScatterViewItem_ContainerManipulationDelta(object sender, ContainerManipulationDeltaEventArgs e)
        {            
            ScatterViewItem movedPartSVI = sender as ScatterViewItem; //cast as svi
            Part movedPartDATA = movedPartSVI.DataContext as Part; //grab model of moved part
            List<Part> tempDevice = DeviceSearch(movedPartDATA); //grab device of part
                Point savedPointMovedPart = new Point(); //save new point
                savedPointMovedPart = movedPartDATA.Coordinates; //update model
                movedPartDATA.Coordinates = movedPartSVI.Center; //save new point to model
                double yDelta = savedPointMovedPart.Y - movedPartDATA.Coordinates.Y; //figure out delta
                double xDelta = savedPointMovedPart.X - movedPartDATA.Coordinates.X; //figure out delta

                //line update
                if (_lineDictionary.ContainsKey(movedPartDATA.LineKey))
                {
                    Line tempLine = _lineDictionary[movedPartDATA.LineKey];
                    tempLine.X1 = findMidpoint(tempDevice).X;
                    tempLine.Y1 = findMidpoint(tempDevice).Y;
                }

                //update coordinates of other parts in device (so that device moves as one) 
                foreach (Part temp in tempDevice)
                {
                    if (temp != movedPartDATA)
                    {
                        temp.Coordinates = new Point(temp.Coordinates.X - xDelta, temp.Coordinates.Y - yDelta);
                        for (int i = 0; i < TreeViewScatterView.Items.Count; i++)
                        {
                            ScatterViewItem cT = TreeViewScatterView.ItemContainerGenerator.ContainerFromIndex(i) as ScatterViewItem;
                            Part compareTo = TreeViewScatterView.Items.GetItemAt(i) as Part;
                            if (compareTo == temp)
                            {
                                cT.Center = compareTo.Coordinates;
                            }
                        }
                    }
                }

                sw1.MyFlowView.updateCanvas();
        }

        #endregion

        #region containermanipulationstarted

        private void ScatterViewItem_ContainerManipulationStarted(object sender, ContainerManipulationStartedEventArgs e)
        {
            ScatterViewItem s = e.OriginalSource as ScatterViewItem;
        }

        #endregion
        #endregion

        //event handler to bring up window for each part's properties
        private void Part_Click(object sender, RoutedEventArgs e)
        {
         
                ScatterView TreeView = this.Parent as ScatterView;
                
                SurfaceButton b = sender as SurfaceButton;
                Part p = b.DataContext as Part;
            
                PropertiesView pv = new PropertiesView(p);
             
                pv.Center = new Point(500, 500);
                TreeView.Items.Add(pv);
           
        }

        private void SnapRight_Click(object sender, RoutedEventArgs e)
        {

        }

        private void SnapLeft_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
