﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Surface;
using Microsoft.Surface.Presentation;
using Microsoft.Surface.Presentation.Controls;
using Microsoft.Surface.Presentation.Input;
using Eugenie.Model;
using System.ComponentModel;

namespace Eugenie.Views
{
    /// <summary>
    /// Interaction logic for UserControl1.xaml
    /// </summary>
    public partial class FlowView : ScatterViewItem
    {
        Dictionary<int, Line> _lineDictionary = new Dictionary<int, Line>();
        Dictionary<int, Ellipse> _ellipseDictionary = new Dictionary<int, Ellipse>();

        Point laststart = new Point();
        Point lastend = new Point();

        Part leftpart;
        Part rightpart;

        public SurfaceWindow1 sw1;

        int lasttimestamp = 0;
        
        
        public FlowView()
        {
            InitializeComponent();
        }

        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string propertyName)
        {
            var handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }
        public Part LeftPart
        {
            get { return leftpart; }
            set
            {
                leftpart = value;
                OnPropertyChanged("LeftPart");
            }
        }

        public Part RightPart
        {
            get { return rightpart; }
            set
            {
                rightpart = value;
                OnPropertyChanged("RightPart");
            }
        }


        #region SVI Touch Events
        private void ScatterViewItem_TouchDown(object sender, TouchEventArgs e)
        {            
            Point currentFingerPt = e.TouchDevice.GetCenterPosition(this);
            ScatterViewItem s = sender as ScatterViewItem;

  
            LeftPart = s.Content as Part;

            lasttimestamp = e.Timestamp;
            laststart = e.GetTouchPoint(PermanentCanvas).Position;

        }

        private void ScatterViewItem_PreviewTouchMove(object sender, TouchEventArgs e)
        {
            ScatterViewItem s = sender as ScatterViewItem;
            s.Background = Brushes.Black;
            TouchMoveFeedback(e);
        }

        private void ScatterViewItemPreviewTouchUp(object sender, TouchEventArgs e)
        {
            ScatterViewItem s = sender as ScatterViewItem;
            s.Background = Brushes.Red;

            IInputElement ii = FlowViewScatterView.InputHitTest(e.GetTouchPoint(PermanentCanvas).Position);
            try
            {
                Border b = (Border)ii;
                Decorator d = b as Decorator;
                Grid g = d.Child as Grid;
                Panel p = g as Panel;
                FrameworkElement f = p as FrameworkElement;
                rightpart = f.DataContext as Part;
            }
            catch (Exception ex) { }

            try
            {
                Image i = (Image)ii;
                FrameworkElement f = i as FrameworkElement;
                rightpart = f.DataContext as Part;

            }
            catch (Exception ex) { }

            if (leftpart != null && rightpart != null && rightpart != leftpart)
            {
                Relationship relation = new Relationship(leftpart, Relationship.relation.represses, rightpart);

                foreach (Relationship rule in sw1.rules)
                {
                    if (rule.ToString().Equals(relation.ToString()))
                    {
                        RightPart = null;
                        LeftPart = null;
                        return;
                    }

                }
                sw1.rules.Add(relation);
                
                sw1.MyCodeView.code.Text = sw1.generateEugene();
                Line l = new Line();
                l.X1 = laststart.X;
                l.Y1 = laststart.Y;
                l.X2 = e.GetTouchPoint(PermanentCanvas).Position.X;
                l.Y2 = e.GetTouchPoint(PermanentCanvas).Position.Y;

                _lineDictionary.Add(e.Timestamp, l);

                s.Background = Brushes.Red;

                RightPart = null;
                LeftPart = null;
            }
        }

        private void ScatterViewItem_TouchLeave(object sender, TouchEventArgs e)
        {
            ScatterViewItem s = sender as ScatterViewItem;
            s.Background = Brushes.Red;

            IInputElement ii = FlowViewScatterView.InputHitTest(e.GetTouchPoint(PermanentCanvas).Position);
            try
            {
                Border b = (Border)ii;
                Decorator d = b as Decorator;
                Grid g = d.Child as Grid;
                Panel p = g as Panel;
                FrameworkElement f = p as FrameworkElement;
                rightpart = f.DataContext as Part;
            }
            catch (Exception ex) { }

            try
            {
                Image i = (Image)ii;
                FrameworkElement f = i as FrameworkElement;
                rightpart = f.DataContext as Part;

            }
            catch (Exception ex) { }

            if (leftpart != null && rightpart != null && rightpart != leftpart)
            {
                Relationship relation = new Relationship(leftpart, Relationship.relation.represses, rightpart);

                foreach (Relationship rule in sw1.rules)
                {
                    if (rule.ToString().Equals(relation.ToString()))
                    {
                        RightPart = null;
                        LeftPart = null;
                        return;
                    }

                }
                sw1.rules.Add(relation);
                sw1.MyCodeView.code.Text = sw1.generateEugene();
                Line l = new Line();
                l.X1 = laststart.X;
                l.Y1 = laststart.Y;
                l.X2 = e.GetTouchPoint(PermanentCanvas).Position.X;
                l.Y2 = e.GetTouchPoint(PermanentCanvas).Position.Y;

                _lineDictionary.Add(e.Timestamp, l);

                s.Background = Brushes.Red;

                RightPart = null;
                LeftPart = null;
            }


        }

        #endregion

        #region Mouse Events

        private void FlowViewScatterView_SourceUpdated(object sender, DataTransferEventArgs e)
        {
            ScatterViewItem svi =
            FlowViewScatterView.ItemContainerGenerator.ContainerFromItem(e.Source) as ScatterViewItem;

            e.Handled = true;
        }


        private void ScatterViewItem_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            Point currentFingerPt = e.Device.GetCenterPosition(this);
            ScatterViewItem s = sender as ScatterViewItem;
            LeftPart = s.Content as Part;

            lasttimestamp = e.Timestamp;
            laststart = e.GetPosition(PermanentCanvas);
        }

        private void ScatterViewItem_PreviewMouseMove(object sender, MouseEventArgs e)
        {
            ScatterViewItem s = sender as ScatterViewItem;
        }

        private void ScatterViewItem_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            ScatterViewItem s = sender as ScatterViewItem;
            IInputElement ii = FlowViewScatterView.InputHitTest(e.GetPosition(FlowViewScatterView));
            try
            {
                Border b = (Border)ii;
                Decorator d = b as Decorator;
                Grid g = d.Child as Grid;
                Panel p = g as Panel;
                FrameworkElement f = p as FrameworkElement;
                rightpart = f.DataContext as Part;
            }
            catch (Exception ex)
            {

            }

            try
            {
                Image i = (Image)ii;
                FrameworkElement f = i as FrameworkElement;
                rightpart = f.DataContext as Part;

            }catch (Exception ex){}

            if (leftpart != null && rightpart != null && rightpart!=leftpart )
            {
                optionpane.Visibility = Visibility.Visible;

                lastend = e.GetPosition(PermanentCanvas);
                lasttimestamp = e.Timestamp;
            }

           
        }

        #endregion


        #region Feedback & Drawing Helper Methods

        private void DrawFeedbackLine(Point start, Point end, int touchId)
        {
            //Make line for UI Feedback
            Line myLine = new Line();
            myLine.StrokeThickness = 4;
            myLine.Stroke = System.Windows.Media.Brushes.DarkGray;

            //Place Line start & end
            myLine.X1 = start.X;
            myLine.Y1 = start.Y;
            myLine.X2 = end.X;
            myLine.Y2 = end.X;

            //Save line & add to feedback canvas
            _lineDictionary.Add(touchId, myLine);
            TempCanvas.Children.Add(myLine);
        }

        private void DrawFeedbackEllipse(Point touchPt, int touchId)//Needs point from a touch
        {
            //add an ellipse where the contact appeared
            Ellipse myEllipse = new Ellipse();
            myEllipse.RenderTransformOrigin = new Point(0.5, 0.5);
            myEllipse.Width = 80;
            myEllipse.Height = myEllipse.Width;

            RadialGradientBrush gradient = new RadialGradientBrush();

            GradientStop color1 = new GradientStop();
           color1.Color = Color.FromArgb(0xFF, 0x00, 0xFF, 0x00);
            color1.Offset = 0.0;
            gradient.GradientStops.Add(color1);

            GradientStop color2 = new GradientStop();
            color2.Color = Color.FromArgb(0x00, 0x00, 0xFF, 0x00);
            color2.Offset = 1.0;
            gradient.GradientStops.Add(color2);

            myEllipse.Fill = gradient;

            //Save ellipse for future ref
            _ellipseDictionary.Add(touchId, myEllipse);

            //Add ellipse to feedback canvas
            TempCanvas.Children.Add(myEllipse);

            Canvas.SetLeft(myEllipse, touchPt.X - 40);
            Canvas.SetTop(myEllipse, touchPt.Y - 40);
        }

        private void TouchMoveFeedback(TouchEventArgs e)
        {
            //Check if the touch has an ellipse
            //update ellipse to track contact

            if (_ellipseDictionary.ContainsKey(e.TouchDevice.Id)) 
            {
                Canvas.SetLeft(_ellipseDictionary[e.TouchDevice.Id], e.GetTouchPoint(this).Position.X - 40); ;
                Canvas.SetTop(_ellipseDictionary[e.TouchDevice.Id], e.GetTouchPoint(this).Position.Y - 40);
            }

            //Check if touch has a line
            //Draw line to track touch

            if (_lineDictionary.ContainsKey(e.TouchDevice.Id))
            {
                _lineDictionary[e.TouchDevice.Id].X2 = e.GetTouchPoint(this).Position.X;
                _lineDictionary[e.TouchDevice.Id].Y2 = e.GetTouchPoint(this).Position.Y;
            }

          }

        private void MouseMoveFeedback(MouseEventArgs e)
        {
            //Check if the touch has an ellipse
            //update ellipse to track contact

            try
            {
                if (_ellipseDictionary.ContainsKey(e.Timestamp))
                {
                    Canvas.SetLeft(_ellipseDictionary[e.Timestamp], e.GetPosition(this).X - 40); ;
                    Canvas.SetTop(_ellipseDictionary[e.Timestamp], e.GetPosition(this).Y - 40);
                }

                //Check if touch has a line
                //Draw line to track touch

                if (_lineDictionary.ContainsKey(e.Timestamp))
                {
                    _lineDictionary[e.Timestamp].X2 = e.GetPosition(this).X;
                    _lineDictionary[e.Timestamp].Y2 = e.GetPosition(this).Y;
                }
            }
            catch (Exception Message)
            {
                Console.WriteLine(Message.Message);
            }

        }

        private void TouchUpFeedback(TouchEventArgs e) //figure out what was being touched at start and end and draw repression line there
        {            
            
            RelationLine rp = new RelationLine();

            PermanentCanvas.Children.Add(rp);
            
            try
            {
                Canvas.SetLeft(rp, _lineDictionary[e.TouchDevice.Id].X1);//tp.First().Position.X);
                
                Canvas.SetTop(rp, _lineDictionary[e.TouchDevice.Id].Y1);//tp.Last().Position.Y);

                rp.Width = _lineDictionary[e.TouchDevice.Id].X2 - _lineDictionary[e.TouchDevice.Id].X1;
            }
            catch (Exception Message)
            {
                Console.WriteLine(Message.Message);
            }
        }

        private void MouseUpFeedback(object sender, MouseEventArgs e) //figure out what was being touched at start and end and draw repression line there
        {
            
            RelationLine rp = new RelationLine();

            try
            {
                PermanentCanvas.Children.Add(rp);
                

                Line l = _lineDictionary[e.Timestamp];
                double setleft = (l.X1 < l.X2 ? l.X1 : l.X2);
                double settop = (l.Y1 < l.Y2 ? l.Y1 : l.Y2);

                Canvas.SetLeft(rp, setleft);//tp.First().Position.X);
               
                double width =Math.Abs(l.X1 - l.X2);
                rp.linegrid.Width = width;
                double height = 59 * width / 249;

                Canvas.SetTop(rp, settop - 50 - height);

                if (l.X1 > l.X2)
                    rp.flip();


            }
            catch (Exception Message)
            {
                Console.WriteLine(Message.Message);
            }
        }

        #endregion

        public void updateCanvas()
        {

            PermanentCanvas.Children.Clear();
            foreach (Relationship r in sw1._relationships)
            {
                
                    RelationLine rl = new RelationLine();

                   
                    if (r.Relation == Relationship.relation.then)
                        rl.thenline.Visibility = Visibility.Visible;
                    else if (r.Relation == Relationship.relation.represses)
                        rl.repressionline.Visibility = Visibility.Visible;
                    else if (r.Relation == Relationship.relation.and)
                        rl.andline.Visibility = Visibility.Visible;
                    else if (r.Relation == Relationship.relation.xor)
                        rl.xorline.Visibility = Visibility.Visible;
                    else if (r.Relation == Relationship.relation.or)
                        rl.orline.Visibility = Visibility.Visible;
                  

                    PermanentCanvas.Children.Add(rl);

                    try
                    {
                        Canvas.SetLeft(rl, (r.Left.Coordinates.X < r.Right.Coordinates.X ? r.Left.Coordinates.X  : r.Right.Coordinates.X  ));//tp.First().Position.X);
                      
                        Canvas.SetTop(rl, (r.Left.Coordinates.Y < r.Right.Coordinates.Y ? r.Left.Coordinates.Y - 100 : r.Right.Coordinates.Y - 100));//tp.Last().Position.Y);

                        if (r.Left.Coordinates.X > r.Right.Coordinates.X)
                            rl.flip();

                        rl.Width = Math.Abs(r.Left.Coordinates.X - r.Right.Coordinates.X);

                    }
                    catch (Exception e)
                    {
                    }



            }
        }

        private void makeSelection(object sender, RoutedEventArgs e)
        {
            if (leftpart != null && rightpart != null)
            {

                Relationship.relation r = Relationship.relation.represses;

                       if ((bool)Repressess.IsChecked)
                        r = Relationship.relation.represses;
                   
                   


                Relationship relation = new Relationship(leftpart, r, rightpart);

                //prevents adding dup rules
                foreach (Relationship rule in sw1.rules) 
                {
                    if (rule.ToString().Equals(relation.ToString()))
                    {
                        RightPart = null;
                        LeftPart = null;
                        return;
                    }

                }


                sw1.rules.Add(relation);
                sw1.MyCodeView.code.Text = sw1.generateEugene();
                Line l = new Line();
                l.X1 = laststart.X;
                l.Y1 = laststart.Y;
                l.X2 = lastend.X;
                l.Y2 = lastend.Y;

                _lineDictionary.Add(lasttimestamp, l);
                updateCanvas();


            }

            optionpane.Visibility = Visibility.Hidden;

            RightPart = null;
            LeftPart = null;
        }

        private void cancelButton_Click(object sender, RoutedEventArgs e)
        {
            optionpane.Visibility = Visibility.Hidden;

            RightPart = null;
            LeftPart = null;
        }

        private void SnapLeft_Click(object sender, RoutedEventArgs e)
        {

        }

        private void SnapRight_Click(object sender, RoutedEventArgs e)
        {

        }

        
        
    }
}
