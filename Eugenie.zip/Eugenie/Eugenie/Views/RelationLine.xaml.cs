﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Eugenie.Views
{
    /// <summary>
    /// Interaction logic for RelationLine.xaml
    /// </summary>
    public partial class RelationLine : UserControl
    {
        public RelationLine()
        {
            InitializeComponent();
        }

        public void flip()
        {
            linegrid.RenderTransformOrigin = new Point(.5, .5);
            ScaleTransform scale = new ScaleTransform(-1, 1);
            linegrid.RenderTransform = scale;
        }
    }
}
