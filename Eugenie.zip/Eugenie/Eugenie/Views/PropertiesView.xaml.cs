﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Surface;
using Microsoft.Surface.Presentation;
using Microsoft.Surface.Presentation.Controls;
using Microsoft.Surface.Presentation.Input;
using System.Windows.Forms.Integration;
using System.Windows.Forms;
using Eugenie.Model;
using System.ComponentModel;

namespace Eugenie.Views
{
    /// <summary>
    /// Interaction logic for PropertiesView.xaml
    /// </summary>
    public partial class PropertiesView : ScatterViewItem, INotifyPropertyChanged
    {
     
       

        private int _length;
        private string _lengthstring;
        private string _name;
        private string _regDataSheetString;
        private RegDataSheet _regDataSheet;
        private Part _myPart;
        private string _partAuthor;
        private string _description;
        private string _availability;
        private string _usefulness;
        private string _sequence;
        private string _twins;
        private string _direction;
        
    

        public RegDataSheet RegDataSheet
        {
            get
            { return _regDataSheet; }
            set 
            { _regDataSheet = value; }
        }


        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string propertyName)
        {
            var handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }

     

        public PropertiesView(Part p)
        {
            DataContext = this;
            _myPart = new Part(p.Name, p.Represses, p.RepressedBy, p.Induces, p.InducedBy, p.Direction);
            InitializeComponent();
            //EditProperties();

            //for data sheet
            if(p.Name.Contains("Generic"))
            {
                _regDataSheet = new RegDataSheet();
            } else
            {
           
                _regDataSheet = new RegDataSheet(p);
            }
            _regDataSheetString = _regDataSheet.ToString();
            PartInfoString = _regDataSheetString;

            //part length
            _length = _regDataSheet.BasicInfo.Length;
            Console.WriteLine(_length);
            _lengthstring = _length.ToString();
            Length = _lengthstring;

            //part direction
   
                  _direction = _regDataSheet.BasicInfo.Direction;
                  Console.WriteLine(_myPart.Direction);
                  Direction = _myPart.Direction;
              
            
            //part twins
            _twins = _regDataSheet.BasicInfo.Twins;
            Console.WriteLine(_twins);
            Twins = _twins;

            //part author
            _partAuthor = _regDataSheet.BasicInfo.PartAuthor;
            PartAuthor = _partAuthor;

            //part description
            _description = _regDataSheet.BasicInfo.DescriptionName;
            Description = _description;

            //part usefulness
            _usefulness = _regDataSheet.BasicInfo.Usefulness;
            Usefulness = _usefulness;

            //part availability
            _availability = _regDataSheet.BasicInfo.Availability;
            Availability = _availability;

            
        }



        #region accessors

        public Part MyPart
        {
            get { return _myPart; }
            set { _myPart = value; }
        }


        public string Twins
        {
            get { return _twins; }
            set
            {
                _twins = value;
                OnPropertyChanged("Twins");
            }
        }

        public string PartInfoString
        {
            get
            {
                return _regDataSheetString;
                
            }
            set
            {
                _regDataSheetString = value;
                OnPropertyChanged("PartInfoString");
                
            }

        }

          public string Length
        {
            get { return _lengthstring; }
            set
            {
                _lengthstring = value;
                OnPropertyChanged("Length");
                
            }
        }


          public string PartAuthor
          {
              get { return _partAuthor; }
              set
              {
                  _partAuthor = value;
                  OnPropertyChanged("PartAuthor");
                  
              }
          }

          public string Description
          {
              get { return _description; }
              set
              {
                  _description = value;
                  OnPropertyChanged("Description");
                  
              }
          }

          public string Availability
          {
              get { return _availability; }
              set
              {
                  _description = value;
                  OnPropertyChanged("Availability");
                  
              }
          }

          public string Usefulness
          {
              get { return _usefulness; }
              set
              {
                  _description = value;
                  OnPropertyChanged("Usefulness");
                  
              }
          }

          public string Direction
          {
              get { return _direction; }
              set
              {
                  _myPart.Direction = value;
                  OnPropertyChanged("Direction");
                  
             
              }
          }

          public string Represses
          {
              get { return _myPart.Represses; }
              set
              {
                  _myPart.Represses = value;
                  OnPropertyChanged("Represses");
                  
              }
          }

          public string RepressedBy
          {
              get { return _myPart.RepressedBy; }
              set
              {
                  _myPart.RepressedBy = value;
                  OnPropertyChanged("RepressedBy");
                  PartRepressedBy.Text = value;
                
              }
          }

          public string Induces
          {
              get { return _myPart.Induces; }
              set
              {
                  _myPart.Induces = value;
                  OnPropertyChanged("Induces");
                 
              }
          }

          public string InducedBy
          {
              get { return _myPart.InducedBy; }
              set
              {
                  _myPart.InducedBy = value;
                  OnPropertyChanged("InducedBy");
                  
              }
          }

        #endregion
          
        
        #region event handlers

          private void Represses_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key.Equals(Key.Enter))
                _myPart.Represses = PartRepresses.Text;
            
        }

        private void RepressedBy_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key.Equals(Key.Enter))
                _myPart.RepressedBy = PartRepressedBy.Text;
        }

        private void Induces_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key.Equals(Key.Enter))
                _myPart.Induces = PartInduces.Text;
        }

        private void InducedBy_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key.Equals(Key.Enter))
                _myPart.InducedBy = PartInducedBy.Text;
        }
        private void EditName_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {

            if (e.Key.Equals(Key.Enter))
                _myPart.Name = EditName.Text;
        }

        private void OKbutton_Click(object sender, RoutedEventArgs e)
        {
            _myPart.Represses = PartRepresses.Text;
            _myPart.RepressedBy = PartRepressedBy.Text;
            _myPart.Induces = PartInduces.Text;
            _myPart.InducedBy = PartInducedBy.Text;
            _myPart.Name = EditName.Text;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            PartRepresses.Text = "";
            PartRepressedBy.Text = "";
            PartInduces.Text = "";
            PartInducedBy.Text = "";
        }

        private void Donebutton_Click(object sender, RoutedEventArgs e)
        {
            Popup.Visibility = Visibility.Hidden;
        }

  

          #endregion




       

        

        public override string ToString()
        {
            string temp = _regDataSheetString;
            return temp;
        }

        private void PartForward_Checked(object sender, RoutedEventArgs e)
        {
            _myPart.Direction = "forward";
                Direction = _myPart.Direction;
               
                OnPropertyChanged("Direction");
                PartDirection.Text = _myPart.Direction;
            
                Console.WriteLine(_myPart.Direction);
        }

        private void PartReverse_Checked(object sender, RoutedEventArgs e)
        {
            _myPart.Direction = "reverse";
            Direction = _myPart.Direction;
                OnPropertyChanged("Direction");
                PartDirection.Text = _myPart.Direction;
                Console.WriteLine(_myPart.Direction);
               
        }

        private void PartBidirectional_Checked(object sender, RoutedEventArgs e)
        {
            _myPart.Direction = "bidirectional";
            Direction = _myPart.Direction;
            OnPropertyChanged("Direction");
            PartDirection.Text = _myPart.Direction;
            Console.WriteLine(_myPart.Direction);
        }

        
        }

        



    }


