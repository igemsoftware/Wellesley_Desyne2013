﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Surface;
using Microsoft.Surface.Presentation;
using Microsoft.Surface.Presentation.Controls;
using Microsoft.Surface.Presentation.Input;

namespace Eugenie.Views
{

    #region default
    /// <summary>
    /// Interaction logic for CodeView.xaml
    /// </summary>
    public partial class CodeView : ScatterViewItem
    {
        public CodeView()
        {
            InitializeComponent();
        }
    

    #endregion

    #region snapping

    //vars
        private Point left;
        private Point right;
        private double snapThreshold;
        private double snapThreshold_flow;
        public static SurfaceWindow1 sw1;

        private void CodeView_ContainerManipulationCompleted(object sender, ContainerManipulationCompletedEventArgs e)
        {
            ScatterViewItem CV = (ScatterViewItem)sender;
            //If its center is within the threshold of low.Y or high.Y or L2
            if (CV.Center.Y < left.Y + snapThreshold)
                CV.Center = new Point(right.X, left.Y);
            if (CV.Center.Y > right.Y - snapThreshold)
                CV.Center = new Point(right.X, right.Y);
            if (CV.Center.Y > (sw1.MyFlowView.Center.Y - snapThreshold_flow))
                CV.Center = new Point(right.X, sw1.MyFlowView.Center.Y - snapThreshold_flow);
        }





    #endregion

        private void SnapLeft_Click(object sender, RoutedEventArgs e)
        {
            this.Center = new Point(right.X, left.Y);
        }

        private void SnapRight_Click(object sender, RoutedEventArgs e)
        {
            this.Center = new Point(right.X, left.Y);
        }
    }
}
