﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Surface;
using Microsoft.Surface.Presentation;
using Microsoft.Surface.Presentation.Controls;
using Microsoft.Surface.Presentation.Input;
using Eugenie.Model;

namespace Eugenie.Views
{
    /// <summary>
    /// Interaction logic for DesignPartsView.xaml
    /// </summary>
    public partial class DesignPartsView : ScatterViewItem
    {
        public SurfaceWindow1 sw1;
        public DesignPartsView()
        {
            InitializeComponent();
        }

        private void DragSource_DragCompleted(object sender, SurfaceDragCompletedEventArgs e)
        {
        }


        private void DragSource_PreviewTouchDown(object sender, TouchEventArgs e)
        {
            FrameworkElement findSource = e.OriginalSource as FrameworkElement;
            SurfaceListBoxItem draggedElement = null;

            // Find the ScatterViewitem object that is being touched.
            while (draggedElement == null && findSource != null)
            {
                if ((draggedElement = findSource as SurfaceListBoxItem) == null)
                {
                    findSource =
                     VisualTreeHelper.GetParent(findSource) as FrameworkElement;
                }
            }

            if (draggedElement == null)
            {
                return;
            }

            Part data = draggedElement.Content as Part;

            if (data == null || !data.CanDrag)
            {
                return;
            }

            data.DraggedElement = draggedElement;



            // Create the cursor visual
            ContentControl cursorVisual = new ContentControl()
            {
                Content = draggedElement.DataContext,
                Style = FindResource("CursorStyle") as Style
            };

            //Enable the application to change the visual cues.
            SurfaceDragDrop.AddTargetChangedHandler(cursorVisual, OnTargetChanged);
            SurfaceDragDrop.AddPreviewDragEnterHandler(cursorVisual, DropTarget_DragEnter);

            // Create a list of input devices. Add the touches that
            // are currently captured within the dragged element and
            // the current touch (if it isn't already in the list).
            List<InputDevice> devices = new List<InputDevice>();
            devices.Add(e.TouchDevice);
            foreach (InputDevice touch in draggedElement.TouchesCapturedWithin)
            {
                if (touch != e.TouchDevice)
                {
                    devices.Add(touch);
                }
            }

            ItemsControl dragSource = ItemsControl.ItemsControlFromItemContainer(draggedElement);



            SurfaceDragCursor startDragOkay =

            SurfaceDragDrop.BeginDragDrop(
                          dragSource,                     // The ScatterView object that the cursor is dragged out from.
                          draggedElement,                 // The ScatterViewItem object that is dragged from the drag source.
                          cursorVisual,                   // The visual element of the cursor.
                          draggedElement.DataContext,     // The data attached with the cursor.
                          devices,                        // The input devices that start dragging the cursor.
                          DragDropEffects.Move);          // The allowed drag-and-drop effects of this operation.


            if (startDragOkay != null)
            {
                //this element has been handled
                e.Handled = true;
            }
        }


        private void OnTargetChanged(object sender, TargetChangedEventArgs e)
        {
            if (e.Cursor.CurrentTarget != null)
            {
                Part data = e.Cursor.Data as Part;
                e.Cursor.Visual.Tag = (data.CanDrop) ? "CanDrop" : "CannotDrop";
            }
            else
            {
                e.Cursor.Visual.Tag = null;
            }
        }


        private void DropTarget_DragEnter(object sender, SurfaceDragDropEventArgs e)
        {

            ScatterView svi = sender as ScatterView;
            string temp = svi.Name;
            Part data = e.Cursor.Data as Part;
            if (!data.CanDrop)
            {
                e.Effects = DragDropEffects.None;
            }
            else
            {
                e.Effects = DragDropEffects.Move;
            }
        }


        private void DropTarget_DragLeave(object sender, SurfaceDragDropEventArgs e)
        {
            e.Cursor.Visual.Tag = null;
        }


        private void DropTarget_DragCompleted(object sender, SurfaceDragCompletedEventArgs e)
        {
                e.Handled = true;
        }

        private void DropTarget_Drop(object sender, DragEventArgs e)
        {

        }


    }
}
