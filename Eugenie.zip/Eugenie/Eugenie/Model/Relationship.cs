﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace Eugenie.Model
{
    //contains relationships between parts as defnied by the eugene rule set, found at http://eugene.sourceforge.net/documentation.html
    public class Relationship : INotifyPropertyChanged
    {
        public enum relation { contains, after, before, startsWith,
            endsWith, with, then, nextTo, equalTo, notEqualTo, 
            lessThan, greaterThan, greaterThanOrEqualTo, lessThanOrEqualTo,
            represses, and, or, xor
        };

        relation relatesBy;
        Part left;
        Part right;

        public relation Relation {

            get
            {
                return relatesBy;
            }
            set { 
                relatesBy=value;
            }
        }

        public Part Left
        {
            get
            { return left; }
            set
            { left = value; }

        }


        public Part Right

        {
            get
            { return right; }
            set
            { right = value; }

        }



        public Relationship(Part leftPart, relation relatedBy, Part rightPart)
        {
            left = leftPart;
            right = rightPart;
            relatesBy = relatedBy;
        }

        public override string ToString()
        {
            //return left.Name + " " + relatesBy.ToString().ToUpper() +" " + right.Name;
            if (relatesBy == Relationship.relation.represses)
            {
                return left.eugenename+".Represses == " + right.eugenename+".Name";
            }

            return left.eugenename + " " + relatesBy.ToString().ToUpper() + " " + right.eugenename;
        }



        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string propertyName)
        {
            var handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
