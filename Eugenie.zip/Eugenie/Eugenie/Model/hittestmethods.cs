﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Media;
using System.Windows;

namespace Eugenie.Model
{
    class hittestmethods
    {

        public static Part getPart(HitTestResult htr)
        {
            Part p = new Part("", true, true) ;

            foreach (object child in LogicalTreeHelper.GetChildren(htr.VisualHit))
            {
                if ((child as Part) != null)
                {
                    p = child as Part;
                    if (!p.Name.Equals(""))
                        return p;
                }
                else
                    p = getParthelper(child); 
            }
 

            return p;
        }

        public static Part getParthelper(object o)
        {
            Part p = new Part("", true, true);

            foreach (object child in LogicalTreeHelper.GetChildren(o as FrameworkElement))
            {
                if ((child as Part) != null)
                {
                    p = child as Part;
                    if(!p.Name.Equals(""))
                        return p;
                }
                else
                    p = getParthelper(child); 
            }


            return p;
        }
    }
}
