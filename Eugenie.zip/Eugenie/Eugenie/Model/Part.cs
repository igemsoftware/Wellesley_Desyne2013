﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Windows;
using System.Windows.Media.Imaging;
using System.Windows.Media;
using Eugenie.Views;

namespace Eugenie.Model
{
    public class Part : INotifyPropertyChanged
    {

        private string name;
        private string type;
        private bool canDrop;
        private bool canDrag;
        private string represses;
        private string repressedBy;
        private string induces;
        private string inducedBy;
        private string direction;
        private Point coordinates;
        private BitmapImage image;
        private string partCategory;
        private Brush borderColor = Brushes.Gray;

        public string idPart;
        private int lineKey;

        public string description;
        public string format;
        public string sequence;
        public string riskGroup;

        public int morethan; 
        public string eugenename;
         public PropertiesView pv1;
      

        
        #region Accessors

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public string Type
        {
            get { return type; }
            set { type = value; }
        }

        public string PartCategory
        {
            get { return partCategory; }
            set 
            { 
                partCategory = value; 
      
            }
        }

        public string Represses
        {
            get { return represses; }
            set 
            { 
                represses = value;
                OnPropertyChanged("Represses");
                Console.WriteLine("InducedByChanged");
            }
        }

        public string RepressedBy
        {
            get { return repressedBy; }
            set 
            { 
                repressedBy = value;
                OnPropertyChanged("RepressedBy");
                Console.WriteLine("RepressedByChanged"+repressedBy);
                
            }
        }

        public string Induces
        {
            get { return induces; }
            set 
            {
                induces = value;
                OnPropertyChanged("Induces");
                Console.WriteLine("Induces");
            }
        }

        public string InducedBy
        {
            get { return inducedBy; }
            set
            {
                inducedBy = value;
                OnPropertyChanged("InducedBy");
                Console.WriteLine("InducedByChanged");
            }
        }


        
        public string Direction
        {
            get 
            { 
                return direction;
            }
            set
            {
                direction = value;
                OnPropertyChanged("Direction");
            }
        }




        public bool CanDrag
        {
            get { return canDrag; }
        }

        public bool CanDrop
        {
            get { return canDrop; }

        }

        public object DraggedElement
        {
            get;
            set;
        }

        public string getType
        {
            get { return type; }
        }

        
        public BitmapImage PartImage
        {
            get
            {
                image = new BitmapImage();
                image.BeginInit();
                if (this.type == "Promoter" || this.type== "Promoter2")
                {
                    image.UriSource = new Uri("/Resources/sbol_prom.bmp", UriKind.Relative);
                }
                else if (this.type == "RBS" || this.type == "RBS2")
                {
                    image.UriSource = new Uri("/Resources/sbol_rbs.png", UriKind.Relative);
                }
                else if (this.type == "CDS" || this.type == "CDS2")
                {
                    image.UriSource = new Uri("/Resources/sbol_cds.png", UriKind.Relative);
                }
                else if (this.type == "Terminator" || this.type == "Terminator2")
                {
                    image.UriSource = new Uri("/Resources/sbol_term.png", UriKind.Relative);
                }
                else
                {
                    image.UriSource = new Uri("/Resources/icon.png", UriKind.Relative);
                }
                image.EndInit();
                return image;


            }
            set { image = value; }

        }

        public Brush BorderColor
        {
            get { return borderColor; }
            set 
            {   
                borderColor = value;
                OnPropertyChanged("BorderColor");
            }

        }

        public int LineKey
        {
            get { return lineKey; }
            set
            {
                lineKey = value;
                OnPropertyChanged("LineKey");
            }
        }

        

#endregion


   

        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string propertyName)
        {
            var handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }

       
        //currently using this constructor
        public Part(string name, string type, string partCategory, string direction, bool canDrag, bool canDrop)
        {
            this.name = name;
            this.type = type;
            this.canDrag = canDrag;
            this.canDrop = canDrop;
            this.partCategory = partCategory;
            this.direction = direction;
   
        }

        public Part(string name, bool canDrag, bool canDrop)
        {
            this.name = name;
            this.canDrag = canDrag;
            this.canDrop = canDrop;
        }

        public Part(Point myCenter)
        {
            this.coordinates = myCenter;
        }

        //constructor that takes repressed/induced information
        public Part(string _name, string _represses, string _repressedBy, string _induces, string _inducedBy, string _direction)
        {
            name = _name;
            represses = _represses;
            repressedBy = _repressedBy;
            induces = _induces;
            inducedBy = _inducedBy;
            direction = _direction;
           
            
           
        }

        public Point Coordinates
        {
            get { return coordinates; }
            set 
            { 
                coordinates = value;
                OnPropertyChanged("Coordinates");
            }
        }

        public Part clonePart
        {
            get
            {
             
                Part newPart = new Part(this.name, this.type, this.partCategory, this.direction, this.canDrag, this.canDrop);
                return newPart;
            }

        }

        public Part clonePart1
        {
            get
            {

                Part newPart = new Part(this.name, this.represses, this.repressedBy, this.induces, this.inducedBy, this.direction);
                return newPart;
            }

        }

        public bool checkTypes(Part compareTo)
        {
                string t1 = this.type;
                string t2 = compareTo.getType;
                return (t1 != t2);
        }

        new public string ToString
        {
            
            get {
            string str = "Part Name: " + this.name;
            return str; }
           
        }
        
       



    }
   
}
        