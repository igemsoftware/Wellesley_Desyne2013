//FILE NAME: javascript.js
//WRITTEN BY: 
//DATE: 2013
//PURPOSE: Javascript

var msg = "Bac to the Future";
var secondcolor = "#00FFCC";
var flashspeed = 800;  //in milliseconds

// Vars for interval functions
var plasmidInsertion, dnaInsertion, tickCall;

/*
var JDictionary = {
"a" : "AAA",
"b" : "AAC",
"c" : "AAG",
"d" : "AAT",
"e" : "ACA"
};
*/

var Alphabet = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p",
"q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "A", "B", "C", "D", "E", "F", "G", "H", "I",
"J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "1", "2",
"3", "4", "5", "6", "7", "8", "9", "0", " ", " . "];

var Dictionary = ["AAA", "AAC", "AAG", "AAT", "ACA", "ACC", "ACG", "ACT", "AGA", "AGC", "AGG",
"AGT", "ATA", "ATC", "ATG", "ATT", "CAA", "CAC", "CAG", "CAT", "CCA", "CCC", "CCG", "CCT", "CGA",
"CGC", "CGG", "CGT", "CTA", "CTC", "CTG", "CTT", "GAA", "GAC", "GAG", "GAT", "GCA", "GCC", "GCG",
"GCT", "GGA", "GGC", "GGG", "GGT", "GTA", "GTC", "GTG", "GTT", "TAA", "TAC", "TAG", "TAT", "TTC",
"TCA", "TCC", "TCG", "TCT", "TGA", "TGC", "TGG", "TGT", "TTA", "TTG", "TTT"];


function writeMsg() {
	var newhtml = "";
	for (var i=0; i < msg.length; i++)
        newhtml += '<span id="neonlight'+i+'">' + msg.charAt(i) + "</span>";
    $('#message:first-child').replaceWith('<span id=mssg><h3>' + newhtml + '</h3></span>');
}

function encode() {
	document.getElementById("step-1").style.color = "#00FFCC";
	var t = toCodon(msg);
	drawDNA(t);
}

function toCodon(string) {
	var t = "";
	var index = -1;	
	for (var i = 0; i < string.length; i++) {
		index = getIndex(string.charCodeAt(i));
			if (index != -1)
				t = t.concat(Dictionary[index]);
			else 
				t = t.concat("TTG");
	}
	return t;
}

var n = 0;
function translate() {
	//Change all letters to second color
	if (n < msg.length) {
	    index = getIndex(msg.charCodeAt(n));
        document.getElementById("neonlight"+n).style.color = secondcolor;
        document.getElementById("d"+index).style.color = secondcolor;
        n++;
    } 
}

// Converts unicode index of msg char to Dictionary array index
function getIndex(num) {
    if (num >= 65 && num <= 90 ) {
        return num - 38;
    } else if (num >= 97 && num <= 122) {
        return num - 97;
    } else if (num >= 48 && num <= 57) {
        return num - 12;
    } else if (num == 32) {
        return 62;
    } else if (num == 46) {
        return 63;
    } else {
        return -1;
    }
}

function writeRow(startIndex, endIndex) {
	document.write('<tr>');
	for (i=startIndex;i<endIndex;i=i+8)
		document.write('<td>' + Alphabet[i] + "-" + '<span id="d'+i+'">'+Dictionary[i] + '</span></td>');
	document.write('</tr>');
}

function writeDict() {
    document.write('<table cellpadding="2px">');
	writeRow(0, 57);
	writeRow(1, 58);
	writeRow(2, 59);
	writeRow(3, 60);
	writeRow(4, 61);
	writeRow(5, 62);
	writeRow(6, 63);
	writeRow(7, 64);
	document.write('</table>');
}

/*
function makeButton() {
    if (document.getElementById("button1").innerHTML != "Encode!") {
        document.getElementById("button1").innerHTML = "Encode!";
        hide_visibility("alert1");
        show_visibility("alert2");
        document.getElementById("button2").style.display = "inline-block";
    } else {
        beginColor();
        init();
    }
}
*/

function changeMessage() {
	//Updating the msg variable
	msg = document.getElementById("tweetmessage").innerHTML;
	var n = msg.indexOf(' - ');
	msg = msg.substr(n+3);
	//Changing the HTML
	var newhtml = "";
	for (var i=0; i < msg.length; i++)
        newhtml += '<span id="neonlight'+i+'">' + msg.charAt(i) + "</span>";
    //Implementing the change
    document.getElementById('mssg').innerHTML = '<h3>' + newhtml + '</h3>';
    document.getElementById("step-1").style.color = "#00FFCC";
}

function changeScreen() {  
$(document).ready(function(){
    $("#top, #dna, #dict").fadeOut(1500);
    document.getElementById("w1").style.display = "none";
    $("#w2").fadeIn(1500); 
});
}

function closeBox() {
	//When the message box is closed, fade out
    $("#dim").fadeOut();
    setTimeout(function() {dispMsg = true;}, 1000);
    return false;
}

var popUpMsg =  "<form name='input'>" +
			    "<center>Enter your twitter username:<br><br>" +
				"<input type='text' id='username' size='45'><br><br>" +
				"<input type='submit' value='Submit' onclick='retrieve_message(); closeBox(); return false;'>" + 
				"</center>" + 
				"</form>";
				
var codonTerm = "To translate the message to DNA code, each letter of the alphabet corresponds to three "
+ "DNA bases. This series of three bases is called a codon because it codes for which type of amino acid to be used. "
+ "<br><br><br>http://www.mrsec.psu.edu/education/nano-activities/dna/dnas_secret_code/dnas_secret_code.pdf";

var dnaTerm = "Deoxyribonucleic acid (DNA) -- is a molecule that encodes the genetic instructions "
+ "used in the development and functioning of all known living organisms and many viruses. "
+ "It consists of units called nucleotides—each nucleotide is composed of a nucleobase ((G)guanine, (A)adenine, (T)thymine, and (C)cytosine)."
+ "<br><br><br>http://en.wikipedia.org/wiki/DNA";

var synthTerm = "DNA Synthesis -- chemical assembly of nucleotides in a specified order "
+  "<br><br><br>biobuilder.org";

var plasmidTerm = "Plasmid -- a circular, double-stranded DNA molecule typically containing a few " 
+ "thousand base pairs that replicates within a cell independently of the chromosomal DNA. Plasmid "
+ "DNA is easily purified from cells, manipulated using common lab techniques and incorporated into cells."
+  "<br><br><br>biobuilder.org";

var ecoliTerm = "Escherichia coli -- is a Gram-negative, facultative anaerobic, rod-shaped bacterium "
+ "that is commonly found in the lower intestine of warm-blooded organisms (endotherms). "
+ "E. coli is the most widely studied prokaryotic model organism, and an important species in the fields "
+ "of biotechnology and microbiology, where it has served as the host organism for the majority of work "
+ "with recombinant DNA."
+ "<br><br>http://en.wikipedia.org/wiki/Escherichia_coli";

function changeMsgBox(elt) {
	document.getElementById("msgTxt").innerHTML = elt;
}

// BEGIN JQUERY CODE

$(document).ready(function(){

// JQuery for Twitter Queue
$(document).on("click", ".queue", function(){
	var currentId = $(this).attr('id');
	var html = document.getElementById(currentId).innerHTML;
	var k = html.indexOf('blank">');
	var l = html.indexOf('</a>');
	var m = html.indexOf(': ');
	var n = html.indexOf('</p>');
	var user = html.slice(k+7, l); //gets username
	var messg = html.slice(m+2, n); //gets tweet
	//Gets rid of special symbols
	messg = messg.replace(/[`~!@#$%^&*()_|+\-=?;:'",.<>\{\}\[\]\\\/]/gi, '');
	msg = messg; //Updates msg var from top
	var newhtml = ""; //Changes message on html page
	for (var i=0; i < msg.length; i++)
        newhtml += '<span id="neonlight'+i+'">' + msg.charAt(i) + "</span>";
    document.getElementById('mssg').innerHTML = '<h3>' + newhtml + '</h3>';
	//Stores message in temporary div for later retrieval
	document.getElementById('tweetmessage').innerHTML = user + " - " + msg;
	document.getElementById("step-1").style.color = "#00FFCC";
});

}); //END JQUERY CODE

// reset canvas dimensions and mouse coordinate calibration when window is resized
window.onresize = function(){
  // reset large canvas
  canvas = document.getElementById("myCanvas");
  canvas.width = window.innerWidth * .65;
  canvas.height = window.innerHeight *.86;
  ctx1 = canvas.getContext("2d");
  W = canvas.width/2;
  H = canvas.height;
  
  // reset mouse scale
  scaleX = (window.innerWidth * .175);
  scaleY = (window.innerHeight * .10);
};

// preload images
function preload(images) {
    if (document.images) {
        var i = 0;
        var imageArray = new Array();
        imageArray = images.split(',');
        var imageObj = new Image();
        for(i=0; i<=imageArray.length-1; i++) {
            //document.write('<img src="' + imageArray[i] + '" />');// Write to page (uncomment to check images)
            imageObj.src=imageArray[i];
        }
    }
}


