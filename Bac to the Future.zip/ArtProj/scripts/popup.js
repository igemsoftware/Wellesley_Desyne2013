// JQUERY CODE FOR POPUP WINDOW

$(document).ready(function(){
   	//Adjust height of overlay to fill screen when page loads
   	$("#dim").css("height", $(document).height());
   	//When the link that triggers the message is clicked fade in overlay/msgbox
	$(document).on("click", ".alert1", function(){
      	$("#dim").fadeIn();
      	dispMsg = false;
      	return false;
   	});
   	//When the message box is closed, fade out
   	$(".close").click(function(){
      	$("#dim").fadeOut();
      	setTimeout(function() {dispMsg = true;}, 1000);
      	return false;
   	});
});

//Adjust height of overlay to fill screen when browser gets resized
$(window).bind("resize", function(){
   	$("#dim").css("height", $(window).height());
});

//Hide and show classes
function hide_visibility(classname){
	$("."+classname).hide();
}

function show_visibility(classname){
	$("."+classname).show();
}