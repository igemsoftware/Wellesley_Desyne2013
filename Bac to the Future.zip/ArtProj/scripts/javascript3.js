// ----------------------DNA translation animation------------------->

function drawDNA(string) { 
	var str = string;	
	
	canvas1 = document.getElementById('myCanvas1');
    ctx = canvas1.getContext('2d');
	var W1 = canvas1.width = (window.innerWidth * .65)/2;
	var H1 = canvas1.height = (window.innerHeight *.86)/4;
	var count = 0;
	var sIndex = 0;
	var linearSpeed = 300;
	
	window.requestAnimFrame = (function() {
		return window.requestAnimationFrame || window.webkitRequestAnimationFrame || window.mozRequestAnimationFrame || window.oRequestAnimationFrame || window.msRequestAnimationFrame ||
        function(callback) {
        	window.setTimeout(callback, 1000 / 60);
        }; 
    })();
      
	function animate(base, canvas1, ctx, startTime) { 	
        // update
        var st = startTime;
        var time = (new Date()).getTime() - st;
        // pixels / second
        var newY = linearSpeed * time / 1000;
		
		if (count >= str.length) {
			setTimeout(initW2(), 1000);
			return;
		}
		
        if (newY < canvas1.height - base.height) {
          	base.y = newY;
        } else { 
            if (count * base.width >= canvas1.width-base.width) 
        		sIndex++;
        	if ((count)%3 == 0) 
				translate();
			if (count >= 50)
				linearSpeed = 600;
			if (count >= 75)
				linearSpeed = 900;
        	st = (new Date()).getTime();
        	base.y = -100;
        	count++;
        } 

        // clear
        ctx.clearRect(0, 0, canvas1.width, canvas1.height);
        
        for (var i = sIndex; i < count; i ++) 
        	drawBase(str.charAt(i), i-sIndex, canvas1.height - base.height);        
		drawBase(str.charAt(count), i-sIndex, base.y);
		
        // request new frame
        requestAnimFrame(function() {
          	animate(base, canvas1, ctx, st);
        });
    } 
      
    function drawBase(b, shift, y) {
		if (b == 'A')
			ctx.drawImage(A, shift*base.width, y, base.width, base.height);
		if (b == 'T')
			ctx.drawImage(T, shift*base.width, y, base.width, base.height);
		if (b == 'C')
			ctx.drawImage(C, shift*base.width, y, base.width, base.height);
		if (b == 'G')
			ctx.drawImage(G, shift*base.width, y, base.width, base.height);		
	}
      
    var base = {
    	x: 1,
      	y: -100,
      	width: W1/15,
        height: H1/2
    };
      
    drawBase(str.charAt(0), 0, base.y);
	
	// start animation
	setTimeout(function() {
		var startTime = (new Date()).getTime();
        animate(base, canvas1, ctx, startTime);
    }, 0);
}

// --------------------------Ticker Display----------------------------->

var runTicker = new Boolean(0);
var stopTicker = new Boolean(1);

function ticker(array) {
	runTicker = true;
	stopTicker = false;
    tCanvas = document.getElementById('tickerCanvas');
    tctx = tCanvas.getContext('2d');
 	var W2 = tCanvas.width = (window.innerWidth * .65)/2;
	var H2 = tCanvas.height = (window.innerHeight *.86)/10;
	var string = array.toString();
	var codonStr = toCodon(string);
	var str = "";
	var count = 0;
	var linearSpeed = 30;
	var tickerSpeed = 100;
	var startX = W2;
    var x = W2;
    
    document.getElementById("pinkBg").style.display = "block";
		
	window.requestAnimFrame = (function() {
		return window.requestAnimationFrame || window.webkitRequestAnimationFrame || window.mozRequestAnimationFrame || window.oRequestAnimationFrame || window.msRequestAnimationFrame ||
        function(callback) {
        	window.setTimeout(callback, 1000 / 60);
        }; 
        
    })();
      
	function animate(startTime, ts) {
	  if (runTicker) {
        // update
        var time = (new Date()).getTime() - startTime;
        // pixels / second
        var newX = startX - linearSpeed * time / 1000;
        var tickStart = ts;
        var tickTime = (new Date()).getTime() - tickStart;
        var tickX = startX - tickerSpeed * tickTime / 1000; 
		
		if (newX > W2 * .75 || count/3 > string.length) {
			x = newX;   
		} else if (tickX < W2 * .98 && count/3 <= string.length) {
			tickStart = (new Date()).getTime();
			codonStr = codonStr.substr(1); 
				if (count % 3 == 0)
					str = str.concat(string.charAt(count/3 - 1));
			count++;        	
		} 
		
		if (count/3 == string.length) {
			startTime = (new Date()).getTime();
			startX = W2 * .75;
		}
		
		if (x <= 0) {
			selectedId = null;
			document.getElementById("pinkBg").style.display = "none";
			runTicker = false;
			stopTicker = true;
			defaultTicker();
			return;
		}

		tctx.clearRect(0, 0, W2, H2);
		 
        var strW = tctx.measureText(str).width;
        tctx.fillText(str, x-strW, 35);
        tctx.fillText(codonStr, x, 35);
        
        // request new frame
        requestAnimFrame(function() {
          	animate(startTime, tickStart);
        });
      } else {
      	stopTicker = true;
      	return;
      }
    } 
	
	tctx.font = "20px Times New Roman";
    tctx.fillStyle = secondcolor;
    
    // start animation
	if (runTicker == true) {
		var startTime = (new Date()).getTime();
        animate(startTime, startTime);        
    }   
}

function defaultTicker() {
    tCanvas = document.getElementById('tickerCanvas');
    tctx = tCanvas.getContext('2d');
 	var W2 = tCanvas.width = (window.innerWidth * .65)/2;
	var H2 = tCanvas.height = (window.innerHeight *.86)/10;
	var str = "Click the bacteria to see the encoded messages.";
	var linearSpeed = 30;
    var x = W2;
		
	window.requestAnimFrame = (function() {
		return window.requestAnimationFrame || window.webkitRequestAnimationFrame || window.mozRequestAnimationFrame || window.oRequestAnimationFrame || window.msRequestAnimationFrame ||
        function(callback) {
        	window.setTimeout(callback, 1000 / 60);
        }; 
        
    })();
      
	function animate(startTime) { 
	  if (runTicker == false) {
        // update
        var time = (new Date()).getTime() - startTime;
        // pixels / second
        var newX = W2 - linearSpeed * time / 1000;
        var strW = tctx.measureText(str).width;
		
		if (newX > 0 - strW)
			x = newX;  
		else 
			return;
			//startTime = (new Date()).getTime();			
					
		tctx.clearRect(0, 0, W2, H2); 
        tctx.fillText(str, x, 35);
        
        // request new frame
        requestAnimFrame(function() {
          	animate(startTime);
        });
      } else {
      	return;
      }
    } 
	
	tctx.font = "20px Times New Roman";
    tctx.fillStyle = secondcolor;
    
    // start animation
    if (runTicker == false) {
		var startTime = (new Date()).getTime();
        animate(startTime);    
    }
}

