var canvas;
var canvas1;
var tCanvas;
var ctx;
var ctx1;
var tctx;

var selectedId; //var to store the id of the selected bacteria object
var selectedId1;

// -------------------------- DNA ------------------------->
// Unused in final - replaced with drawDNA() animation

var x1 = 0;
var y1 = 20;
var y2 = y1 + 80;
var mx = 1;
var counter = 0; 
var increase = Math.PI * 2 / 500;

function circle(x1,y1,r) {
  ctx.beginPath();
  ctx.arc(x1, y1, r, 0, Math.PI*2, true);
  ctx.fill();
}

// Initialize the draw function
function init() {
  canvas = document.getElementById("myCanvas1");
  ctx = canvas.getContext("2d");
  dnaCreation = setInterval(draw, 5);
}

// Draws two overlapping sine waves -- temp dna animation
function draw() {

  if (x1 <= W) {
  
  	circle(x1, y1, 2);
  	
  	x1 += mx;
  	y1 += Math.sin( counter );
  	counter += increase;
  	
  	circle(x1, y2, 2);
  	
  	y2 -= Math.sin( counter );
  	counter += increase;
  } else {
  	clear();
    window.clearInterval(translation);
  	window.clearInterval(dnaCreation);
  	initW2();
  	changeScreen();
  } 
}
  
function clear() {
	ctx.clearRect(0, 0, canvas.width, canvas.height);
}

// -------------------------- Bacteria ---------------------------->
//Animation - framework for bacteria tank animation

var W; var H;

// Images

// image file names
var imgFileArray_R = ["/images/imgs/b0.png", "/images/imgs/b1.png", "/images/imgs/b2.png"];
var imgFileArray_L = ["/images/imgs/b3.png", "/images/imgs/b4.png", "/images/imgs/b5.png"];
var imgFileArray_R1 = ["/images/imgs/b6.png", "/images/imgs/b7.png", "/images/imgs/b8.png"];
var imgFileArray_L1 = ["/images/imgs/b9.png", "/images/imgs/b10.png", "/images/imgs/b11.png"];

//image objects					
var imgArrayR = []; 
var imgArrayL = [];
var imgArrayR1 = [];
var imgArrayL1 = [];

// Array of bacteria
var bacteria = [];
var bactNum = 10;
var id = 0;

// Create bacteria array
function createArray() {
  for(var i = 0; i < bactNum; i++)
	//This will add 10 particles to the array with random positions
	bacteria.push(new create_bacteria());  
}

// Array of images
function createImgArray(fileArray, imgArray) {
  for(var i = 0; i < fileArray.length; i++)   	
      imgArray.push(createImgObject(fileArray[i]));
}

function createImgObject(src) {
	var img = new Image;
	img.src = src;
	return img;
}

// Create bacteria objects
function create_bacteria() {

	//Random position on the canvas
	this.x = Math.random()*W + W * 1.03;
	this.y = Math.random()*(H-(window.innerHeight *.86)/10) + (window.innerHeight *.86)/10;
	this.w = 255;
	this.h = 55;
	
	this.xClip = 0;
	this.yClip = 0;
	
	//Lets add random velocity to each particle
	this.vx = Math.random()*20-10;
	this.vy = Math.random()*20-10;
	if (this.vx > 0) 
		this.img = imgArrayR[0];
	else 
		this.img = imgArrayL[0];
	this.id = id;
	id++;
}

var num = 0; //keep count of image iteration
var iter = -1;

// Animate the bacteria
function drawBacteria() {

	//ctx2.globalCompositeOperation = "source-over";
	ctx1.clearRect(W, 0, W, H);

	//Draw bacteria from the array into the canvas
	for(var t = 0; t < bacteria.length; t++) {
		
		if (selectedId1 != bacteria[t].id) {
			var p = bacteria[t]; 
			
			ctx1.beginPath();
			
			if (p.vx > 0) {
				if (selectedId == bacteria[t].id)
					ctx1.drawImage(imgArrayR1[num], 0+p.xClip, p.yClip, 255-p.xClip, 55-p.yClip, p.x, p.y, 255-p.xClip, 55-p.yClip);
				else 
					ctx1.drawImage(imgArrayR[num], 0+p.xClip, p.yClip, 255-p.xClip, 55-p.yClip, p.x, p.y, 255-p.xClip, 55-p.yClip);
			} else {
				if (selectedId == bacteria[t].id) 
					ctx1.drawImage(imgArrayL1[num], 0+p.xClip, p.yClip, 255-p.xClip, 55-p.yClip, p.x, p.y, 255-p.xClip, 55-p.yClip);
				else 
					ctx1.drawImage(imgArrayL[num], p.xClip, p.yClip, 255-p.xClip, 55-p.yClip, p.x, p.y, 255-p.xClip, 55-p.yClip);
			}
			
			//Update velocity
			p.x += p.vx;
			p.y += p.vy;
		
			//To prevent the particles from moving out of the canvas
			//Clips images at the edges of the tank space
			if (p.x < W * 1.03) {
				if (p.xClip >= 240) {  
					p.x = 2*W;
					p.xClip = 0;
				} else {              
					p.x = W * 1.03;
					p.xClip += -p.vx;
				}
			}
			if (p.x == (W * 1.03) + p.vx && p.vx > 0) {
				if (p.xClip > 15) {
					p.x = W * 1.03;
					p.xClip -= p.vx;
				} else {
					p.xClip = 0;
					p.x += p.vx;
				}
			}
			if (p.y < (window.innerHeight *.86)/10) {
				if (p.yClip >= 40) {
					p.y = H;
					p.yClip = 0;
				} else {
					p.y = (window.innerHeight *.86)/10;
					p.yClip += -p.vy;
				}
			}
			if (p.x > 2*W) {
				p.x = W * 1.03;
				p.xClip = 240;
			}
			if (p.y > H) p.y = (window.innerHeight *.86)/10;	
		}		
	}
	
    //Return the count to 0 when the end of the image array is reached
	if (num == imgArrayR.length-1 || num == 0) {
		iter *= -1;
	}
	num += iter;
}

// Initialize the canvas
function initTank() {
  canvas = document.getElementById("myCanvas");
  canvas.width = window.innerWidth * .65;
  canvas.height = window.innerHeight *.86;
  ctx1 = canvas.getContext("2d");
  W = canvas.width/2;
  H = canvas.height;
  createImgArray(imgFileArray_R, imgArrayR);  
  createImgArray(imgFileArray_L, imgArrayL);
  createImgArray(imgFileArray_R1, imgArrayR1);
  createImgArray(imgFileArray_L1, imgArrayL1);
  createArray();
  setInterval(drawBacteria, 300);
}

// ---------------MOUSE COORDINATE Events for WS2-------------------->

var mouseX;
var mouseY;
var scaleX = (window.innerWidth * .175);
var scaleY = (window.innerHeight * .10);

function getMouseCoords(event) { 
      mouseX = event.pageX - scaleX;
      mouseY = event.pageY - scaleY; 
}
    
document.onmouseup = function(event) {    
	if (ws2 == true) {
    	bacClicked = false;
    	dna.clicked = false;
    	plasmid.clicked = false;
    	
    	switch(step) {
    		
    		case 0:
    			animImg();
    			break;
    		case 1:
    			if (selectedId1 != null) 
    				if (bacteria[selectedId1].x <= W) 
    					step++;
    			break;
    		case 2:
    			insertPlasmid();
    			break;
    		case 3:
    			reTank();
    	}
    }    
}
    
document.onmousedown = function(event) {

	getMouseCoords(event);
	
	if (ws2 == true) {
	
		switch(step) {
		
			case 0:
				getObj(dna);
				getObj(plasmid);
	    		if (plasmid.clicked == true) {
	    			plasmid.clicked = false;
    				alert(alrt);
    			}
    			break;
    			
    		case 1:
    			getObj(plasmid);
 				for (i = 0; i < bacteria.length; i++) {
        			if (mouseX >= bacteria[i].x && mouseX <= bacteria[i].x + 255 && 
            		mouseY >= bacteria[i].y && mouseY <= bacteria[i].y + 55) {
            			document.getElementById("step2").style.color = "#00FFCC";
        				document.getElementById("instr").innerHTML = document.getElementById("step2").innerHTML;
        				selectedId1 = bacteria[i].id;
        				bacClicked = true;
        			}
    			}    			
    			if (plasmid.clicked == true) {
    				plasmid.clicked = false;
    				alert(alrt);
    			}
    			break;
    		case 2:
    			getObj(plasmid);
				if (mouseX >= bacteria[selectedId1].x && mouseX <= bacteria[selectedId1].x + 255 && 
            	mouseY >= bacteria[selectedId1].y && mouseY <= bacteria[selectedId1].y + 55)
            		alert(alrt);
            	break;
            case 3:
				if (mouseX >= bacteria[selectedId1].x && mouseX <= bacteria[selectedId1].x + 255 && 
            	mouseY >= bacteria[selectedId1].y && mouseY <= bacteria[selectedId1].y + 55)
            		bacClicked = true;
            	break;            	
		}
	} else if (dispMsg == true) {
		displayMsg();
	}
}
    
document.onmousemove = function(event) {
    if (ws2 == true) {
    	getMouseCoords(event);
    	
    	if (bacClicked == true) 
    		move(bacteria[selectedId1]);
    
    	if (dna.clicked == true) 
    		move(dna);
    
    	if (plasmid.clicked == true) 
    		move(plasmid); 
    }
}

function getObj(obj) {
    if (mouseX >= obj.x && mouseX <= obj.x + obj.w && 
        mouseY >= obj.y && mouseY <= obj.y + obj.h) {
    	obj.clicked = true;
    }
}

var dispMsg = new Boolean(1);

// Displays the specified  message array in the ticker
function displayMsg() {
    for (i = 0; i < bacteria.length; i++) {
        if (mouseX >= bacteria[i].x && mouseX <= bacteria[i].x + 255 && 
            mouseY >= bacteria[i].y && mouseY <= bacteria[i].y + 55 && mouseX < canvas.width - 5) {
        	selectedId = bacteria[i].id;  
        	if (runTicker == true) runTicker = false;
        	tickCall = setInterval(callTicker, 50);
        }
    }
}

function callTicker() {
	if (stopTicker == true) 
    	ticker(msgArray[selectedId]);
    else 
    	window.clearInterval(tickCall);
}

// Message arrays
var msgArray = [ 
["Messages for Bacteria Zero"], ["Messages for Bacteria One"], ["Messages for Bacteria Two"], 
["Messages for Bacteria Three"], ["Messages for Bacteria Four"], ["Messages for Bacteria Five"], 
["Messages for Bacteria Six"], ["Messages for Bacteria Seven"], ["Messages for Bacteria Eight"], 
["Messages for Bacteria Nine"] ];

function addMsg(num) {
	msgArray[num].push(msg);
	//alert(msgArray[num]);
}

// ------------------------ Draw images in ws2 ------------------------>
var posX = (window.innerWidth * .7) / 4; // Initialized position of images
var posY = (window.innerHeight * .9) / 10;
var ws2 = new Boolean(0);
var bacClicked = new Boolean(0);
var dna;
var plasmid;
var step;
var alrt = "Oops. Please refer to the protocol.";

// Initialize workspace2
function initW2() { 
  	changeScreen();
	dna = new createObj("dna", posX, posY + 150, 210, 70, 0);
  	plasmid = new createObj("plasmid", posX-25, posY, 125, 125, 0);
	ws2 = true;
	step = 0;
	document.getElementById("step0").style.color = "#00FFCC";
	document.getElementById("instr").innerHTML = document.getElementById("step0").innerHTML;
	ctx1.drawImage(plasmidImg, plasmid.x, plasmid.y);
    ctx1.drawImage(dnaImg, dna.x, dna.y);
}

function createObj(n, x, y, w, h, bool) {
	this.name = n;
	this.x = x - w/2;
	this.y = y;
	this.w = w;
	this.h = h;
	this.clicked = new Boolean(bool);
}

// Drag image
function move(obj) {

	ctx1.clearRect(0, 0, W, H);
	obj.x = mouseX - (obj.w/2);
	obj.y = mouseY - (obj.h/2);	
	
	switch(step) {
		case 0:
			ctx1.drawImage(plasmidImg, plasmid.x, plasmid.y);
			ctx1.drawImage(dnaImg, dna.x, dna.y);	
			break;
		case 1: 
			ctx1.drawImage(plasmidImg1, plasmid.x, plasmid.y);	
			ctx1.drawImage(bacteria[selectedId1].img, obj.x, obj.y);
			break;
		case 2:	
			ctx1.drawImage(bacteria[selectedId1].img, bacteria[selectedId1].x, bacteria[selectedId1].y);	
			ctx1.drawImage(plasmidImg1, plasmid.x, plasmid.y);
			break;
		case 3:
			if (bacteria[selectedId1].vx > 0) {
				ctx1.drawImage(imgArrayR1[0], bacteria[selectedId1].x, bacteria[selectedId1].y);
			} else {
				ctx1.drawImage(imgArrayL1[0], bacteria[selectedId1].x, bacteria[selectedId1].y);
			}
	}
}

// Redraw the image with decreasing dimensions
function animImg() {
	if (dna.x >= plasmid.x-50 && dna.x <= plasmid.x + 50 && 
        dna.y >= plasmid.y-50 && dna.y <= plasmid.y + 50) {
        dnaInsertion = setInterval(shrinkImg, 50);
        step++;
    }
}

function shrinkImg() {
	if (dna.w >= 30) {
		ctx1.clearRect(0, 0, W, H);
		dna.w = dna.w - 3;
		dna.h = dna.h - 1;
		ctx1.drawImage(plasmidImg, plasmid.x, plasmid.y);
		ctx1.drawImage(dnaImg, plasmid.x + (plasmid.w/2) - (dna.w/2), plasmid.y, dna.w, dna.h);
	} else {
		window.clearInterval(dnaInsertion);
		dna.x = null;
		dna.y = null;
		ctx1.clearRect(0, 0, W, H);
		ctx1.drawImage(plasmidImg1, plasmid.x, plasmid.y);
		document.getElementById("step1").style.color = "#00FFCC";
		document.getElementById("instr").innerHTML = document.getElementById("step1").innerHTML;
	}
}

function insertPlasmid() {
	if (plasmid.x >= bacteria[selectedId1].x && plasmid.x <= bacteria[selectedId1].x + 200 && 
        plasmid.y >= bacteria[selectedId1].y-50 && plasmid.y <= bacteria[selectedId1].y + 100) {
        plasmidInsertion = setInterval(shrinkPlasmid, 50);
        step++;
        addMsg(selectedId1);
		//Adds message to datastore
		var username, tweetmssg;
		forDatastore(username, tweetmssg);
    }
}

function shrinkPlasmid() {
	if (plasmid.w >= 30) {
		ctx1.clearRect(0, 0, W, H);
		plasmid.w = plasmid.w - 1;
		plasmid.h = plasmid.h - 1;
		ctx1.drawImage(bacteria[selectedId1].img, bacteria[selectedId1].x, bacteria[selectedId1].y);
		ctx1.drawImage(plasmidImg1, bacteria[selectedId1].x + (255/2) - (plasmid.w/2), bacteria[selectedId1].y, plasmid.w, plasmid.h);
	} else {
		window.clearInterval(plasmidInsertion);
		plasmid.x = null;
		plasmid.y = null;
		ctx1.clearRect(0, 0, W, H);
		if (bacteria[selectedId1].vx > 0) {
			ctx1.drawImage(imgArrayR1[0], bacteria[selectedId1].x, bacteria[selectedId1].y)
		} else {
			ctx1.drawImage(imgArrayL1[0], bacteria[selectedId1].x, bacteria[selectedId1].y);
		}
		//alert("Message Inserted");
		document.getElementById("step1").style.color = "#00FFCC";
		document.getElementById("instr").innerHTML = document.getElementById("step1").innerHTML;
	}
}

function reTank() {
	if (bacteria[selectedId1].x >= W) {
        ctx1.clearRect(0, 0, W, H);
        //alert("Back In Tank");
        selectedId = selectedId1;
        selectedId1 = null;
        document.getElementById("step3").style.color = "#00FFCC";
        document.getElementById("instr").innerHTML = " "; //adds msg to datastore
        ws2 = false;
        displayMsg();
    }
}

// Function for GAE Datastore
function forDatastore(name, tweet) {
	var html = document.getElementById("tweetmessage").innerHTML;
	var n = html.indexOf(" - ");
	name = html.slice(0, n);
	tweet = html.substr(n+3);
	$.getJSON('/store', {'username': name, 'message': tweet});
}

// Function for filling the tank
function getDatastore() {
	$.getJSON('/tank',
	function(result) {
		var tank = [];
		//stores messages from datastore into temp array
		for (i=0; i<result.length; i++) {
			tank.push(result[i]['tweet_message']);
		}
		//puts messages in temp array into actual msgArray
		for (i=0; i<tank.length; i=i+10) {
			for (j=0; (j<10 || j<tank.length); j++) {
				msgArray[j].push(tank[i]);
				i++;
			}
		}
	});
}
