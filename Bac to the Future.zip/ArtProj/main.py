#!/usr/bin/env python
#
# Copyright 2007 Google Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


# ------------------------------------------------------------------------------------------
# ----------------------------------- BAC TO THE FUTURE ------------------------------------
# ------------------------------- JOANNA BI & HEATHER PETROW -------------------------------
# ----------------------------------- WELLESLEY HCI LAB ------------------------------------
# ------------------------------------------------------------------------------------------

# imports the different functions that we need
import jinja2
import os
import webapp2
import logging
import string, json
import datetime
from google.appengine.ext import db

# for the twitter portion
import requests
import requests_oauthlib
import oauthlib
from twython import Twython, TwythonError

APP_KEY = '3ZHQdn83nrV8xI2PN4DGzA'
APP_SECRET = '3yC4Shw8iRoGrq7PSgRc8ABHdcnzz4XMvD8J3OGVTE'
OAUTH_TOKEN = '1465436268-NJNvQeXZDSiMXgtuqjyQsJNk2Gm76EybHzhZWs4'
OAUTH_TOKEN_SECRET = 'DMjkVrXBHkCWxYyxax5fQpns75vfW5kE2Hk4BmM'

# for the html template
template_env = jinja2.Environment( loader=jinja2.FileSystemLoader(os.getcwd()))

# ------------------------------------------------------------------------------------------
# ----------------------------------- DATASTORE ENTITY -------------------------------------
# ------------------------------------------------------------------------------------------

class Message(db.Model):
    user = db.StringProperty()
    #tweet_original = db.StringProperty()
    #date_created = db.StringProperty()
    tweet_translated = db.StringProperty()
    date_translated = db.DateTimeProperty()


# ------------------------------------------------------------------------------------------
# ------------------------------------ INTRO HANDLER ---------------------------------------
# ------------------------------------------------------------------------------------------

class IntroHandler(webapp2.RequestHandler):

    def get(self):

        # HTML TEMPLATE DISPLAY
        template = template_env.get_template('intro.html')
        context = {'placeholder': 'jinja is dumb'}
        self.response.write(template.render(context))


# ------------------------------------------------------------------------------------------
# ------------------------------------ ENCODE HANDLER --------------------------------------
# ------------------------------------------------------------------------------------------

class EncodeHandler(webapp2.RequestHandler):

    def get(self):

        # HTML TEMPLATE DISPLAY
        template = template_env.get_template('main.html')
        context = {'placeholder': 'jinja is dumb'}
        self.response.write(template.render(context))


# ------------------------------------------------------------------------------------------
# ------------------------------------ SEARCH HANDLER --------------------------------------
# ------------------------------------------------------------------------------------------

class SearchHandler(webapp2.RequestHandler):

    def get(self):

        # BEGIN TWITTER CODE
        name = self.request.get('username')
        message = 'empty'

        twitter = Twython(APP_KEY, APP_SECRET, OAUTH_TOKEN, OAUTH_TOKEN_SECRET)

        try:
            search_results = twitter.search(q='%23igem2013', lang='en', count=100, result_type='recent')
        except TwythonError as e:
            print e

        for tweet in search_results['statuses']:
            screenname = tweet['user']['screen_name']
            text = tweet['text']
            #date = tweet['created_at']
            if not text.startswith('RT'):
                if (screenname == name):
                    message = text
                    message = parse(message) #parses the tweet
                    break

        # RETURNS MESSAGE TO HTML
        json.dump({'user': name, 'message': message}, self.response.out)


# ------------------------------------------------------------------------------------------
# ------------------------------------ QUEUE HANDLER ---------------------------------------
# ------------------------------------------------------------------------------------------

class QueueHandler(webapp2.RequestHandler):

    def get(self):

        queue = [] #initializes empty json object

        # BEGIN TWITTER CODE
        twitter = Twython(APP_KEY, APP_SECRET, OAUTH_TOKEN, OAUTH_TOKEN_SECRET)

        try:
            search_results = twitter.search(q='%23igem2013', lang='en', count=30, result_type='recent')
        except TwythonError as e:
            print e

        for tweet in search_results['statuses']:
            #icon = tweet['user']['profile_image_url']
            screenname = tweet['user']['screen_name']
            text = tweet['text']
            if not text.startswith('RT'):
                queue.append({'screenname': screenname, 'text': text})

        # FILLS QUEUE ON HTML PAGE
        json.dump(queue, self.response.out)


# ------------------------------------------------------------------------------------------
# ----------------------------------- STORE HANDLER ----------------------------------------
# ------------------------------------------------------------------------------------------

class StoreHandler(webapp2.RequestHandler):

    def get(self):

        screenname = self.request.get('username')
        tweetmessage = self.request.get('message')

        # creates new datastore entity
        new = Message(user = screenname,
                      tweet_translated = tweetmessage,
                      date_translated = datetime.datetime.now())
        new.put() #adds tweet to datastore


# ------------------------------------------------------------------------------------------
# ------------------------------------ TANK HANDLER ----------------------------------------
# ------------------------------------------------------------------------------------------

class TankHandler(webapp2.RequestHandler):

    def get(self):

        # gets all messages in datastore
        q = db.GqlQuery("SELECT * FROM Message")

        tank_messages = [] #initializes empty json object
        for msg in q:
            tweet = msg.tweet_translated
            tank_messages.append({'tweet_message': tweet})

        # adds messages in datastore to html page
        json.dump(tank_messages, self.response.out)


# ------------------------------------------------------------------------------------------
# ----------------------------------- HELPER METHODS ---------------------------------------
# ------------------------------------------------------------------------------------------

# PARSES TWEET MESSAGE
def parse(tweetmssg):
    '''tweetmsg = ''
    word_list = tweetmssg.split() #returns list of each word in string
    for word in word_list:
        if (not ((word.startswith('@')) or (word.startswith('#')))):
            tweetmsg = tweetmsg + ' ' + word
    tweetmsg.lstrip()'''
    remove_punctuation_map = dict((ord(char), None) for char in '\!@#$%^&*()-_+={|}[\'/]?<>,":;')
    tweetmssg = tweetmssg.translate(remove_punctuation_map) #removes punctuation
    return tweetmssg


# ------------------------------------------------------------------------------------------
# ----------------------------------- WEBAPP2 PAGES ----------------------------------------
# ------------------------------------------------------------------------------------------

app = webapp2.WSGIApplication([
    ('/', IntroHandler),
    ('/search', SearchHandler),
    ('/queue', QueueHandler),
    ('/encode', EncodeHandler),
    ('/store', StoreHandler),
    ('/tank', TankHandler)
], debug=True)
