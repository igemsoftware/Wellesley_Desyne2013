using UnityEngine;
using System.Collections;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.IO;
public class BasicInfo : MonoBehaviour {
	
	

	
	private string _sbolImg;
	private string _availability;
	private string _usefulness;
	private string _sequence;
	private int _length;
	private List<string> _twins;
	private string _descriptionName;
	public static string sourceCode;
	public static string seq;
	public static string partType;
	public static string partName;
	public static string link;
	#region Properties
	public string SbolImg
	{
		get{ return _sbolImg;}
		set{ _sbolImg = value;}
	}
	
	public string Availability
	{
		get { return _availability; }
		set { _availability = value; }
	}
	
	public string Usefulness
	{
		get { return _usefulness; }
		set { _usefulness = value; }
	}
	
	public string Sequence
	{
		get { return _sequence; }
		set { _sequence = value; }
	}
	
	public int Length
	{
		get { return _length; }
		set { _length = value; }
	}
	
	public List<string> Twins
	{
		get { return _twins; }
		set { _twins = value; }
	}
	
	public string DescriptionName
	{
		get { return _descriptionName; }
		set { _descriptionName = value; }
	}
#endregion
	
	public BasicInfo()
	{
		_sbolImg = "";
		_availability = "";
		_usefulness = "";
		_sequence = "";
		_length = 0;
		_twins = new List<string>();
		_descriptionName = "";
	}
	
	//Constructor for custom Parts: contains Sequence data
	public BasicInfo(String seq)
	{
		
	}
	
	/// <summary>
	/// 6/21/2012
	/// Links to Parts Registry pages and parses source code in order to obtain basic information for a 
	/// particular part
	/// @ Nicole Francisco & Veronica Lin
	/// </summary>
	/// <param name="sourceCode">Source code of a particular page</param>
	/// <param name="type">Type of part - promoter, terminator, rbs, or gene</param>
	/// <param name="name">Name of part</param>
	
        public BasicInfo(String sourceCode, String type, String name)
	{
		
	}
	
	//Returns a string representation of the part's twins
	public string getTwins()
	{
		if (_twins.Count != 0)
		{
			return string.Join(", ", _twins.ToArray());
		}
		
		return "No Information";
	}
	
	//returns all of the basic info parsed from each part page's source code
	public override string ToString()
	{
		if (_twins.Count != 0)
			return "{0}Image:" + _sbolImg + "{0}Sequence:" + _sequence + "{0}Length:" + _length + "{0}Availability:" + _availability + "{0}Usefulness:"
				+ _usefulness + "{0}Twins:" + _twins.Count;
		return "{0}Image:" + _sbolImg + "{0}Sequence:" + _sequence + "{0}Length:" + _length + "{0}Availability:" + _availability + "{0}Usefulness:"
			+ _usefulness;
	}
	
	// Use this for initialization
	void Start () {
		_sbolImg = "";
		_availability = "";
		_usefulness = "";
		
		if(seq != null)
            {
			_sequence = seq;
			_length = seq.Length;
		}
		
		_sequence = "";
		_length = 0;
		_twins = new List<string>();
		_descriptionName = "";
		
		int index = 0;
		string br = "</a>";
		string sc = sourceCode;
		
		index = sc.IndexOf("http://parts.igem.org/partsdb/twin_info.cgi?part=");
		if (index == -1) _twins.Add("This part has no twins."); //case where no twins
		else
		{
			WWW twinsPage = new WWW("http://parts.igem.org/partsdb/twin_info.cgi?part=" + Infoprint.thePart);
			while(!twinsPage.isDone)
			{
				Console.WriteLine ("waiting");
			}
			string scTwins = twinsPage.text;
			index = scTwins.IndexOf("class='noul_link part_link'");
			//scTwins = scTwins.Substring(0, sc.IndexOf("</div>"));
			
			scTwins = scTwins.Substring(index);
			scTwins = scTwins.Substring(0, scTwins.IndexOf("</div>"));
			
			do
			{
				index = scTwins.IndexOf("class='noul_link part_link'");
				//scTwins = scTwins.Substring(0, sc.IndexOf("</div>"));
				
				
				//string temp = scTwins.Substring(scTwins.IndexOf("'>") + 2, scTwins.IndexOf("</A>") - scTwins.IndexOf("'>") - 2);
				string temp = scTwins.Substring(scTwins.IndexOf("'>") + 2, scTwins.IndexOf("</A>") - scTwins.IndexOf("'>") - 2);
				scTwins = scTwins.Substring(index);
				//print(temp);
				scTwins = scTwins.Substring(scTwins.IndexOf("</A>") + "</A>".Length);
				//temp = temp + " :" + scTwins.Substring(0, scTwins.IndexOf("\n"));
				temp = temp.Replace("\n", "").Trim();
				if(!temp.Equals(Infoprint.thePart))
					_twins.Add(temp); //produces list of twins
				
				index = scTwins.IndexOf("class='noul_link part_link'");
				if(index != -1)
					scTwins = scTwins.Substring (index);
			}
			while (!(scTwins.IndexOf("</A>") == -1));
			
		}
		
		
		//finds availability of the part (on the top right corner of each part's page)
		//index = sc.IndexOf("<div style='float:right;padding-top:1px; font-size:95%;line-height:99%;text-align:center;margin-left:20px;'>");
		string availInd = "1px solid gray;;background-color:#ffffff;'><a href='http://parts.igem.org/Help:Part_Status_Box'>";
		if(sc.Contains("Part Deleted")) _availability = "Part Deleted";
		else if(sc.Contains (availInd)) {
			index = sc.IndexOf(availInd);
			sc = sc.Substring(index + availInd.Length);
			_availability = sc.Substring(0, sc.IndexOf(br));
		}
		
		//finds usefulness of the part (on the top right corner of each part's page)
		
		//string useInd = "<div style='display:block;position:relative;height:16px;padding-top:3px;text-align:center;border:1px solid gray;border-top:none;'background-color:#ffffff;'>";
		//index = sc.IndexOf(useInd);
		string useInd = "Experience:";
		index = sc.IndexOf (useInd);
		if(index != -1)
		{
			sc = sc.Substring(index);
			br = "</div>"; 
			_usefulness = sc.Substring (0, sc.IndexOf (br));
		}
		
		else if (sc.Contains ("http://parts.igem.org/images/stars/1star.png"))
			_usefulness = "1 Registry Star";
		
            else
			_usefulness = "No Results";
		
		//_usefulness = sc;
		//index = sc.IndexOf(br);
		//sc = sc.Substring(index + br.Length);
		//_usefulness = sc.Substring(0, sc.IndexOf("</")).Trim();
		//_usefulness = sc.Substring (0, sc.IndexOf (br));
		//Case where Usefulness: 1 Registry Star
		if (_usefulness.Contains("http://parts.igem.org/images/stars/1star.png"))
			_usefulness = _usefulness.Substring(_usefulness.IndexOf(">") + 1);
		
		//finds the SBOL image
		index = sc.IndexOf("http://parts.igem.org/images/partbypart/icon_");
		sc = sc.Substring(index);
		_sbolImg = sc.Substring(0, sc.IndexOf("'>"));
		
		//finds description name
		if (sc.Contains("<SPAN style='font-size: 150%; font-weight: bold;'>"))
		{
			string descriptInd = "<SPAN style='font-size: 150%; font-weight: bold;'>";
			index = sc.IndexOf(descriptInd) + descriptInd.Length;
			sc = sc.Substring(index);
			_descriptionName = sc.Substring(0, sc.IndexOf("</SPAN>"));
		}
		
		//finds list of twins of the part (on the bottom of each part's page)
		
		
		/* Checking if works with parts with multiple twins
		 * string twinsList = string.Join(",", twins.ToArray());
		 * Console.WriteLine(twinsList);
		 */
		
		
		//Go to part design page in Parts Registry
		// used to build entire input
		StringBuilder sb = new StringBuilder();
		
		// used on each read operation
		byte[] buf = new byte[8192];
		
		// prepare the web page we will be asking for
		WWW theSite = new WWW(link);
		while(!theSite.isDone)
		{
			Console.WriteLine("wait");
		}
		buf = theSite.bytes;
		
		
		
		
		// we will read data via the response stream
		//Stream resStream = response.GetResponseStream();
		
		string tempString = "";
		int count = 0;
		
		count = buf.Length;
				
		//Infoprint.print (count);
		
		if (count > 0)
		{
			// fill the buffer with data
			
					
			// make sure we read some data
			
			
			// translate from bytes to ASCII text
			tempString = Encoding.ASCII.GetString(buf, 0, count);
			
			// continue building the string
			sb.Append(tempString);
			//count--;
					}
		
		
		//while (count > 0); // any more data to read?
		
		
		//htmlText = sb.ToString();
		// while (count > 0); // any more data to read?
		
		
		//finds sequence and length of the part (on the design page for each part)
		index = 0;
		
		String htmlText = sb.ToString();
		
		
		if (htmlText.Contains("var sequence"))
		{
			index = htmlText.IndexOf("String('");
			htmlText = htmlText.Substring(index + "String('".Length);
			_sequence = htmlText.Substring(0, htmlText.IndexOf("')"));
			_length = _sequence.Length;   
		}
		
		if (_sequence == "")
		{
			_sequence = "No Information";
			_length = 0;
		}
		
		
		
		//resStream.Close();
		//response.Close();
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
