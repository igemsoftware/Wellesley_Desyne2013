using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Net;
using System.IO;
//using System.Linq;
using UnityEngine;

//this is a data sheet which will hold all the necessary information of any part. IF it is properly populated.

    /// <summary>
    /// All information for a part's data sheet extracted from the Registry
    /// </summary>
    public class RegDataSheet2D : MonoBehaviour
    {
        public string _name;
        public string _type;
        private Terminator _terminator;
        private Promoter _promoter;
        private RBS _rbs;
        private Gene _gene;
        private BasicInfo _basicInfo;
        private Description _description;
        //private Protocol _protocol;
        private Reference2D _reference;
        private bool _none; //is not the type of part we want
		
		public static string link;
		public bool done = false;
		
		protected static FileInfo InfoFile;
		protected byte[] buf;
		protected static StreamReader reader = null;
		public string sourceText, htmlText, tempText;
		
		public int theNum;
		//public static int counter;
        #region Properties

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public string Type
        {
            get { return _type; }
            set { _type = value; }
        }

        public Terminator Terminator
        {
            get { return _terminator; }
            set { _terminator = value; }
        }

        public Promoter Promoter
        {
            get { return _promoter; }
            set { _promoter = value; }
        }

        public RBS Rbs
        {
            get { return _rbs; }
            set { _rbs = value; }
        }

        public Gene Gene
        {
            get { return _gene; }
            set { _gene = value; }
        }

        public BasicInfo BasicInfo
        {
            get { return _basicInfo; }
            set { _basicInfo = value; }
        }

        public Description Description
        {
            get { return _description; }
            set { _description = value; }
        }

        //public Protocol Protocol
        //{
        //    get { return _protocol; }
        //    set { _protocol = value; }
        //}

        public Reference2D Reference
        {
            get { return _reference; }
            set { _reference = value; }
        }

        public bool isPart
        {
            get { return _none; }
            set { _none = value; }
        }


        #endregion

        public RegDataSheet2D()
        {
		
	}
	
	/// <summary>
	/// 6/21/2012
	/// Links to Parts Registry pages and parses source code in order to obtain general information for a 
	/// particular part
	/// @ Nicole Francisco & Veronica Lin
	/// </summary>
	/// <param name="link">Particular extension of URL specific to this page</param>
	
	public RegDataSheet2D(string link)
	{
	}
	
	
	
	void Start()
	{
	
	
	//Infoprint.print ("jfbka");
		//RegDataSheet1.counter ++;
            _name = "";
            _type = "";
            _none = true;
            /*_terminator = new Terminator();
            _promoter = new Promoter();
            _rbs = new RBS();
            _gene = new Gene();
            _basicInfo = new BasicInfo();
            _description = new Description();
            //_protocol = new Protocol();
            _reference = new Reference();
            
            
            
            _name = "";
            _type = "";
            _none = true;
            _terminator = new Terminator();
            _promoter = new Promoter();
            _rbs = new RBS();
            _gene = new Gene();
            _basicInfo = new BasicInfo();
            _description = new Description();
            //_protocol = new Protocol();
            _reference = new Reference();
			 */
            bool linkValid = true;

            #region HTML Web Request
            //the first link was set to -1 if no results showed up
            if (link.Equals("http://parts.igem.org/-1"))
            {
                linkValid = false;
            }
		
		
		
            if (linkValid)
            {
            
                try
                {
				
				//Open a connection to PubMed publication page to get the information
				Uri uri = new Uri(link);
				
				
				// used to build entire input
				StringBuilder sb = new StringBuilder();
				
				// used on each read operation
				buf = new byte[8192];
				
				// prepare the web page we will be asking for
				//HttpWebRequest request =
				//(HttpWebRequest)WebRequest.Create(uri);
				
				// execute the request
				//HttpWebResponse response = (HttpWebResponse)request.GetResponse();
				
				
				
				// WWW theSite = Test();
				
				 WWW theSite = new WWW(link);
				 while(!theSite.isDone)
				 {
					Console.WriteLine("wait");
				 }
				 buf = theSite.bytes;
				 
		//var aSite = new WWW("http://www.google.com");
		//Infoprint.print (www.isDone);
		//Infoprint.print("anything");
		//yield return www;
		//return aSite;
				 
				 
				 
				// we will read data via the response stream
				//Stream resStream = response.GetResponseStream();
				
                string tempString = "";
				int count = 0;
				
				count = buf.Length;
				
				//Infoprint.print (count);
				
				if (count > 0)
                    {
                    //print (count);
                    //Infoprint.print (count);
                   
					// fill the buffer with data
					
					
					// make sure we read some data
					
					
						// translate from bytes to ASCII text
                            tempString = Encoding.ASCII.GetString(buf, 0, count);
						
						// continue building the string
						sb.Append(tempString);
						//count--;
					}
					 
					 
					 //Infoprint.print ("something");
				//while (count > 0); // any more data to read?
				
				

#endregion
				htmlText = sb.ToString(); //keep original to have objects parse through and find
				//Infoprint.print("godoodo");
				//Infoprint.print ("efjiw");
				//System.IO.File.WriteAllText(@"D:\Users\zSpace\Documents\zTreeDirectIntegration\BigFile\htmlText.txt", sb.ToString ());
				
				//htmlText = theSite.text;
				//specific information
                tempText = sb.ToString(); //will be parsed through in this top-level method to find name and type of part
                //System.IO.File.WriteAllText(@"D:\Users\zSpace\Documents\zTreeDirectIntegration\BigFile\tempText.txt", sb.ToString ());
				sourceText = sb.ToString(); //will be parsed for sections of source code each class needs
				
				
				System.IO.File.WriteAllText("Assets\\", sb.ToString());
				
				
				
				//}
			}
			catch (Exception ex)
			{
				Console.Write("Exception : " + ex.Message);
			}
			
		}
		done = true;
		//print ("got here");
		PopulateData ();
		
		//System.IO.File.WriteAllText(@"C:\Users\Valued Customer\Documents\zTree\Assets\sourceText.txt", sb.ToString());
		
		
		//StreamWriter s = new StreamWriter(@"C:\Users\Valued Customer\Documents\zTree\Assets\" + _name + ".txt");
		//s.WriteLine(ToString(), Environment.NewLine);
		//s.Close();
		
		//print (ToString());
		//gameObject.GetComponent<Infoprint>().done = true;
		
	}
	
	//Constructor for custom Part datasheet: covers Description, Sequence, Associated wtih
	public RegDataSheet2D(String[] data)
        {
		_name = data[3].Trim(); //Set name
		_type = "";
		_none = true;
		_terminator = new Terminator();
		_promoter = new Promoter();
		_rbs = new RBS();
		_gene = new Gene();
		_basicInfo = new BasicInfo(data[5].Trim()); //Set sequence
		_description = new Description();
		//_protocol = new Protocol();
		_reference = new Reference2D();
		
		//Determine appropriate type
		_type = data[2];
		if (_type.Equals("prom"))
		{
			_promoter = new Promoter("custom");
		}
		else {
		
		} {
			
		} {
			
		} if (_type.Equals("rbs"))
		{
			_rbs = new RBS("custom");
		}
		else if (_type.Equals("cds"))
		{
			_gene = new Gene();
		}
            else
		{
			_terminator = new Terminator("custom");
		}
		
            //Save description to regDS
		_description.Desc = data[4].Trim();
		
	}
	
	public override string ToString ()
	{
		  string temp = "Name: " + _name + "\n Type: " + _type +
                //Basic Info:
                           "\n SBOL Image: " + _basicInfo.SbolImg + 
                           "\n Description Name: " + _basicInfo.DescriptionName + 
                //Description
                           "\n ------Description " + "\n ----Properties " +
                           "\n Sequence: " + _basicInfo.Sequence +
                           "\n Length: " + _basicInfo.Length +
                //Separate Parts Type Classes:               
                           "\n --Category: \n Chassis: " + _description.chassisString();
                 
		
		//"\n**Description:** " + _description
		//     + "\n**Protocol:** " + _protocol + "\n**Reference:** " + _reference;
		
		if (_type == "promoter") temp = temp + "\n Regulation:" + _promoter.getReg();
		if (_type == "rbs") temp = temp + "\n Family Name:" + _rbs.FamilyName;
		
		//Parameters:
		
		if (_type == "promoter") temp = temp + "\n Positive Regulation: " + _promoter.PosReg +
			"\n Negative Regulation: " + _promoter.NegReg;
		//if (_type == "rbs") temp = temp + "\n-->Positive Regulation: " + _rbs.PosReg +
		//                                "\n-->Negative Regulation: " + _rbs.NegReg; 
		if (_type == "terminator") temp = temp + _terminator;
		if (_type == "gene") temp = temp + "\n Gene type: " + _gene.GeneType;
		
             temp = temp + "\n Twins: " + _basicInfo.getTwins() + "\n --Assembly Compatibility: " + _description.assembCompString() +
                    //"{0}------Related" +
                    //"{0}Other Related Parts:" + _protocol.getRelParts() +
                    "\n ------Availibility, Usefulness" + 
                    "\n Availibility: " + _basicInfo.Availability +  
                    "\n Usefulness: " + _basicInfo.Usefulness + 
                    "\n ------References" + _reference;
		
		return temp;
	}
	
	
	
	
	WWW Test()
	{   
	//Infoprint.print("please print something");
	BasicInfo.link = link;
		WWW aSite = new WWW(link);
		//var aSite = new WWW("http://www.google.com");
		//Infoprint.print (www.isDone);
		//Infoprint.print("anything");
		//yield return www;
		return aSite;
	}
	
	
	void PopulateData()
	{
	//print ("test");
	int index = 0;
				
				
                    //find name of page
                //TextAsset sText = (TextAsset)Resources.Load ("sourceText.txt");
                
				string pageTitle = "<h1 class='firstHeading'>"; //length: 25
				string typeImg = "<img style='padding-top:0px' src='http://parts.igem.org/images/partbypart/icon_";
				string partLead = "Part:";
				
				//strings needed for each big class
                    string descriptionText = "";
				string referenceText = "";
				
				string categoriesBox = "";
				string parametersBox = "";
				
				
				
				//print (InfoFile);
				//InfoFile = new FileInfo(@"C:\Users\Valued Customer\Documents\zTree\Assets\sourceText.txt");
				//if(reader == null)
				//{
				//reader = InfoFile.OpenText();
				//}
				//print (reader.ReadLine () + " li");
				//string line = "gurgle";
				//print (line);
				
				try{
				//sourceText = reader.ReadLine();
				}
				catch{
				//sourceText = null;
				//print ("done");
				}
				
				if (sourceText != null) {
				
				//line = reader.ReadLine();
				//theNum++;
					//Infoprint.print(line);
					
					//print (sourceText);
					//string line= "aghe";
				
				//reader.Close();
				
				
				if (sourceText.Contains("Designed by"))
				{
					index = sourceText.IndexOf("Designed by");
					sourceText = sourceText.Substring(index);
					referenceText = sourceText.Substring(0, sourceText.IndexOf("</div>"));
				}
				
				//if (line.Contains("Assembly Compatibility:<UL>"))
				if(sourceText.Contains("Assembly Compatibility:<UL>"))
				{
				index = sourceText.IndexOf("Assembly Compatibility:<UL>");
                        sourceText = sourceText.Substring(index);
                        descriptionText = sourceText.Substring(0, sourceText.IndexOf("</UL>") + 5);
				}
				
				if (sourceText.Contains("<div style='border:1px solid #aaa;'>"))
				{ 
				index = sourceText.IndexOf("<div style='border:1px solid #aaa;'>");
                        sourceText = sourceText.Substring(index);
                        categoriesBox = sourceText.Substring(0, sourceText.IndexOf("</div>"));
                    }
				
				if (sourceText.Contains("<div id='parameters'>"))
				{
					index = sourceText.IndexOf("<div id='parameters'>");
					sourceText = sourceText.Substring(index);
					parametersBox = sourceText.Substring(0, sourceText.IndexOf("<!--"));
				}
				
				if (tempText.Contains(typeImg)) //checks if this page is a parts page
				{
					//Find type of the part
					index = tempText.IndexOf(typeImg) + typeImg.Length;
                        tempText = tempText.Substring(index);
					string temp = tempText.Substring(0, sourceText.IndexOf("\'>"));
					
					
					//first case, where the type of the part is RBS
					if (htmlText.Contains("rbs"))
					{
						//if (temp == "rbs.png" || htmlText.Contains("//rbs/prokaryote/regulated/issacs"))
                            //{
						_type = "rbs";
						
						
						//_rbs = new RBS(categoriesBox);
						_rbs = gameObject.AddComponent<RBS>();
						RBS.sourceCode = htmlText;
						//}
						//Console.WriteLine("RBS!");
					}
					//second case, where the type of the part is promoter (different images for
					//different types of promoters)
					else if (htmlText.Contains("//promoter"))
					{
					//print("testing");
					//print ("test");
						_type = "promoter";
						Promoter.sourceCode = (categoriesBox + " " + parametersBox);
						_promoter = gameObject.AddComponent<Promoter>();
						
						//Console.WriteLine("PROMOTER!");
						
                        //if (temp == "regulatory.png" || temp == "reporter.png" ||
						//    temp == "generator.png" || temp == "signalling.png" ||
						//    temp == "intermediate.png" || temp == "composite.png")
						//{
						
						
					}
					//third case, where the type of the part is terminator
					else if (temp == "terminator.png")
					{
						_type = "terminator";
						Terminator.sourceCode = parametersBox;
						_terminator = gameObject.AddComponent<Terminator>();
						//_terminator = new Terminator(parametersBox);
						//Console.WriteLine("TERMINATOR!");
					}
					//fourth case, where the type of the part is gene or protein coding sequence
					else {
					
					} if (temp == "coding.png" || GameObject.Find ("RegistryCrawler").GetComponent<RegistryCrawler>().topChoice.Equals("DNA"))
					{
						_type = "gene";
						Gene.sourceCode = categoriesBox;
						_gene = gameObject.AddComponent<Gene>();
						//gene = new Gene(categoriesBox);
						//Console.WriteLine("GENE!");
					}
				}
				//last case, where type of part is none of the 4 classified parts above
				else
				{
					_none = false;
				}

				//Finding page title
				
				//case where page is not a parts page
				if (_none == false)
				{
					index = tempText.IndexOf("<h1 class=\'firstHeading\'>") + "<h1 class=\'firstHeading\'>".Length;
					tempText = tempText.Substring(index);
					_name = tempText.Substring(0, tempText.IndexOf("</h1>"));
				}
                    //case where page is a parts page
				else
				{
					 index = tempText.IndexOf(pageTitle) + pageTitle.Length + partLead.Length;
                        tempText = tempText.Substring(index);
                        _name = tempText.Substring(0, tempText.IndexOf("</h1>"));
				}
				
				//string protocolLink = "http://parts.igem.org/cgi/partsdb/related.cgi?part=" + _name;
				
				//if the page is a parts page
				if (_none)
				{
					//_basicInfo = new BasicInfo(htmlText, _type, _name);
					BasicInfo.sourceCode = htmlText;
					BasicInfo.partType = _type;
					BasicInfo.partName = _name;
					BasicInfo.link = link;
					_basicInfo = gameObject.AddComponent<BasicInfo>();
                        //Console.WriteLine(_basicInfo); 
                        Description.sourceCode = descriptionText;
					_description = gameObject.AddComponent<Description>();
					//Console.WriteLine(_description); 
					//_protocol = new Protocol(protocolLink);
                        //Console.WriteLine(_protocol); 
                        Reference2D.sourceCode = referenceText;
					_reference = gameObject.AddComponent<Reference2D>();
					//Console.WriteLine(_reference); 
				}
				}
				else if (sourceText == null){
				//reader.Close();
				}
		//reader.Close();
	}
	
	
	void Update()
	{
	
	
}
	}