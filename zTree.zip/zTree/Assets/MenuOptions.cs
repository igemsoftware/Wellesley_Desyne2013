using UnityEngine;
using System.Collections;

public class MenuOptions : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
		this.gameObject.AddComponent<Rigidbody>();
		this.gameObject.GetComponent<Rigidbody>().useGravity = false;
		this.gameObject.transform.localScale = new Vector3(5f, 3f, .5f);
		
		GameObject textLabel = new GameObject();
		textLabel.transform.parent = this.gameObject.transform;
		var label = (TextMesh)textLabel.AddComponent("TextMesh");
		var meshRenderer = textLabel.AddComponent("MeshRenderer");
		var fontResource = Resources.Load ("Aller_Rg");
		label.font = (Font)fontResource;
		label.text = "Parts Tree";	
		label.characterSize = .75f; 	
		label.font.material.color = Color.black;
		meshRenderer.renderer.material = label.font.material;
		textLabel.transform.position = textLabel.transform.parent.position - new Vector3(2.25f, -.5f, 0f);
		textLabel.transform.rotation = textLabel.transform.parent.rotation;
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	
	void OnMouseDown(){
		if(Input.GetMouseButtonDown(0)){
			Application.LoadLevel(0);
		}
	}
}
