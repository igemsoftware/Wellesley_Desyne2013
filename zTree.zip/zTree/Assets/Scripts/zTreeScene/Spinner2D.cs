using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Spinner2D : MonoBehaviour {
	//The carousel
	private GameObject carousel;
	
	//List of Carousels called layers
	private IList<IList<Carousel2D>> layers;
	
	//The index of the selected carousel
	private int indexOfSelected;
	
	// Use this for initialization
	void Start () {
		carousel = gameObject;
	}
	
	
	
	
	// Update is called once per frame
	void Update () {
		
		Spin();
	}
	
	
	
	
	
	//Spins the carousel when the arrow keys are clicked.
	void Spin()
	{
		indexOfSelected = carousel.transform.parent.GetComponent<InfoTree2D>().getIndexOfSelected();
		int indexOfSelectedInLayer = carousel.transform.parent.GetComponent<InfoTree2D>().getIndexofSelectedInLayer();
		if(Input.GetKey(KeyCode.RightArrow) && carousel.GetComponent<Carousel2D>().selected == true)
		{	
			getLayers ();
			foreach(IList<Carousel2D> layer in layers){
				foreach(Carousel2D caro in layer){
					if (layers[indexOfSelected][indexOfSelectedInLayer].transform.position.y > caro.transform.position.y){
						carousel.transform.RotateAround( (carousel.transform.position), Vector3.down, (5f/carousel.GetComponent<Carousel2D>().cards.Count));
						//if(Card.otherClicked(carousel.GetComponent<Carousel>())==true){
						//}else{
						Vector3 movingPosition = caro.parentCard.transform.position;
						movingPosition.y = movingPosition.y -2.5f;
						caro.transform.position = movingPosition;
						//clickedCardPosition(caro);
						//}
					}else {
						carousel.transform.RotateAround((carousel.transform.position), Vector3.down, (5f/carousel.GetComponent<Carousel2D>().cards.Count));
					}
				}
			}
		}
		if(Input.GetKey(KeyCode.LeftArrow) && carousel.GetComponent<Carousel2D>().selected == true)
		{
			getLayers ();
			foreach(IList<Carousel2D> layer in layers){
				foreach(Carousel2D caro in layer){
					if (layers[indexOfSelected][indexOfSelectedInLayer].transform.position.y > caro.transform.position.y){
						carousel.transform.RotateAround( (carousel.transform.position), Vector3.up, (5f/carousel.GetComponent<Carousel2D>().cards.Count));
						//caro.transform.position = clickedCardPosition(caro);
						//if(Card.otherClicked(carousel.GetComponent<Carousel>())==true){
						//}else{
						//caro.transform.position = caro.parentCard.transform.position;
						//clickedCardPosition(caro);
						Vector3 movingPosition = caro.parentCard.transform.position;
						movingPosition.y = movingPosition.y -2.5f;
						caro.transform.position = movingPosition;
						//}
					}	
					else {
						carousel.transform.RotateAround( (carousel.transform.position), Vector3.up, (5f/carousel.GetComponent<Carousel2D>().cards.Count));
					}
				}		
			}	
		}		
	}//Spin
	
	void getLayers(){
		layers = carousel.transform.parent.GetComponent<InfoTree2D>().layers;	
		
	}
	
	//Searches the list of carousels for the one that is currently selected, and by selected we mean the one that spins
	public int getIndexOfCard(Carousel2D caro){
		foreach(IList<Carousel2D> layer in layers){
			foreach(Carousel2D car in layer){
				if(car == caro){
					return layers.IndexOf(layer);
				}
			}
		}
		return -1;
	}
	
	
	
	
	public int getIndexInLayerOfCard(Carousel2D caro){
		foreach(IList<Carousel2D> layer in layers){
			foreach(Carousel2D car in layer){
				if(car == caro){
					return layers[layers.IndexOf(layer)].IndexOf(car);
				}
			}
		}
		return -1;
	}
	
	
	
	
	public Vector3 clickedCardPosition(Carousel2D caro){
		int index = getIndexOfCard(caro);
		print (index);
		//int indexInLayer = getIndexInLayerOfCard(caro);
		int indexInLayer = caro.indexInLayer;
		IList<Card2D> cards = layers[index-1][indexInLayer].GetComponent<Carousel2D>().cards;
		foreach(Card2D car in cards){
			if (car.isClicked){
				Vector3 position = car.transform.position;
				position.y = position.y - 2.5f;
				return position;
			}
		} return Vector3.zero;
	}
}
