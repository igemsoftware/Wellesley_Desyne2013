using UnityEngine;
using System.Collections;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class Card : MonoBehaviour {
	//How many cards
	public int dataOptions;
	public Carousel carouselOfCard;
	public static bool onPartLevel;
	
	public static bool done; 
	public bool getTheInfo, callAgain, onButtonDownCalled;
	public static bool partPopulated;
	
	//States whether or not the card has been clicked
	public bool isClicked;
	
	//The text on the card
	public GameObject textLabel;
	
	public IList<String> dataInfo; 
	
	//Yellow line that connects carousels
	private GameObject line;
	
	//Which carousel
	private int indexOfCarousel;
	
	private int orangeLineIndex;
	 
	public static int iteration;
	
	//public string selection;
	
	public static string selected; 
	
	public Infoprint printer;
	
	public GameObject stylus; 
	
	public GameObject camera;
	
	public string partInformation;
	
	public string originalInfo;
	
	public static string labelInfo;
	
	public Color naturalColor; 
	
	public static string thePartInfo;
	
	public FileWriter fileWriter; 
	
	//public static string searchData; 
	
	//public static bool searching; 
	
	//public static bool callAgainSearch; 
	
	// Use this for initialization
	public void Start () {
		//partPopulated = false; 
		partInformation = ""; 
		Card.labelInfo = "Please choose a part";
		//finds pen
		stylus = GameObject.Find ("ZSStylus");
		fileWriter = GameObject.Find("FileWriter").GetComponent<FileWriter>();
		//sets all the cards to not clicked
		isClicked = false;
		
	
		
		
		
		//Adds a Rigidbody to the card
		gameObject.AddComponent<Rigidbody>();
		gameObject.GetComponent<Rigidbody>().useGravity = false;
		gameObject.GetComponent<Rigidbody>().mass = Mathf.Infinity;
		
		//Adds the text labels to the cards and adjusts their position, size, and color.
		textLabel = new GameObject("cardLabel");
		textLabel.transform.parent = gameObject.transform;
		textLabel.transform.tag = "lab";
		textLabel.AddComponent<TextMesh>();
		var label = textLabel.GetComponent<TextMesh>();
		var meshRenderer = textLabel.AddComponent("MeshRenderer");
		var fontResource = Resources.Load ("Aller_Rg");
		label.font = (Font)fontResource;
		
		
		gameObject.name = Carousel.dataInfo[dataOptions];
		originalInfo = Carousel.dataInfo[dataOptions];
		
		//formats the font
		string lessUnderscore = Carousel.dataInfo[dataOptions].Replace('_', '\n');
		//settings for making RegistryCrawler's level correct
		if(lessUnderscore.Substring(0,3).Equals("BBa")){
			onPartLevel = true;
			GameObject.Find("RegistryCrawler").GetComponent<RegistryCrawler>().level = 5;
		}
		
		lessUnderscore = lessUnderscore.Replace(' ', '\n');
		int longest = 0;
		IList<string> split = lessUnderscore.Split('\n');
		//IList<string> split = new List<string>();
		//foreach(string word in listOfWords){
			//split.Add(word);
		//}
		/*if(split.Count > 3){
			for (int i = 0; i < split.Count; i++){
				if (split[i].Length < 5){
					if((i+1) < split.Count){
						split[i+1] = split[i] + split[i+1];
						split.Remove(split[i]);
					}else{
						split[i-1] = split[i-1] + split[i];
						split.Remove(split[i]);
					}
				}
			}
		}*/
		
		foreach(string word in split){
			if(word.Length > longest){
				longest = word.Length;
			}
		}
		//string finalText = "";
		//for(int i = 0; i<split.Count; i++){
		//	finalText = finalText + split[i] + '\n';
		//}
		//foreach(string word in split){
		//	finalText = finalText +word + '\n';
		//}
		//label.text = finalText;
		
		
		
		label.text = lessUnderscore;
		
		
		if(label.text.Length == 1){
			label.characterSize = .4f;
		}else if(split.Count >=5){
			label.characterSize = .07f;
		}else{
			label.characterSize = (float)(0.65f/(Math.Pow((double)(longest), 0.81f)));
		}
		
		label.font.material.color = Color.black;
		meshRenderer.renderer.material = label.font.material;
		textLabel.transform.position = textLabel.transform.parent.position;
		textLabel.transform.rotation = textLabel.transform.parent.rotation;
		textLabel.transform.Rotate(Vector3.up * 180f);
		textLabel.transform.Translate(new Vector3(0.47f, .3f, 0f), textLabel.transform.parent);
		//size of card is set
		gameObject.transform.localScale = new Vector3(((2*Mathf.PI*(1/3f))/(1.1f)*.9f), .9f *1f, .05f);
		
		//gets the index of the carousel
		indexOfCarousel = getIndexOfCarousel();
		
		//card colors
		if(indexOfCarousel == 0){
			if(label.text.Equals("Promoters")){
				this.renderer.material.color = Color.green;
				naturalColor = Color.green;
			}else if (label.text.Equals("Terminators")){
				this.renderer.material.color = Color.red;
				naturalColor = Color.red;
			}else if(label.text.Equals("DNA")){
				this.renderer.material.color = Color.yellow;
				naturalColor = Color.yellow;
			}else if(label.text.Equals ("Primers")){
				Color purple = new Color(148/255f, 0/255f, 211/255f, 255f);
				this.renderer.material.color = purple;
				naturalColor = purple;
			}else if(label.text.Equals("Plasmids")){
				Color orange = new Color(255/255f, 104/255f, 31/255f, 255f);
				this.renderer.material.color = orange;
				naturalColor = orange;
			}else if(label.text.Equals("Protein\ndomains")){
				Color pink = new Color(255/255f, 20/255f, 147/255f, 255f);
				this.renderer.material.color = pink;
				naturalColor = pink; 
			}else if(label.text.Equals("Translational\nunits")){
				Color blue = new Color(28/255f, 57/255f, 187/255f, 255f);
				this.renderer.material.color = blue;
				naturalColor = blue;
				}else if(label.text.Equals ("Plasmid\nbackbones")){
				Color green = new Color(102/255f, 255/255f, 102/255f, 255f);
				this.renderer.material.color = green;
				naturalColor = green; 
				}else if (label.text.Equals("Protein\ncoding\nsequences")){
				Color yellow = new Color(252/255f, 194/255f, 0/255f, 255f);
				this.renderer.material.color = yellow;
				naturalColor = yellow;
			}else{
				Color lightBlue = new Color(154/255f, 240/255f, 255/255f, 255f);
				this.renderer.material.color = lightBlue;
				naturalColor = lightBlue;
			}
		}else{
			naturalColor = this.transform.parent.GetComponent<Carousel>().parentCard.naturalColor;
			this.renderer.material.color = naturalColor;
		}
		
		
		//adds the SBOL images
		if(GameObject.Find ("RegistryCrawler").GetComponent<RegistryCrawler>().level == 1)
		{
			//if( (Texture)Resources.Load (lessUnderscore.Replace ("\n", "_")) )
			if( (Texture)Resources.Load (originalInfo) )
			//if( (Texture)Resources.Load (label.GetComponent<TextMesh>().text.Replace ("\n", "_")) )
			{
				//Texture theTexture = (Texture)Resources.Load (label.GetComponent<TextMesh>().text.Replace ("\n", "_"));
				Texture theTexture = (Texture)Resources.Load (originalInfo);
				textLabel.active = false;
				gameObject.transform.renderer.material.mainTexture = theTexture;
			}
		}
		
		carouselOfCard = this.gameObject.transform.parent.gameObject.GetComponent<Carousel>();
		
	}
	
	
	
	
	
	
	// Update is called once per frame
	void Update () {

			
	//iteration is a convoluted way to allow things requiring the regDataSheet to be populated to be called 
	//only after regDataSheet is actually populated.
	//It's hard to do this, because of the way Unity likes to finish out scripts before parts of the scripts are
	// allowed to finish. So, iteration allows us to indicate where in the process the function is as a whole, and give it
	//a frame or two break between steps of the function.
	
	//if(getChildGameObject (gameObject, "partLabel") != null)
/*	if(!labelInfo.Equals ("Please choose a part")){
			iteration = 0;
			if(printer != null)
			{
				printer.done = false;
			}
		}*/
	
	//Checks if the printer is done and information ready to be printed. Otherwise, trying to use the information
	//would result in a null reference (see Infoprint's comments)
	/*if(printer != null && printer.done)
		{
			print("Card.populated is true");
			Card.partPopulated = true;
		}*/
				
		
		
		//Another example of needing a break after part of the function is done to allow population.
		if(callAgain){
			
			penLeftButtonDown ();
		}
		
		/*if(getTheInfo){
			try{
				print ("Get the info is always true.. not getting set to false");
				Infoprint.thePart = InfoTree.selection;
				printer.PartInfo();
				getTheInfo = false; 
			}
			catch{	
			}
			getTheInfo = false;
		}
		
		//checks to see if it can move on to the next part of this function.
		if(printer && printer.done && (getChildGameObject (gameObject, "partLabel") == null) )
		{
			iteration = 1;
			printer.done = false; 
		}
		*/
		
		//if(iteration == 1)
		//{
		
			//getTheInfo = true;
			//iteration = 0;
			//printer.PartInfo();
			//onButtonDownCalled = false;
			
		//}
		
		//if nothing is started, start getting it going
		//if(!Card.partPopulated && selection != null)
		
		
	/*	if(!Card.partPopulated && InfoTree.selection.Substring(0,3).Equals("BBa"))
		{
			printer = GameObject.FindGameObjectWithTag("thePrinter").GetComponent<Infoprint>();
			//RegDataSheet1 theSheet = printer.gameObject.GetComponent<RegDataSheet1>();
			Infoprint.thePart = InfoTree.selection;
			
			if(!InfoTree.partToInfo.ContainsKey (Infoprint.thePart) && Infoprint.thePart.Substring (0,3).Equals ("BBa")){
				print("Doesn't contain the part... printer.partInfo();");
				printer.PartInfo ();
				partPopulated = true; 
				
			}
			
		}*/
	
		
		//this is what happens when the left pen button is clicked.
		if(stylus.GetComponent<ZSStylusSelector>().GetButtonUp(2) && stylus.GetComponent<ZSStylusSelector>().hoveredObject == this.gameObject){
			fileWriter.logData.Add("User pressed left button to get a data sheet");
			
			penLeftButtonDown ();
			//this.transform.position = initPos;
			//IList<Carousel> caroPath = carouselOfCard.carouselPath();
		}
		
		
		
		//When pen hovers over a card, the text appears.
		if(gameObject.renderer.material.mainTexture != null)
		if(stylus.GetComponent<ZSStylusSelector>().hoveredObject == this.gameObject){
			textLabel.active = true;
		}else {
			textLabel.active = false;
		}
		
		
		if(stylus.GetComponent<ZSStylusSelector>().GetButtonUp(0) && stylus.GetComponent<ZSStylusSelector>().hoveredObject == this.gameObject){
			InfoTree.selection = (textLabel.GetComponent<TextMesh>().text.Replace ("\n", "_"));
			fileWriter.logData.Add("User selected a part with the stylus");
			OnButtonDown();
		}
		
		//get it going if nothing has started and something is selected
		/*if(InfoTree.selection.Substring(0,3).Equals("BBa") && !done){
			//print ("calling partInfo() at the end of update because !done");
			print ("never done... update...calling partInfo repeatedly");
			//Infoprint.thePart = InfoTree.selection;
			partInfo();
		} */
		
		
		//Determines the color of the card based on whether it is clicked or not and moves line to appropriate positions
		try{
			if(isClicked == true){//If it is the selected Card, it draws the line from the card to the next Carousel
				Color orange = new Color(255/255f, 141/255f, 46/255f, 255f);
				//this.renderer.material.color = orange;
				this.renderer.material.color = Color.white;
				IList<IList<Carousel>> allLayers = getAllLayers();
				line.GetComponent<LineRenderer>().enabled = true; 
				line.GetComponent<LineRenderer>().SetPosition(0, this.transform.position);
				line.GetComponent<LineRenderer>().SetPosition (1, allLayers[indexOfCarousel+1][orangeLineIndex].GetComponent<Carousel>().anchor.transform.position);
			}else{
				this.renderer.material.color = this.transform.parent.GetComponent<Carousel>().parentCard.naturalColor;
				//Color32 blue = new Color(94/255f, 193/255f, 255/255f, 255f);
				//this.renderer.material.color = blue;
			}
		}catch{
		}
		
		
	}
	
	
	
	
	
	void OnButtonDown(){
		
		done = false;
		
		//gives the location of the card clicked on so the new carousel can spawn underneath it
		Vector3 newCaroPosition = this.transform.position;
		newCaroPosition.y = newCaroPosition.y - 2.5f;
		this.transform.parent.parent.GetComponent<InfoTree>().clickedPosition = newCaroPosition;
		
		//selection = (textLabel.GetComponent<TextMesh>().text.Replace ("\n", "_"));
		//selection = originalInfo;
		//InfoTree.selection = selection; 
		InfoTree.selection = (textLabel.GetComponent<TextMesh>().text.Replace ("\n", "_"));
		//is it on the part level and at the correct step for the data sheet to begin populating?
		if(iteration == 0 || !textLabel.GetComponent<TextMesh>().text.Substring(0,3).Equals("BBa")){
			if(!done){
				Infoprint.thePart = InfoTree.selection;
				//Infoprint.thePart = selection;
			}
			
			//if(selection.Substring(0, 3).Equals ("BBa"))
			if(InfoTree.selection.Substring(0, 3).Equals ("BBa"))
			{
				//if the dictionary hasn't already been populating, go ahead and start populating everything
				if(!InfoTree.partToInfo.ContainsKey (Infoprint.thePart) )
				{
					
					partInfo();
				}
			}
		}
		
		

		IList<IList<Carousel>> allLayers = getAllLayers();
		RegistryCrawler crawler = this.transform.parent.parent.gameObject.GetComponent<InfoTree>().crawler.GetComponent<RegistryCrawler>();
		crawler.level = carouselOfCard.crawlerLevel;
		
		if(crawler.level == 1){
			crawler.secCats = new List<string>();
			crawler.thirdCats = new List<string>();
			crawler.fourthCats = new List<string>();
		}else if (crawler.level == 2){
			crawler.thirdCats = new List<string>();
			crawler.fourthCats = new List<string>();
		}else if (crawler.level ==3 ){
			crawler.fourthCats = new List<string>();
		}
		
		crawler.level++;
		
		//this is the point in this method where we differentiate between single or multiple carousels
			//and if the card is the last carousel. All of the internal if statements handle these cases
			
		//if it's the last card (aka a biological part and not a category) then add it to the cache
		//this should probably also handle the data sheet stuff... maybe we should rethink our allocations of buttons
		//if(selection.Substring(0, 3).Equals ("BBa")){
		if(InfoTree.selection.Substring(0,3).Equals("BBa")){
			isClicked = true;
			//InfoTree.cache.Add(selection);
			InfoTree.cache.Add (InfoTree.selection);
			updateCache();
			
		}else{
			//if it's a multiple carousel, do all of these things
			if(otherClicked() == true){
				isClicked = true;
				//int numListsToPopulate = carouselOfCard.carouselPath ().Count;
				dataInfo = new List<string>();
				//setSelection(selection);
				setSelection (InfoTree.selection);
				
				if(crawler.smallerTree){
					crawler.level = carouselOfCard.crawlerLevel + 2;
				}else {
					crawler.level = carouselOfCard.crawlerLevel + 1;
					
				} 
				
				//setSelection(selection);
				
				crawler.done = false;
				crawler.siteDone = false;
				crawler.Update ();
				dataInfo = getDataList ();
				if(dataInfo.Count >0){
					InfoTree.dataInfo = dataInfo;
				}
				
				Carousel.numCardsToSpawn = dataInfo.Count;
				
				if(allLayers[this.indexOfCarousel+1] != null){
					IList<Carousel> parallelCarousels = allLayers[this.indexOfCarousel + 1];
					foreach(Carousel caro in parallelCarousels){
						caro.transform.localScale = new Vector3(.5f, .5f, .5f);
					}
				}
				Carousel newCaro = this.transform.parent.parent.gameObject.GetComponent<InfoTree>().nextCarouselLayer(dataInfo.Count);
				if(dataInfo.Count > 12){
					newCaro.transform.localScale = new Vector3(.75f, .75f, .75f);
				}
				newCaro.transform.localScale = new Vector3(.5f, .5f, .5f);
				//newCaro.transform.Translate(new Vector3(0f, -2.5f, 0f));
				allLayers[indexOfCarousel+1].Add(newCaro);
				this.transform.parent.parent.GetComponent<InfoTree>().layers = allLayers;
				newCaro.indexInLayer = allLayers[indexOfCarousel+1].Count -1;
				newCaro.indexInLayers = indexOfCarousel+1;
				newCaro.parentCard = this.gameObject.GetComponent<Card>(); 
				makeOrangeLines (newCaro);
				
				//if it's a single carousel do these things instead
			}else{
				//crawler.level = carouselOfCard.crawlerLevel;
				isClicked = true;
				if(crawler.smallerTree){
					crawler.level = carouselOfCard.crawlerLevel + 2;
				}else {
					crawler.level = carouselOfCard.crawlerLevel + 1;
				} 
				
				
				setSelection(InfoTree.selection);
				
				//can't clear here, removes all functionality
				//this.transform.parent.parent.gameObject.GetComponent<InfoTree>().clearRegistryCrawler();
				//dataInfo = new List<string>();
				
				
				crawler.done = false; 
				crawler.siteDone = false;
				crawler.Update();
				dataInfo = getDataList();
				
				if(dataInfo.Count > 0){
					InfoTree.dataInfo = dataInfo; 
					
					Carousel.numCardsToSpawn = dataInfo.Count;
					Carousel newCaro = this.transform.parent.parent.gameObject.GetComponent<InfoTree>().nextCarouselLayer(dataInfo.Count);
					//newCaro.dataInfo = dataInfo;
					IList<Carousel> newCarouselList = new List<Carousel>();
					newCarouselList.Add (newCaro);
					if(dataInfo.Count>12){
						newCaro.transform.localScale = new Vector3(.75f, .75f, .75f);
					}
					newCaro.indexInLayer = 0;
					newCaro.indexInLayers = indexOfCarousel+1;
					this.transform.parent.parent.gameObject.GetComponent<InfoTree>().layers.Add(newCarouselList);
					makeOrangeLines(newCaro);
					newCaro.indexInLayerOfMomma = carouselOfCard.indexInLayer;
					newCaro.parentCard = this.gameObject.GetComponent<Card>();
				}
			}
			//}
		}
		//after everything is populated, this can now happen. getTheInfo can be set to true, which indicates that 
		//everything is populated.
		if(iteration == 1)
		{
			print ("gettheinfo is always true");
			getTheInfo = true;
			//printer.PartInfo();
			onButtonDownCalled = false;
			iteration = 0; 
		}
		
	}
	
	
	
	
	
	//gets the list of layers from InfoTree
	public IList<IList<Carousel>> getAllLayers(){
		IList<IList<Carousel>> allLayers =  this.transform.parent.parent.GetComponent<InfoTree>().layers;
		return allLayers;
	}
	
	
	
	
	
	
	//this finds out which layer a carousel is in
	public int getIndexOfCarousel(){
		IList<IList<Carousel>> allLayers = getAllLayers ();
		foreach(IList<Carousel> layer in allLayers){
			foreach(Carousel caro in layer){
				if(this.transform.parent.GetComponent<Carousel>() == caro){
					return allLayers.IndexOf(layer);
				}
			}
		}
		return -1;
	}
	
	
	
	
	
	
	
	//this checks to see if the carousel that the present card is in has another card that was clicked on.
	public bool otherClicked(){
		IList<IList<Carousel>> allLayers = getAllLayers();
		foreach(Carousel caro in allLayers[indexOfCarousel]){
			foreach(Card ca in caro.cards){
				if(ca.isClicked ==true){
					return true;
				}
			}
		}
		return false; 
		}
		
		
		
		
		
		
	//this method draws lines from the card that was clicked on to the anchor of the new carousel it spawned
	// just used as a way to make the data easier to interpret. The lines stretch and move as the carousels do.
	void makeOrangeLines(Carousel newCaro){
		line = new GameObject();
		IList<IList<Carousel>> allLayers = getAllLayers();
		line.transform.parent = newCaro.transform;
	
		line.name = "OrangeLine";
		LineRenderer lineRenderer= line.AddComponent<LineRenderer>();
		lineRenderer.enabled = false;
		lineRenderer.material = new Material(Shader.Find("Particles/Additive"));
		Color orange = new Color(255/255f, 141/255f, 46/255f, 255f);
		//lineRenderer.SetColors(orange, orange);
		lineRenderer.SetColors (Color.white, Color.white);
		lineRenderer.SetWidth(0.1f, 0.1f);
		lineRenderer.SetVertexCount(2);
		orangeLineIndex = newCaro.indexInLayer;
		
		}
	
	
	
	
	
	
	
	//this goes into registryCrawler and gets the information for the carousel depending on the level of the carousel
	public IList<String> getDataList(){
		RegistryCrawler crawler = this.transform.parent.parent.gameObject.GetComponent<InfoTree>().crawler.GetComponent<RegistryCrawler>();
		
		if(crawler.level == 1){
			return crawler.categories;
		}else if(crawler.level == 2){
			return crawler.secCats;
		}else if (crawler.level == 3){
			return crawler.thirdCats;
		}else if (crawler.level == 4){
			return crawler.fourthCats;
		}else{
			return new List<String>();
		}
	}
	
	
	
	
	
	
	
	
	public string partInfo(){
		//done = true; 
		//this really only applies in the case of a part. Is it a part?
		if(InfoTree.selection.Substring (0, 3).Equals ("BBa"))
			//if(textLabel.GetComponent<TextMesh>().text.Substring (0, 3).Equals ("BBa"))
		{
			
			string partName;
			//partName = gameObject.GetComponent<Card>().textLabel.GetComponent<TextMesh>().text;
			partName = InfoTree.selection; 
			//print (partName);
			
			//the printer is specific to the part that is selected - the old one must be DESTROYED!
			foreach(GameObject obj in GameObject.FindGameObjectsWithTag("thePrinter"))
			{
				Destroy(obj);
			}
			
			//makes a "part" GameObject which will be able to print its information
			
			GameObject part = new GameObject("part");
			part.tag = "thePrinter";
			
			//partName = partName.Replace ("\n", "_");
			
			//Infoprint.thePart = partName;
			//Infoprint.thePart = InfoTree.selection;
			part.AddComponent<Infoprint>();
			printer = GameObject.FindGameObjectWithTag("thePrinter").GetComponent<Infoprint>();
			
			
			//done = true;
			
			//partInfoCalled = false;
			return partName;
			//return Infoprint.thePart;
		}
		else {
		}
		return "testOffPart";
	}
	
	
	
	
	
	
	
	//this updates the choices in RegistryCrawler depending on the level and the card clicked on so it can search
	//and find the information for the next carousel
	public void setSelection(string selection){
		RegistryCrawler crawler = this.transform.parent.parent.gameObject.GetComponent<InfoTree>().crawler.GetComponent<RegistryCrawler>();
		
		if(crawler.level == 2){
			crawler.topChoice = selection;
		}else if (crawler.level == 3){
			crawler.secChoice = selection;
		}else if (crawler.level == 4){
			crawler.thirdChoice = selection;
		}else{
			//return new List<String>();
		}
	}
	
	
	
	
	
	
	
	//this adds the clicked on cards to the cache. Presently the cache has no uses other than to display your choices
	void updateCache(){
		//list of all things in the cache
		IList<string> cache = InfoTree.cache;
		
		//creates the object for the card and gives it some settings
		GameObject cacheCard = GameObject.CreatePrimitive(PrimitiveType.Cube);
		cacheCard.transform.parent = this.transform.parent.parent.GetComponent<InfoTree>().camera.transform;
		cacheCard.transform.localPosition = new Vector3(-3f, 3f - .5f*cache.Count, 7f);
		Color orange = new Color(255/255f, 141/255f, 46/255f, 255f);
		//cacheCard.renderer.material.color = orange;
		cacheCard.renderer.material.color = naturalColor;
		cacheCard.transform.localScale = new Vector3(((2*Mathf.PI*(1/3f))/(1.1f)*.9f)/2f, (.9f *1f)/2f, (.05f)/2f); 
		
		//label settings
		GameObject label = new GameObject("cardLab");
		label.transform.parent = cacheCard.transform;
		label.transform.position = cacheCard.transform.position;
		label.AddComponent<TextMesh>();
		var labelMesh = label.GetComponent<TextMesh>();
		var meshRenderer = label.AddComponent("MeshRenderer");
		var fontResource = Resources.Load ("Aller_Rg");
		labelMesh.font = (Font)fontResource;
		
		//fixing text size
		string lessUnderscore = InfoTree.cache[InfoTree.cache.Count - 1];
		lessUnderscore = lessUnderscore.Replace(' ', '\n');
		int longest = 0;
		IList<string> split = lessUnderscore.Split('\n');
		foreach(string word in split){
			if(word.Length > longest){
				longest = word.Length;
			}
		}
		labelMesh.text = lessUnderscore;	
		if(labelMesh.text.Length == 1){
			labelMesh.characterSize = .2f;
		}else if(split.Count >=5){
			labelMesh.characterSize = .045f;
		}else{
			labelMesh.characterSize = (float)((0.85f/(Math.Pow((double)(longest), 0.74)))/2);
		}
		labelMesh.font.material.color = Color.black;
		meshRenderer.renderer.material = labelMesh.font.material;
		label.transform.position = label.transform.parent.position;
		label.transform.Translate(new Vector3(-.375f, .15f, 0f), label.transform.parent);
		fileWriter.logData.Add("Added a part to the cache");
	}
	
	
	
	
	
	
	
	//this is what happens when you press the left stylus button
	//It should spawn the datasheet with the info about the part clicked on.
	public void penLeftButtonDown(){
	print ("penleftbuttonDown called");
		//if(InfoTree.selection.Substring(0,3).Equals("BBa")){
			//InfoTree.selection = (textLabel.GetComponent<TextMesh>().text.Replace ("\n", "_"));
			//selection = (textLabel.GetComponent<TextMesh>().text.Replace ("\n", "_"));
		callAgain = false; 	
		Infoprint.thePart = InfoTree.selection; 
			//print (InfoTree.selection);
			
			
		if(InfoTree.partToInfo.ContainsKey(InfoTree.selection)){
			callAgain = false; 
			//iteration = 1; 
			
			//string theKey = originalInfo;
			string theKey = InfoTree.selection;
			
			//textLabel.GetComponent<TextMesh>().text.Replace ("\n", "_");
			partInformation = InfoTree.partToInfo[theKey];
			//print (InfoTree.partToInfo[theKey]);
			
			print("This is the part Information" + partInformation);
			Card.labelInfo = partInformation;
			
			//iteration = 0; 
			
			
		}
		else {
			if(!onButtonDownCalled){
			print ("second part of left button down");
				//print ("doing left button stuff...pt 2");
				//if(iteration == 0){
				//	if(!done){
						Infoprint.thePart = InfoTree.selection;
						//print(Infoprint.thePart);
						//Infoprint.thePart = selection;
					}
					
					if(InfoTree.selection.Substring(0,3).Equals ("BBa")){
						//if the dictionary hasn't already been populating, go ahead and start populating everything
						if(!InfoTree.partToInfo.ContainsKey (Infoprint.thePart) ){
							//print ("Calling part Info");
							partInfo();
							
						}
					}
			//	}
				
			//}
			
			callAgain = true;
		}
	}


	
	
	

	
	
	//method pulled from the web to access children of objects
	static public GameObject getChildGameObject(GameObject fromGameObject, string withName) {
		//Author: Isaac Dart, June-13.
		Transform[] ts = fromGameObject.transform.GetComponentsInChildren<Transform>();
		foreach (Transform t in ts) if (t.gameObject.name == withName) return t.gameObject;
		return null;
	}
	
	
	//preliminary search function
	//works the same as left pen down for right now
	
}