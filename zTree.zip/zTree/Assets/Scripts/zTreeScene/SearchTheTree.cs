using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class SearchTheTree : MonoBehaviour {


	public static string searchString, nameString, name;
	
	public bool windowActive; 
	
	public bool callAgainSearch;
	
	public Infoprint printer; 
	
	public Rect window;
	
	//public GameObject fileWriter; 

	// Use this for initialization
	void Start () {
		
		//.GetComponent<FileWriter>();
		nameString = "Please enter your name here";
		window = new Rect(Screen.width/2f-150f, Screen.height/2f-100f, 300, 200);
		searchString = "Search here:";
		windowActive = true;
		callAgainSearch = false; 
		name = ""; 
		
	
	}
	
	// Update is called once per frame
	void Update () {
		
		if(callAgainSearch){
			searchParts ();
		} 
	
	}
	
	void OnGUI(){
		//GUI Directions for using zTree
		GUI.Box (new Rect(20, 20, 300, 150), "Keyboard Commands");
		GUI.Label(new Rect(25, 45, 280, 130), "Rotate Carousel: Left and Right Arrow Keys \n\nChange selected: Up" 
			+ ", Down, and Left Stylus \n\t\t\t\t\t\t\tKeys or Click on Anchor \n\nDelete layers: Space bar");
		
		//GUI Info for the part information
		GUI.Box (new Rect(Screen.width - 330, Screen.height - 500, 320, 460), "Part Information");
		GUI.Label(new Rect(Screen.width - 320, Screen.height - 460, 310, 420), Card.labelInfo);
		
		//search box for parts registry... upper right corner
		searchString = GUI.TextField(new Rect(Screen.width - 200, 40, 175, 60), searchString, 40);
		Event e = Event.current;
		if (e.keyCode == KeyCode.Return){
			InfoTree.selection = searchString.Replace(" ", "_");
			searchParts();
		}
		
		if(GUI.Button (new Rect(20, Screen.height - 60, 200, 40), "Export cache to text file")){
			GameObject fw = GameObject.Find("FileWriter");
			fw.GetComponent<FileWriter>().writeCache();
		}
		
		if(windowActive == true){
			window = GUI.Window(0, window, DoMyWindow, "Enter your name here:");
		}
	}
	
	void searchParts(){
		callAgainSearch = false;
		Infoprint.thePart = InfoTree.selection; 
		
		if(InfoTree.partToInfo.ContainsKey(InfoTree.selection)){
			callAgainSearch = false;
			string theKey = InfoTree.selection;
			//Card.partInformation = InfoTree.partToInfo[theKey];
			Card.labelInfo = InfoTree.partToInfo[theKey];
			GameObject fw = GameObject.Find("FileWriter");
			fw.GetComponent<FileWriter>().logData.Add("User tried to search for a part"); 
			
			
						
		}else {	
				if(InfoTree.selection.Substring(0, 3).Equals ("BBa")){
				//if the dictionary hasn't already been populating, go ahead and start populating everything
				if(!InfoTree.partToInfo.ContainsKey (Infoprint.thePart) ){
					
					partInfo();
				}
				
			}
			callAgainSearch = true;
		}
	}
	
	
	public string partInfo(){
	//this really only applies in the case of a part. Is it a part?
		if(InfoTree.selection.Substring (0, 3).Equals ("BBa"))
		//if(textLabel.GetComponent<TextMesh>().text.Substring (0, 3).Equals ("BBa"))
		{
		
			string partName;
			partName = InfoTree.selection; 
			//the printer is specific to the part that is selected - the old one must be DESTROYED!
			foreach(GameObject obj in GameObject.FindGameObjectsWithTag("thePrinter"))
			{
				Destroy(obj);
			}
			
			//makes a "part" GameObject which will be able to print its information
			
			GameObject part = new GameObject("part");
			part.tag = "thePrinter";
			part.AddComponent<Infoprint>();
			printer = GameObject.FindGameObjectWithTag("thePrinter").GetComponent<Infoprint>();
			return partName;
		}
		else {
		}
		return "testOffPart";
	} 
	
	void DoMyWindow(int windowID){
		nameString = GUI.TextField(new Rect(50, 40, 200, 60), nameString, 30);
		Event e = Event.current;
		if (e.keyCode == KeyCode.Return){
			windowActive = false; 
			GameObject fw = GameObject.Find("FileWriter");
			fw.GetComponent<FileWriter>().logData.Add("User entered their name");
			name = nameString;
		}
		
	
	}
	
	
}
