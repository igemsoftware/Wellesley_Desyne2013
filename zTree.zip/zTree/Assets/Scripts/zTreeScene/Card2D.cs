using UnityEngine;
using System.Collections;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class Card2D : MonoBehaviour {
	//How many cards
	public int dataOptions;
	public Carousel2D carouselOfCard;
	public static bool onPartLevel;
	
	public bool done, getTheInfo, callAgain, OnMouseDownCalled;
	public static bool partPopulated;
	
	//States whether or not the card has been clicked
	public bool isClicked, hovered;
	
	//The text on the card
	public GameObject textLabel;
	
	public IList<String> dataInfo; 
	
	//Yellow line that connects carousels
	private GameObject line;
	
	//Which carousel
	private int indexOfCarousel;
	
	private int orangeLineIndex;
	 
	public int iteration;
	
	public string selection;
	
	public static string selected; 
	
	public Infoprint2D printer;
	
	public GameObject stylus; 
	
	public GameObject camera;
	
	public string partInformation;
	
	public static string labelInfo;
	
	
	
	
	
	
	// Use this for initialization
	public void Start () {
	
	
		partInformation = ""; 
		Card2D.labelInfo = "Please choose a part";
		//finds pen
		stylus = GameObject.Find ("ZSStylus");
		
		//sets all the cards to not clicked
		isClicked = false;
		
		//card colors
		Color lightBlue = new Color(154/255f, 240/255f, 255/255f, 255f);
		this.renderer.material.color = lightBlue;
		
		//Adds a Rigidbody to the card
		gameObject.AddComponent<Rigidbody>();
		gameObject.GetComponent<Rigidbody>().useGravity = false;
		gameObject.GetComponent<Rigidbody>().mass = Mathf.Infinity;
		
		//Adds the text labels to the cards and adjusts their position, size, and color.
		textLabel = new GameObject("cardLabel");
		textLabel.transform.parent = gameObject.transform;
		textLabel.transform.tag = "lab";
		textLabel.AddComponent<TextMesh>();
		var label = textLabel.GetComponent<TextMesh>();
		var meshRenderer = textLabel.AddComponent("MeshRenderer");
		var fontResource = Resources.Load ("Aller_Rg");
		label.font = (Font)fontResource;
		
		
		gameObject.name = Carousel2D.dataInfo[dataOptions-1];
		
		//formats the font
		string lessUnderscore = Carousel2D.dataInfo[dataOptions-1].Replace('_', '\n');
		//settings for making RegistryCrawler's level correct
		if(lessUnderscore.Substring(0,3).Equals("BBa")){
			onPartLevel = true;
			GameObject.Find("RegistryCrawler").GetComponent<RegistryCrawler>().level = 5;
		}
		
		lessUnderscore = lessUnderscore.Replace(' ', '\n');
		int longest = 0;
		IList<string> split = lessUnderscore.Split('\n');
		//IList<string> split = new List<string>();
		//foreach(string word in listOfWords){
			//split.Add(word);
		//}
		/*if(split.Count > 3){
			for (int i = 0; i < split.Count; i++){
				if (split[i].Length < 5){
					if((i+1) < split.Count){
						split[i+1] = split[i] + split[i+1];
						split.Remove(split[i]);
					}else{
						split[i-1] = split[i-1] + split[i];
						split.Remove(split[i]);
					}
				}
			}
		}*/
		
		foreach(string word in split){
			if(word.Length > longest){
				longest = word.Length;
			}
		}
		//string finalText = "";
		//for(int i = 0; i<split.Count; i++){
		//	finalText = finalText + split[i] + '\n';
		//}
		//foreach(string word in split){
		//	finalText = finalText +word + '\n';
		//}
		//label.text = finalText;
		
		
		
		label.text = lessUnderscore;
		
		
		if(label.text.Length == 1){
			label.characterSize = .4f;
		}else if(split.Count >=5){
			label.characterSize = .07f;
		}else{
			label.characterSize = (float)(0.65f/(Math.Pow((double)(longest), 0.81f)));
		}
		
		label.font.material.color = Color.black;
		meshRenderer.renderer.material = label.font.material;
		textLabel.transform.position = textLabel.transform.parent.position;
		textLabel.transform.rotation = textLabel.transform.parent.rotation;
		textLabel.transform.Rotate(Vector3.up * 180f);
		textLabel.transform.Translate(new Vector3(0.47f, .3f, 0f), textLabel.transform.parent);
		//size of card is set
		gameObject.transform.localScale = new Vector3(((2*Mathf.PI*(1/3f))/(1.1f)*.9f), .9f *1f, .05f);
		
		//gets the index of the carousel
		indexOfCarousel = getIndexOfCarousel();
		
		//adds the SBOL images
		if(GameObject.Find ("RegistryCrawler").GetComponent<RegistryCrawler>().level == 1)
		{
			if( (Texture)Resources.Load (lessUnderscore.Replace ("\n", "_")) )
			//if( (Texture)Resources.Load (label.GetComponent<TextMesh>().text.Replace ("\n", "_")) )
			{
				Texture theTexture = (Texture)Resources.Load (label.GetComponent<TextMesh>().text.Replace ("\n", "_"));
				textLabel.active = false;
				gameObject.transform.renderer.material.mainTexture = theTexture;
			}
		}
		
		carouselOfCard = this.gameObject.transform.parent.gameObject.GetComponent<Carousel2D>();
		
	}
	
	
	
	
	
	
	// Update is called once per frame
	void Update () {
	//iteration is a convoluted way to allow things requiring the regDataSheet to be populated to be called 
	//only after regDataSheet is actually populated.
	//It's hard to do this, because of the way Unity likes to finish out scripts before parts of the scripts are
	// allowed to finish. So, iteration allows us to indicate where in the process the function is as a whole, and give it
	//a frame or two break between steps of the function.
	
	//if(getChildGameObject (gameObject, "partLabel") != null)
	if(!labelInfo.Equals ("Please choose a part"))
		{
		//print ("grrr");
		iteration = 0;
		if(printer != null)
		{
		printer.done = false;
		}
		}
	
	//Checks if the printer is done and information ready to be printed. Otherwise, trying to use the information
	//would result in a null reference (see Infoprint's comments)
	if(printer != null && printer.done)
				{
				Card2D.partPopulated = true;
				}
				
		//When mouse hovers over a card, the text appears.
		if(gameObject.renderer.material.mainTexture != null)
		
		
		
		
		//Another example of needing a break after part of the function is done to allow population.
		if(callAgain){
			LeftButtonDown ();
		}
		
		if(getTheInfo)
		{
			try{
				Infoprint2D.thePart = selection.Replace ("\n", "_");
				printer.PartInfo();
			}
			catch{
				
			}
			//InfoTree.partToInfo.Add(Infoprint.thePart, r.ToString ());
			getTheInfo = false;
		}
		//checks to see if it can move on to the next part of this function.
		if(printer && printer.done && (getChildGameObject (gameObject, "partLabel") == null) )
		{
			iteration = 1;
		}
		
		
		//if nothing is started, start getting it going
		if(!Card2D.partPopulated && selection != null)
		{
			//try{
				
				printer = GameObject.FindGameObjectWithTag("thePrinter").GetComponent<Infoprint2D>();
				//RegDataSheet1 theSheet = printer.gameObject.GetComponent<RegDataSheet1>();
				Infoprint2D.thePart = selection.Replace ("\n", "_");
				if(!InfoTree2D.partToInfo.ContainsKey (Infoprint2D.thePart) && Infoprint2D.thePart.Substring (0,3).Equals ("BBa")){
				//print (Infoprint.thePart + " is the part ");
				printer.PartInfo ();
				}
				
				//Card.partPopulated = true;
				//}
			//catch{
				
			//}
		}
		
		
		
		//same with LeftButtonDown
		if(Input.GetMouseButtonDown (1) && hovered){
			
			LeftButtonDown ();
			//IList<Carousel2D> caroPath = carouselOfCard.carouselPath();
		}
		
		
		
		//Determines the color of the card based on whether it is clicked or not and moves line to appropriate positions
		try{
			if(isClicked == true){//If it is the selected Card, it draws the line from the card to the next Carousel
				Color orange = new Color(255/255f, 141/255f, 46/255f, 255f);
				this.renderer.material.color = orange;
				
				IList<IList<Carousel2D>> allLayers = getAllLayers();
				line.GetComponent<LineRenderer>().enabled = true; 
				line.GetComponent<LineRenderer>().SetPosition(0, this.transform.position);
				line.GetComponent<LineRenderer>().SetPosition (1, allLayers[indexOfCarousel+1][orangeLineIndex].GetComponent<Carousel2D>().anchor.transform.position);
			}else{
				
				Color32 blue = new Color(94/255f, 193/255f, 255/255f, 255f);
				this.renderer.material.color = blue;
			}
		}catch{
		}
		
		//Determines the color of the card based on whether it is clicked or not.
		
		//get it going if nothing has started and something is selected
		if(selection != null && !done)
		{
			partInfo();
		}
		
		if(Input.GetMouseButtonDown(0) && hovered)
		{
		theMousePushed();
		}
		
	}
	
	
	
	
	
	void theMousePushed(){
	done = false;
		Vector3 newCaroPosition = this.transform.position;
		newCaroPosition.y = newCaroPosition.y - 2.5f;
		this.transform.parent.parent.GetComponent<InfoTree2D>().clickedPosition = newCaroPosition;
		
		selection = (textLabel.GetComponent<TextMesh>().text.Replace ("\n", "_"));
		
		//is it on the part level and at the correct step for the data sheet to begin populating?
		if(iteration == 0 || !textLabel.GetComponent<TextMesh>().text.Substring(0,3).Equals("BBa")){
			if(!done){
				
				Infoprint2D.thePart = selection;
				}
				
				if(selection.Substring(0, 3).Equals ("BBa"))
				{
				//if the dictionary hasn't already been populating, go ahead and start populating everything
					if(!InfoTree2D.partToInfo.ContainsKey (Infoprint2D.thePart) )
					{
						partInfo();
					}
				}
		}
		
		
		

		
		
			IList<IList<Carousel2D>> allLayers = getAllLayers();
			RegistryCrawler crawler = this.transform.parent.parent.gameObject.GetComponent<InfoTree2D>().crawler.GetComponent<RegistryCrawler>();
			crawler.level = carouselOfCard.crawlerLevel;
			
		if(crawler.level == 1){
			crawler.secCats = new List<string>();
			crawler.thirdCats = new List<string>();
			crawler.fourthCats = new List<string>();
		}else if (crawler.level == 2){
			crawler.thirdCats = new List<string>();
			crawler.fourthCats = new List<string>();
		}else if (crawler.level ==3 ){
			crawler.fourthCats = new List<string>();
		}
			//print (carouselOfCard.crawlerLevel);
			//if(crawler.level == 4){
			//	crawler.level++;
			//}
			
			crawler.level++;
			
			//this is the point in this method where we differentiate between single or multiple carousels
			//and if the card is the last carousel. All of the internal if statements handle these cases
		if(Input.GetMouseButtonDown (0)){
			
			//if it's the last card (aka a biological part and not a category) then add it to the cache
			//this should probably also handle the data sheet stuff... maybe we should rethink our allocations of buttons
			if(selection.Substring(0, 3).Equals ("BBa")){
				isClicked = true;
				InfoTree2D.cache.Add(selection);
				updateCache();
		
			}else{
				//if it's a multiple carousel, do all of these things
				if(otherClicked() == true){
					//this.transform.parent.parent.gameObject.GetComponent<InfoTree>().clearRegistryCrawler();
					
					//int numListsToPopulate = carouselOfCard.carouselPath ().Count;
					foreach(Carousel2D caro in carouselOfCard.caroPath)
					{
					if(caro.crawlerLevel == 1)
					{
					//categories = caro.
					}
					}
					
					dataInfo = new List<string>();
					setSelection(selection);
					
					if(crawler.smallerTree){
						crawler.level = carouselOfCard.crawlerLevel + 2;
						}else {
						crawler.level = carouselOfCard.crawlerLevel + 1;
									
					} 
						
					
						setSelection(selection);
					
					
					
					crawler.done = false;
					crawler.siteDone = false;
					crawler.Update ();
					dataInfo = getDataList ();
					if(dataInfo.Count >0){
						InfoTree2D.dataInfo = dataInfo;
					}
					this.isClicked = true; 
					Carousel2D.numCardsToSpawn = dataInfo.Count;
					if(allLayers[this.indexOfCarousel+1] != null){
					IList<Carousel2D> parallelCarousels = allLayers[this.indexOfCarousel + 1];
					foreach(Carousel2D caro in parallelCarousels){
						caro.transform.localScale = new Vector3(.5f, .5f, .5f);
					}
					}
					Carousel2D newCaro = this.transform.parent.parent.gameObject.GetComponent<InfoTree2D>().nextCarouselLayer(dataInfo.Count);
					if(dataInfo.Count > 12){
						newCaro.transform.localScale = new Vector3(.75f, .75f, .75f);
					}
					newCaro.transform.localScale = new Vector3(.5f, .5f, .5f);
					//newCaro.transform.Translate(new Vector3(0f, -2.5f, 0f));
					allLayers[indexOfCarousel+1].Add(newCaro);
					this.transform.parent.parent.GetComponent<InfoTree2D>().layers = allLayers;
					newCaro.indexInLayer = allLayers[indexOfCarousel+1].Count -1;
					newCaro.indexInLayers = indexOfCarousel+1;
					newCaro.parentCard = this.gameObject.GetComponent<Card2D>(); 
					makeOrangeLines (newCaro);
					
				//if it's a single carousel do these things instead
				}else{
					//crawler.level = carouselOfCard.crawlerLevel;
					
					if(crawler.smallerTree){
						crawler.level = carouselOfCard.crawlerLevel + 2;
					}else {
						crawler.level = carouselOfCard.crawlerLevel + 1;
					} 
						
					
						setSelection(selection);
					
					//can't clear here, removes all functionality
					//this.transform.parent.parent.gameObject.GetComponent<InfoTree>().clearRegistryCrawler();
					//dataInfo = new List<string>();
					
					
					crawler.done = false; 
					crawler.siteDone = false;
					crawler.Update();
					dataInfo = getDataList();
					
					if(dataInfo.Count > 0){
						InfoTree2D.dataInfo = dataInfo; 
						this.isClicked = true;
						Carousel.numCardsToSpawn = dataInfo.Count;
						Carousel2D newCaro = this.transform.parent.parent.gameObject.GetComponent<InfoTree2D>().nextCarouselLayer(dataInfo.Count);
						//newCaro.dataInfo = dataInfo;
						IList<Carousel2D> newCarouselList = new List<Carousel2D>();
						newCarouselList.Add (newCaro);
						if(dataInfo.Count>12){
							newCaro.transform.localScale = new Vector3(.75f, .75f, .75f);
						}
						newCaro.indexInLayer = 0;
						newCaro.indexInLayers = indexOfCarousel+1;
						this.transform.parent.parent.gameObject.GetComponent<InfoTree2D>().layers.Add(newCarouselList);
						makeOrangeLines(newCaro);
						newCaro.indexInLayerOfMomma = carouselOfCard.indexInLayer;
						newCaro.parentCard = this.gameObject.GetComponent<Card2D>();
					}
				}
			}
		}
		//after everything is populated, this can now happen. getTheInfo can be set to true, which indicates that 
		//everything is populated.
		if(iteration == 1)
		{
		
			getTheInfo = true;
			iteration = 0;
			//printer.PartInfo();
			OnMouseDownCalled = false;
			
		}
		
	}
	
	
	
	
	
	//gets the list of layers from InfoTree
	public IList<IList<Carousel2D>> getAllLayers(){
		IList<IList<Carousel2D>> allLayers =  this.transform.parent.parent.GetComponent<InfoTree2D>().layers;
		return allLayers;
	}
	
	
	
	
	
	
	//this finds out which layer a carousel is in
	public int getIndexOfCarousel(){
		IList<IList<Carousel2D>> allLayers = getAllLayers ();
		foreach(IList<Carousel2D> layer in allLayers){
			foreach(Carousel2D caro in layer){
				if(this.transform.parent.GetComponent<Carousel2D>() == caro){
					return allLayers.IndexOf(layer);
				}
			}
		}
		return -1;
	}
	
	
	
	
	
	
	
	//this checks to see if the carousel that the present card is in has another card that was clicked on.
	public bool otherClicked(){
		IList<IList<Carousel2D>> allLayers = getAllLayers();
		foreach(Carousel2D caro in allLayers[indexOfCarousel]){
			foreach(Card2D ca in caro.cards){
				if(ca.isClicked ==true){
					return true;
				}
			}
		}
		return false; 
		}
		
		
		
		
		
		
	//this method draws lines from the card that was clicked on to the anchor of the new carousel it spawned
	// just used as a way to make the data easier to interpret. The lines stretch and move as the carousels do.
	void makeOrangeLines(Carousel2D newCaro){
		line = new GameObject();
		IList<IList<Carousel2D>> allLayers = getAllLayers();
		line.transform.parent = newCaro.transform;
	
		line.name = "OrangeLine";
		LineRenderer lineRenderer= line.AddComponent<LineRenderer>();
		lineRenderer.enabled = false;
		lineRenderer.material = new Material(Shader.Find("Particles/Additive"));
		Color orange = new Color(255/255f, 141/255f, 46/255f, 255f);
		lineRenderer.SetColors(orange, orange);
		
		lineRenderer.SetWidth(0.1f, 0.1f);
		lineRenderer.SetVertexCount(2);
		orangeLineIndex = newCaro.indexInLayer;
		
		}
	
	
	
	
	
	
	
	//this goes into registryCrawler and gets the information for the carousel depending on the level of the carousel
	public IList<String> getDataList(){
		RegistryCrawler crawler = this.transform.parent.parent.gameObject.GetComponent<InfoTree2D>().crawler.GetComponent<RegistryCrawler>();
		
		if(crawler.level == 1){
			return crawler.categories;
		}else if(crawler.level == 2){
			return crawler.secCats;
		}else if (crawler.level == 3){
			return crawler.thirdCats;
		}else if (crawler.level == 4){
			return crawler.fourthCats;
		}else{
			return new List<String>();
		}
	}
	
	
	
	
	
	
	
	
	public string partInfo(){
	//this really only applies in the case of a part. Is it a part?
		if(textLabel.GetComponent<TextMesh>().text.Substring (0, 3).Equals ("BBa"))
		{
		
			string partName;
			partName = gameObject.GetComponent<Card2D>().textLabel.GetComponent<TextMesh>().text;

			//the printer is specific to the part that is selected - the old one must be DESTROYED!
			foreach(GameObject obj in GameObject.FindGameObjectsWithTag("thePrinter"))
			{
				Destroy(obj);
			}
			
			//makes a "part" GameObject which will be able to print its information
			
			GameObject part = new GameObject("part");
			part.tag = "thePrinter";
			
			partName = partName.Replace ("\n", "_");
			Infoprint2D.thePart = partName;
			part.AddComponent<Infoprint2D>();
			
			printer = GameObject.FindGameObjectWithTag("thePrinter").GetComponent<Infoprint2D>();
			done = true;
			
			//partInfoCalled = false;
			return partName;
		}
		else {
		}
		return "testOffPart";
	}
	
	
	
	
	
	
	
	//this updates the choices in RegistryCrawler depending on the level and the card clicked on so it can search
	//and find the information for the next carousel
	public void setSelection(string selection){
		RegistryCrawler crawler = this.transform.parent.parent.gameObject.GetComponent<InfoTree2D>().crawler.GetComponent<RegistryCrawler>();
		
		if(crawler.level == 2){
			crawler.topChoice = selection;
		}else if (crawler.level == 3){
			crawler.secChoice = selection;
		}else if (crawler.level == 4){
			crawler.thirdChoice = selection;
		}else{
			//return new List<String>();
		}
	}
	
	
	
	
	
	
	
	//this adds the clicked on cards to the cache. Presently the cache has no uses other than to display your choices
	void updateCache(){
		//list of all things in the cache
		IList<string> cache = InfoTree2D.cache;
		
		//creates the object for the card and gives it some settings
		GameObject cacheCard = GameObject.CreatePrimitive(PrimitiveType.Cube);
		cacheCard.transform.parent = this.transform.parent.parent.GetComponent<InfoTree2D>().camera.transform;
		cacheCard.transform.localPosition = new Vector3(-3f, 3f - .5f*cache.Count, 7f);
		Color orange = new Color(255/255f, 141/255f, 46/255f, 255f);
		cacheCard.renderer.material.color = orange;
		cacheCard.transform.localScale = new Vector3(((2*Mathf.PI*(1/3f))/(1.1f)*.9f)/2f, (.9f *1f)/2f, (.05f)/2f); 
		
		//label settings
		GameObject label = new GameObject("cardLab");
		label.transform.parent = cacheCard.transform;
		label.transform.position = cacheCard.transform.position;
		label.AddComponent<TextMesh>();
		var labelMesh = label.GetComponent<TextMesh>();
		var meshRenderer = label.AddComponent("MeshRenderer");
		var fontResource = Resources.Load ("Aller_Rg");
		labelMesh.font = (Font)fontResource;
		
		//fixing text size
		string lessUnderscore = InfoTree2D.cache[InfoTree2D.cache.Count - 1];
		lessUnderscore = lessUnderscore.Replace(' ', '\n');
		int longest = 0;
		IList<string> split = lessUnderscore.Split('\n');
		foreach(string word in split){
			if(word.Length > longest){
				longest = word.Length;
			}
		}
		labelMesh.text = lessUnderscore;	
		if(labelMesh.text.Length == 1){
			labelMesh.characterSize = .2f;
		}else if(split.Count >=5){
			labelMesh.characterSize = .045f;
		}else{
			labelMesh.characterSize = (float)((0.85f/(Math.Pow((double)(longest), 0.74)))/2);
		}
		labelMesh.font.material.color = Color.black;
		meshRenderer.renderer.material = labelMesh.font.material;
		label.transform.position = label.transform.parent.position;
		label.transform.Translate(new Vector3(-.375f, .15f, 0f), label.transform.parent);
	}
	
	
	
	
	
	
	
	//this is what happens when you press the left stylus button
	//It should spawn the datasheet with the info about the part clicked on.
	public void LeftButtonDown(){
	
	foreach(KeyValuePair<string, string> entry in InfoTree2D.partToInfo)
	{
//	print ("Dict: " + entry);
	}
	if( !(labelInfo.Equals("Please choose a part") ) ){
			labelInfo = "Please choose a part";
			iteration = 0;
			}

		else if(InfoTree2D.partToInfo.ContainsKey(textLabel.GetComponent<TextMesh>().text.Replace ("\n", "_")))
		{
//			print ("sdvf");
			callAgain = false;
			
			//foreach(KeyValuePair<string, string> mem in InfoTree.partToInfo)
				
			if(textLabel.GetComponent<TextMesh>().text.Substring(0,3).Equals ("BBa")){
//				print ("bba achieved");
				
				string theKey = textLabel.GetComponent<TextMesh>().text.Replace ("\n", "_");
				partInformation = InfoTree2D.partToInfo[theKey];
				
				//the following code could be used if a GUI is not optimal
				
				
				//GameObject partLabel = new GameObject("partLabel");
				//partLabel.transform.parent = this.transform;
				//partLabel.transform.localPosition = Vector3.zero;
				//partLabel.transform.Rotate(new Vector3(0f, 180f, 0f));
				
				
				
				//partLabel.transform.Translate(new Vector3(0f, 2f, 0f), Space.World);
				//var labelText = (TextMesh)partLabel.AddComponent ("TextMesh");
			
				//var meshRenderer = partLabel.AddComponent("MeshRenderer");	
				//var fontResource = Resources.Load ("Aller_Rg");
				//labelText.font = (Font)fontResource;
				
				//Data Sheet as a label created here - the info is stored as partInformation
				//labelText.text = partInformation;
				
				//labelText.characterSize = 0.07f;
				//meshRenderer.renderer.material = labelText.font.material;
				//print ("updating labelInfo");
				labelInfo = partInformation;
			}
			
			
		}
		else {
			if(!OnMouseDownCalled){
				theMousePushed ();
			}
			callAgain = true;
		}
		
	}
	
	
	

	
	
	//method pulled from the web to access children of objects
	static public GameObject getChildGameObject(GameObject fromGameObject, string withName) {
		//Author: Isaac Dart, June-13.
		Transform[] ts = fromGameObject.transform.GetComponentsInChildren<Transform>();
		foreach (Transform t in ts) if (t.gameObject.name == withName) return t.gameObject;
		return null;
	}
	
	
	
	
	
	
	void OnGUI(){
		GUI.Box (new Rect(Screen.width - 330, Screen.height - 380, 320, 360), "Part Information");
		GUI.Label(new Rect(Screen.width - 320, Screen.height - 360, 310, 320), labelInfo);
		//GUI.Label (new Rect(Screen.width - 290, Screen.height - 200, 250, 80), Card.labelInfo.Substring(Card.labelInfo.Length/2, Card.labelInfo.Length));
	
		}
	
	void OnMouseEnter()
	{
		if(!(textLabel == null))
		{
			textLabel.active = true;
			}
			hovered = true;
	}
	
	void OnMouseExit()
	{
			if(carouselOfCard.crawlerLevel == 1)
			{
			textLabel.active = false;
			}
			hovered = false;
	}
	
}