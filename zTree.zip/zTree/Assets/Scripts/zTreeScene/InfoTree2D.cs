using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class InfoTree2D : MonoBehaviour {
	public GameObject carousel;
	//list of all of the carousels in the infoTree
	public IList<IList<Carousel2D>> layers;
	
	//reads through the interwebs
	public GameObject crawler;
	
	//main camera
	public GameObject camera;
	
	//this gets the position of the last card that was clicked on...maybe not good as an instance variable? 
	public Vector3 clickedPosition;
	
	//list of all parts in that layer of the carousel... i think
	public static IList<string> dataInfo;
	
	//list of all of the parts clicked on
	public static IList<string> cache; 
	
	//Gets populated with each selected part: partToInfo<part, information>
	public static Dictionary<string,string> partToInfo;
	
	
	
	
	
	
	
	// Use this for initialization
	void Start () {
		partToInfo = new Dictionary<string, string>();
		
		//sets the camera to its starting position
		camera.transform.position = new Vector3(-2f, 0f, 0f);
	
		//initializes the cache
		cache = new List<string>(); 
		
		//initializes the clicked position
		clickedPosition = Vector3.zero;
		
		//initalizes the RegistryCrawler
		crawler = GameObject.Find ("RegistryCrawler");
		//Reads in the initial options from the web... in this case the first set of options in the RoSBP
		dataInfo = crawler.GetComponent<RegistryCrawler>().categories;
		
		//this creates the very first carousel layer and starts off the program
		carousel = new GameObject();
		carousel.AddComponent<Carousel2D>();
		
		//sets some of the variables for the first carousel that will be done automatically for every other carousel
		carousel.GetComponent<Carousel2D>().indexInLayerOfMomma = 0; //it doesn't have a parent carousel, so it is it's own parent carousel
		carousel.GetComponent<Carousel2D>().indexInLayers= 0; //this is its index in the list of lists, layers. Will always be zero because it's first
		carousel.GetComponent<Carousel2D>().crawlerLevel = 1; 
		//adds the first carousel to the list of carousels
		layers = new List<IList<Carousel2D>>();
		IList<Carousel2D> newCarouselList = new List<Carousel2D>();
		newCarouselList.Add(carousel.GetComponent<Carousel2D>());
		layers.Add(newCarouselList);
		
	}
	
	
	
	
	// Update is called once per frame
	void Update () {
		//maybe write this more efficiently in the future
		
		
		//uses the keyboard keys to move which carousel is selected up or down appropriately
		
		
		
		if(Input.GetKeyDown(KeyCode.UpArrow))
		{
			int indexSelected = getIndexOfSelected();
			int indexOfSelectedLayer = getIndexofSelectedInLayer();
			try{
				int indexOfAbove = layers[indexSelected][indexOfSelectedLayer].indexInLayerOfMomma;
				layers[indexSelected - 1][indexOfAbove].selected = true;
				layers[indexSelected][indexOfSelectedLayer].selected = false;
				
			}catch{
				
			}
		}
		
		if(Input.GetKeyDown(KeyCode.DownArrow))
		{
			int indexSelected = getIndexOfSelected();
			int indexOfSelectedLayer = getIndexofSelectedInLayer();
			try{
				layers[indexSelected + 1][0].selected = true;
				layers[indexSelected][indexOfSelectedLayer].selected = false;
			}catch{
				
			}
		}		
		
		//we need to make this so it does all of the ones below the selected layer... maybe do user testing to figure out
		//if delete should destroy the one you're on or all the ones below it.
		if(Input.GetKeyDown(KeyCode.Space)){
			//Calls destroy from the bottom carousel up to the selected carousel
			int indexSelected = getIndexOfSelected();
			int indexOfSelectedLayer = getIndexofSelectedInLayer();
			int index = getIndexOfSelected();
			for(int i = layers.Count-1; i>=index; i--){
				for(int j = layers[i].Count-1; j>=0; j--){
					destroyLayer(i,j);
				}
				//crawler.GetComponent<RegistryCrawler>().level = layers[getIndexOfSelected()][getIndexofSelectedInLayer()].crawlerLevel;
			} 
		}
		
		if(Input.GetKeyDown (KeyCode.Return)){
			int indexSelected = getIndexOfSelected();
			int indexOfSelectedLayer = getIndexofSelectedInLayer();
			if(layers[indexSelected].Count == 1){
			}else{
				if(indexOfSelectedLayer+1==layers[indexSelected].Count){
					layers[indexSelected][0].selected = true;
					layers[indexSelected][indexOfSelectedLayer].selected = false;
				}else{
					layers[indexSelected][indexOfSelectedLayer+1].selected = true;
					layers[indexSelected][indexOfSelectedLayer].selected = false;
				}
			}
		}
	}
	
	
	
	
	
	
	//this spawns the next carousel layer and adjusts the position and status of the old ones
	public Carousel2D nextCarouselLayer(int nextNumDataPoints){
	
		//this assumes that the selected carousel is the one you've clicked on
		//we can try to adjust this in the future so this will work on any card you click on, regardless of carousel
		
		//gets the location in layers of the selected carousel
		int j = getIndexOfSelected();
		int i = getIndexofSelectedInLayer();
		
		//gets the list of all the cards within the carousel
		IList<Card2D> carouselCards = layers[j][i].GetComponent<Carousel2D>().cards;
		

		//We need to figure out how the location of the carousel works here. Seems overly complicated and I'm not sure why it's working
		
		//creates the new carousel object
		GameObject newCarousel = new GameObject();
		newCarousel.AddComponent<Carousel2D>();
		
		//newCarousel.transform.position = clickedPosition;
		carousel = newCarousel;
		
		//Moves carousel to be under the card clicked... written in a strange way that works and won't work any other way
		//Vector3 centerPt = new Vector3();
		//centerPt = carousel.GetComponent<Carousel>().centerPoint;
		//carousel.GetComponent<Carousel>().transform.localPosition = centerPt;
		
		
		return carousel.GetComponent<Carousel2D>();

	}
	
	
	
	
	
	
	
	public void destroyLayer(int index, int indexInLayer){
		if(index>0){
			carousel = layers[index][indexInLayer].gameObject;
			int caroLev = layers[index-1][carousel.GetComponent<Carousel2D>().indexInLayerOfMomma].GetComponent<Carousel2D>().crawlerLevel;
			//adjusts the selected values to move up to the proper carousel
			layers[index-1][carousel.GetComponent<Carousel2D>().indexInLayerOfMomma].selected = true; 
			
			//makes every card in the above carousel not clicked anymore
			//this is bad because if there were two children carousels, then the card for the other one won't be clicked anymore
			//adjust so it's only the card that was clicked on for that carousel
			
			foreach(Card2D card in layers[index-1][carousel.GetComponent<Carousel2D>().indexInLayerOfMomma].cards){
				card.isClicked = false;
			}
			Destroy (layers[index][indexInLayer].gameObject);
			layers[index].RemoveAt(indexInLayer);
			if(layers[index].Count == 0){
				layers.RemoveAt(index);
				
				if(caroLev == 1){
					crawler.GetComponent<RegistryCrawler>().secCats = new List<string>();
					crawler.GetComponent<RegistryCrawler>().thirdCats = new List<string>();
					crawler.GetComponent<RegistryCrawler>().fourthCats = new List<string>();
				}else if (caroLev == 2){
					crawler.GetComponent<RegistryCrawler>().thirdCats = new List<string>();
					crawler.GetComponent<RegistryCrawler>().fourthCats = new List<string>();
				}else if (caroLev == 3){
					crawler.GetComponent<RegistryCrawler>().fourthCats = new List<string>();
				}
				
			}
			dataInfo = new List<string>();
			//dataInfo = layers[index-1][carousel.GetComponent<Carousel2D>().indexInLayerOfMomma].cardNames;
			//clearRegistryCrawler();
			
			
		}
	}
	
	
	
	
	
	//Searches the list of carousels for the one that is currently selected, and by selected we mean the one that spins
	public int getIndexOfSelected(){
		foreach(IList<Carousel2D> layer in layers){
			foreach(Carousel2D caro in layer){
				if(caro.selected){
					return layers.IndexOf(layer);
				}
			}
		}
		return -1;
	}
	
	
	
	
	
	//gets the second [x][x] value for layers
	public int getIndexofSelectedInLayer(){
		int i = getIndexOfSelected();
		foreach(Carousel2D caro in layers[i]){
			if(caro.selected){
				return layers[i].IndexOf(caro);
			}
		}
		return -1;
	}
	
	
	
	
	
	//resets all the data lists in Registry crawler so the carousels don't keep growing
	public void clearRegistryCrawler(){
		crawler.GetComponent<RegistryCrawler>().categories = new List<string>();
		crawler.GetComponent<RegistryCrawler>().secCats = new List<string>();
		crawler.GetComponent<RegistryCrawler>().thirdCats = new List<string>();
		crawler.GetComponent<RegistryCrawler>().fourthCats = new List<string>();
		crawler.GetComponent<RegistryCrawler>().smallerTree = false;
		crawler.GetComponent<RegistryCrawler>().done = false;
		crawler.GetComponent<RegistryCrawler>().topChoice = "";
		crawler.GetComponent<RegistryCrawler>().secChoice = "";
		crawler.GetComponent<RegistryCrawler>().thirdChoice = "";
		crawler.GetComponent<RegistryCrawler>().fourthChoice = "";
	}
}
