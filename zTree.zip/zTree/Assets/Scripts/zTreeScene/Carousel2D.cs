using UnityEngine;
using System.Collections;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class Carousel2D : MonoBehaviour {
	//Authors: Cassie Hoef (The Hero),  Daniel Worstell (The Sidekick), Yoav Segev (The 
	public static int numCardsToSpawn;
	
	//if selected, this carousel is the one that is able to spin and the user is currently looking at
	public bool selected;
	
	 //indicates which carousel is selected by color and is the centerpoint of the carousel. 
	//Also, all the spokes start at the anchor
	public GameObject anchor;
	
	//List of all the cards in the carousel
	public IList<Card2D> cards;
	
	//Indicates the centerpoint of the carousel
	public Vector3 centerPoint;
	
	//Radius of the carousel
	public float radius;
	
	//List of all of the labels on the cards
	public IList<GameObject> labels;
	
	//where carousel is in layers
	public int indexInLayers;
	public int indexInLayer;
	
	//which x in [index -1][x] for the carousel that is above this one
	public int indexInLayerOfMomma;
	
	public static IList<string> dataInfo;
	public IList<Carousel2D> caroPath;
	
	//the card that was clicked on to spawn this card
	public Card2D parentCard; 
	
	//lvl
	public int crawlerLevel;
	
	//zSpace pen
	public GameObject stylus;
	
	//Basically this saves you from typing "this.gameObject" in front of everything when you want to access the carousel
	//We have strong feelings about this method of creating objects...
	private GameObject carousel;
	
	public IList<string> cardNames; 
	
	
	
	
	// Use this for initialization
	void Start () {
	caroPath = new List<Carousel2D>();
		
		
		//gets the zSpace stylus
		stylus = GameObject.Find ("ZSStylus");
		
		//When a new carousel is made, it's automatically selected
		selected = true;
		
		cards = new List<Card2D>();
		carousel = gameObject;
		carousel.name = "Carousel2D";
		carousel.transform.parent = GameObject.Find("InfoTree2D").transform;
		carouselSpawn();
		IList<IList<Carousel2D>> allCaros = carousel.transform.parent.gameObject.GetComponent<InfoTree2D>().layers;
		RegistryCrawler crawler = GameObject.Find("RegistryCrawler").GetComponent<RegistryCrawler>();
		if(indexInLayers > 0){
		crawlerLevel = allCaros[indexInLayers -1][indexInLayerOfMomma].crawlerLevel +1; 
		}
		if(crawler.level == 1){
			crawler.secCats = new List<string>();
			crawler.thirdCats = new List<string>();
			crawler.fourthCats = new List<string>();
		}else if (crawler.level == 2){
			crawler.thirdCats = new List<string>();
			crawler.fourthCats = new List<string>();
		}else if (crawler.level == 3){
			crawler.fourthCats = new List<string>();
		}
		
//		print (crawlerLevel);
	}
	
	
	
	
	
	
	
	// Update is called once per frame
	void Update () {
		//renders the labels depending on their card's location in relation to the front of the carousel
	
		foreach(Card2D ca in cards){	
		try{
			if(ca.transform.position.z <= anchor.transform.position.z){
					ca.textLabel.transform.renderer.enabled = true;	
			}else{
					ca.textLabel.transform.renderer.enabled = false;
				
				}
			}
		catch{
		}
		}
		
		//this makes all of the spokes in the carousel move when you spin it
		for(int i = 0; i<cards.Count; i++){
			this.GetComponentsInChildren<LineRenderer>()[i].SetPosition(0, cards[i].transform.position);
			this.GetComponentsInChildren<LineRenderer>()[i].SetPosition(1, anchor.transform.position);
		}
		
		//changes the color of the anchor depending on if it's selected or not
		if(!selected){
			Color dark = new Color(77/255f, 118/255f, 127/255f, 255f);
			anchor.renderer.material.color = dark;
			//this.gameObject.transform.localScale = new Vector3(0.55f, 0.55f, 0.55f);
		} else {
			Color orange = new Color(255/255f, 141/255f, 46/255f, 255f);
			anchor.renderer.material.color = orange;
			//this.gameObject.transform.localScale = new Vector3(1f, 1f, 1f);
			
			//Adjusts the camera's position based on which carousel is selected
			float count = carousel.transform.parent.gameObject.GetComponent<InfoTree2D>().layers[indexInLayers].Count; 
			if(count>1){
			count = count*2;
			}
			float camX = carousel.transform.position.x;
			float camY = carousel.transform.position.y;
			float camZ = carousel.transform.position.z-radius- (7.5f-count);
			this.transform.parent.GetComponent<InfoTree2D>().camera.transform.position = new Vector3(camX,camY,camZ);	
		} 
		//this makes it so if you click on an anchor, that carousel becomes selected
		//make it so the anchors do not move when you click on them... that's the only problem with this
		
		 Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
		RaycastHit hit;
		
if (Physics.Raycast (ray, out hit, 100f)) {
		if(Input.GetMouseButtonDown (0) && hit.collider.gameObject == anchor.gameObject)
		{
			IList<IList<Carousel2D>> allCaros = carousel.transform.parent.gameObject.GetComponent<InfoTree2D>().layers;
			foreach(IList<Carousel2D> layer in allCaros){
				foreach(Carousel2D aCaro in layer)
				{
					if(aCaro.gameObject != carousel)
					{
						aCaro.selected = false;	
					}
				}
			}
			selected = true;	
		}
		}
	}
	
	
	
	
	
	
	//this spawns the carousel
	//dataPoints corresponds to the number of cards in the carousel
	public void carouselSpawn(){
		dataInfo = InfoTree2D.dataInfo;
		int dataPoints = dataInfo.Count; 
		cardNames = dataInfo; 
		
		//the radius depends on the number of cards in the carousel. 
		radius = dataPoints/3f;
		
		//Gets list of all carousels from InfoTree
		//This code should arguably be in InfoTree. We can consider moving it later.
		IList<IList<Carousel2D>> allCaros = carousel.transform.parent.gameObject.GetComponent<InfoTree2D>().layers;
		//when a new carousel is made, all others should be deselected and the new one should be selected
		foreach(IList<Carousel2D> layer in allCaros){
			foreach(Carousel2D aCaro in layer)
			{
				if(aCaro.gameObject != carousel)
				{
					aCaro.selected = false;	
				}
			}
		}
		
		//creates the anchor which is the centerpoint for the carousel and makes the anchor the child of a carousel
		anchor = GameObject.CreatePrimitive(PrimitiveType.Sphere);
		
		anchor.AddComponent<Rigidbody>();
		anchor.GetComponent<Rigidbody>().useGravity = false;
		anchor.GetComponent<Rigidbody>().mass = Mathf.Infinity;
		
		anchor.name = "anchor";
		anchor.transform.parent = carousel.transform;
		anchor.transform.localScale = new Vector3(.5f, .5f, .5f);
		anchor.transform.position = new Vector3(0f, 1.5f, 0f);
		
		//sets the center of the carousel (and the anchor) as the position of the card clicked in the carousel above
		centerPoint = new Vector3();
		centerPoint = carousel.transform.parent.gameObject.GetComponent<InfoTree2D>().clickedPosition;
		carousel.transform.position = centerPoint;
		
		//creates the number of new cards specified by dataPoints
		for (int i = 0; i<dataPoints; i++){
			GameObject dataCard = GameObject.CreatePrimitive(PrimitiveType.Cube);
			
			//sets parent and position of card
			dataCard.transform.parent = carousel.transform;
			dataCard.transform.localPosition = new Vector3(0f, 0f, radius);
			dataCard.transform.RotateAround(centerPoint, Vector3.up, (360f/dataPoints) *i);
			
			//adds component to card
			Card2D comp = dataCard.AddComponent<Card2D>();
			comp.dataOptions = i+1;
			
			//adds the card to the list of cards that the carousel has
			cards.Add(comp);
			
			//sets the spokes on the carousel. Sets the carousel as the line's parent.
			GameObject line = new GameObject();
			line.name = "Line";
			line.transform.parent = carousel.transform;
			LineRenderer lineRenderer= line.AddComponent<LineRenderer>();
			lineRenderer.material = new Material(Shader.Find("Particles/Additive"));
			Color bluish = new Color(54/255f, 179/255f, 133/255f, 255f);
			lineRenderer.SetColors(bluish, bluish);
			lineRenderer.SetWidth(0.04F, 0.04F);
			lineRenderer.SetVertexCount(2);
			
		}
		//adds the spinner script to the carousel so when it's selected it can move.
		carousel.AddComponent<Spinner2D>();
		//caroPath = carouselPath();
	}	
	
	
	/*public int getIndexOfCarousel(){
		IList<IList<Carousel>> allCaros = carousel.transform.parent.gameObject.GetComponent<InfoTree>().layers;
		foreach(IList<Carousel> layer in allCaros){
			foreach(Carousel caro in layer){
				if(caro == this.gameObject){
					return carousel.transform.parent.GetComponent<InfoTree>().layers.IndexOf(layer);
				}
			}
		}
		return -1;
	}*/
	
	public IList<Carousel2D> carouselPath(){
		IList<Carousel2D> caroPath = new List<Carousel2D>();
		//caroPath.Add(this);
		int i = this.indexInLayers;
		Carousel2D previousCarousel = this;
		do{
		caroPath.Add(previousCarousel);
		previousCarousel = previousCarousel.gameObject.transform.parent.gameObject.GetComponent<InfoTree2D>().layers[i][previousCarousel.indexInLayerOfMomma];
			
			//print (previousCarousel.gameObject.transform);
			//previousCarousel = previousCarousel.gameObject.transform.parent.gameObject.GetComponent<InfoTree>().layers[i-1][previousCarousel.indexInLayerOfMomma];
			i--; 
		}
		while(i >= 0);
		//caroPath.Add(carousel.transform.parent.gameObject.GetComponent<InfoTree>().layers[0][0]);
		//caroPath = (IList<Carousel>) caroPath.Reverse();
		caroPath.Reverse();
			//print(caro.indexInLayer);
			foreach(Carousel2D caro in caroPath)
			{
//			print(caro.cards[0]);
			}
		return caroPath;
	}
	
}
