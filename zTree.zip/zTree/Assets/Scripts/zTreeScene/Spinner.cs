using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Spinner : MonoBehaviour {
	//The carousel
	private GameObject carousel;
	
	//List of Carousels called layers
	private IList<IList<Carousel>> layers;
	
	//The index of the selected carousel
	private int indexOfSelected;
	
	public FileWriter fw; 
	
	// Use this for initialization
	void Start () {
		carousel = gameObject;
		fw = GameObject.Find("FileWriter").GetComponent<FileWriter>();
	}
	
	
	
	
	// Update is called once per frame
	void Update () {
		Spin();
		if(Input.GetKeyUp(KeyCode.RightArrow)){
			fw.logData.Add("User holds down right arrow to spin carousel"); 
		}else if(Input.GetKeyUp(KeyCode.LeftArrow)){
			fw.logData.Add("User holds down left arrow to spin carousel"); 
		}
	}
	
	
	
	
	
	//Spins the carousel when the arrow keys are clicked.
	void Spin()
	{
		indexOfSelected = carousel.transform.parent.GetComponent<InfoTree>().getIndexOfSelected();
		int indexOfSelectedInLayer = carousel.transform.parent.GetComponent<InfoTree>().getIndexofSelectedInLayer();
		if(Input.GetKey(KeyCode.RightArrow) && carousel.GetComponent<Carousel>().selected == true)
		{	
			
			getLayers ();
			foreach(IList<Carousel> layer in layers){
				foreach(Carousel caro in layer){
					if (layers[indexOfSelected][indexOfSelectedInLayer].transform.position.y > caro.transform.position.y){
						carousel.transform.RotateAround( (carousel.transform.position), Vector3.down, (5f/carousel.GetComponent<Carousel>().cards.Count));
						//if(Card.otherClicked(carousel.GetComponent<Carousel>())==true){
						//}else{
						Vector3 movingPosition = caro.parentCard.transform.position;
						movingPosition.y = movingPosition.y -2.5f;
						caro.transform.position = movingPosition;
						//clickedCardPosition(caro);
						//}
					}else {
						carousel.transform.RotateAround((carousel.transform.position), Vector3.down, (5f/carousel.GetComponent<Carousel>().cards.Count));
					}
				}
			}
		}
		if(Input.GetKey(KeyCode.LeftArrow) && carousel.GetComponent<Carousel>().selected == true)
		{
			
			getLayers ();
			foreach(IList<Carousel> layer in layers){
				foreach(Carousel caro in layer){
					if (layers[indexOfSelected][indexOfSelectedInLayer].transform.position.y > caro.transform.position.y){
						carousel.transform.RotateAround( (carousel.transform.position), Vector3.up, (5f/carousel.GetComponent<Carousel>().cards.Count));
						//caro.transform.position = clickedCardPosition(caro);
						//if(Card.otherClicked(carousel.GetComponent<Carousel>())==true){
						//}else{
						//caro.transform.position = caro.parentCard.transform.position;
						//clickedCardPosition(caro);
						Vector3 movingPosition = caro.parentCard.transform.position;
						movingPosition.y = movingPosition.y -2.5f;
						caro.transform.position = movingPosition;
						//}
					}	
					else {
						carousel.transform.RotateAround( (carousel.transform.position), Vector3.up, (5f/carousel.GetComponent<Carousel>().cards.Count));
					}
				}		
			}	
		}		
	}//Spin
	
	void getLayers(){
		layers = carousel.transform.parent.GetComponent<InfoTree>().layers;	
		
	}
	
	//Searches the list of carousels for the one that is currently selected, and by selected we mean the one that spins
	public int getIndexOfCard(Carousel caro){
		foreach(IList<Carousel> layer in layers){
			foreach(Carousel car in layer){
				if(car == caro){
					return layers.IndexOf(layer);
				}
			}
		}
		return -1;
	}
	
	
	
	
	public int getIndexInLayerOfCard(Carousel caro){
		foreach(IList<Carousel> layer in layers){
			foreach(Carousel car in layer){
				if(car == caro){
					return layers[layers.IndexOf(layer)].IndexOf(car);
				}
			}
		}
		return -1;
	}
	
	
	
	
	public Vector3 clickedCardPosition(Carousel caro){
		int index = getIndexOfCard(caro);
		print (index);
		//int indexInLayer = getIndexInLayerOfCard(caro);
		int indexInLayer = caro.indexInLayer;
		IList<Card> cards = layers[index-1][indexInLayer].GetComponent<Carousel>().cards;
		foreach(Card car in cards){
			if (car.isClicked){
				Vector3 position = car.transform.position;
				position.y = position.y - 2.5f;
				return position;
			}
		} return Vector3.zero;
	}
}
