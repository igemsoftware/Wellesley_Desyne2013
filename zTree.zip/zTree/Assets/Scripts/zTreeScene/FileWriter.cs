using UnityEngine;
using System; 
using System.Collections;
using System.IO;
using System.Globalization;
using System.Text;
using System.Collections.Generic;


public class FileWriter : MonoBehaviour {

	public IList<string> logData;
	public static string date; 
	//public static StreamWriter logWriter; 

	// Use this for initialization
	void Start () {
		logData = new List<string>();
		date = DateTime.Now.Month + "_" + DateTime.Now.Day + "_" + DateTime.Now.Year;
		
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	
	public void writeCache(){
		logData.Add("User wrote the cache to a text file");
		using (StreamWriter writer = new StreamWriter(SearchTheTree.name+ "_" +"cache" + date + ".txt")){
			foreach(string s in InfoTree.cache){
				writer.WriteLine(s);
			}	
		}
		
	}
	
	 void OnApplicationQuit(){
		using (StreamWriter writer = new StreamWriter(SearchTheTree.name + "_" + date + ".txt")){
			foreach(string s in logData){
				writer.WriteLine(s);
			}	
		}
		
	}
	
}
