using UnityEngine;
using System.Collections;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.IO;

public class RegistryCrawler : MonoBehaviour {
	public IList<String> categories = new List<String>();
	public IList<String> secCats = new List<String>();
	public IList<String> thirdCats = new List<String>();
	public IList<String> fourthCats = new List<String>();
	public int level;
	public Boolean done, siteDone, smallerTree;
	public string topChoice, secChoice, thirdChoice, fourthChoice;
	WWW topLevel, secondLevel, thirdLevel;
	
	
	
	// Use this for initialization
	void Awake () {
	done = false;
	level = 1;
	Update ();
	topChoice = "";
	secChoice = "";
	thirdChoice = "";
	fourthChoice = "";	
	}
	
	void Start()
	{
	//print (UrlIsValid("http://www.google.com"));
	}
	
	// Update is called once per frame
	 public void Update () {
		

		if(!done)
		{
			//general type: promoter, etc
			if(level == 1)
			{
				Card.onPartLevel = false;
				CrawlLevelOne ();
				//level = 1;
			}
			
			//subdivision if present (constitutive, etc)
			if(level == 2)
			{
				Card.onPartLevel = false;
				CrawlLevelTwo ();
				//level = 2;
			}
			
			//next subdivision (type of e.Coli, etc)
			if(level == 3)
			{
				Card.onPartLevel = false;
				CrawlLevelThree ();
				//level = 3;
			}
			
			if(Card.onPartLevel)
			{
			level = 5;
			}
			
			//individual part
			if(level == 4)
			{
				CrawlLevelFour ();
				Card.onPartLevel = true;
				//level = 4;
			}
			
			
			
			
			if(level > 4)
		{
				//print ("done");
				done = true;
			}
			
		}
	}
	
	//always happens first - populates most basic list of categories (promoters, terminators, etc)
	void CrawlLevelOne(){
	topLevel = new WWW("http://parts.igem.org/Catalog");
	while(!topLevel.isDone)
		{
			Console.WriteLine ("waiting");
		}
		siteDone = true;
		string topLevelCode = topLevel.text;
		string startPoint = "<td valign=\"top\" align=\"center\" width=\"50px\">";
		string endPoint = "</p>\n<table>";
		topLevelCode = topLevelCode.Substring(topLevelCode.IndexOf(startPoint), topLevelCode.IndexOf (endPoint) - topLevelCode.IndexOf (startPoint));
	
	
	
	
		//html parsing
		do {
			startPoint = "line-height: 500px; z-index: 3\"><a href=\"/";
			endPoint = "\" title=";
			topLevelCode = topLevelCode.Substring(topLevelCode.IndexOf(startPoint));
			
			string newCat = topLevelCode.Substring(startPoint.Length, topLevelCode.IndexOf (endPoint) - topLevelCode.IndexOf (startPoint) - startPoint.Length);
			categories.Add (newCat);
			newCat = newCat.Replace ("_", " ");
			//print (newCat);
			topLevelCode = topLevelCode.Substring (topLevelCode.IndexOf (endPoint) + endPoint.Length);
			
			
		}
		while(! (topLevelCode.IndexOf("line-height: 500px; z-index: 3\"><a href=\"/") == -1));
		
		done = true;
	}
	
	
	
	//parsing the next level of the registry
	void CrawlLevelTwo(){
		topChoice = topChoice.Replace("\n", "_");
		topChoice = topChoice.Replace (" ", "_");
		secondLevel = new WWW("http://parts.igem.org/" + topChoice);
		while(!secondLevel.isDone)
		{
			Console.WriteLine("Waiting");
		}
		siteDone = true;
		
		string sourceCode = secondLevel.text;
		if(sourceCode.Contains (topChoice + "/Catalog"))
		{
			secondLevel = new WWW(secondLevel.url + "/Catalog");
		}
		
		while(!secondLevel.isDone)
		{
			Console.WriteLine("Waiting");
		}
		siteDone = true;
		
		sourceCode = secondLevel.text;
		string endPoint = "\" title=";
		while (sourceCode.IndexOf (endPoint) != -1)
		{
			try{
				string startPoint = secondLevel.url.Substring (secondLevel.url.IndexOf (".org") + 4);
				endPoint = "\" title=";
				sourceCode = sourceCode.Substring(sourceCode.IndexOf(startPoint));
				string nextCat = sourceCode.Substring(startPoint.Length, sourceCode.IndexOf (endPoint) - sourceCode.IndexOf (startPoint) - startPoint.Length);
				sourceCode = sourceCode.Substring (sourceCode.IndexOf (endPoint) + endPoint.Length);
				
				nextCat = nextCat.Substring (1);
				nextCat = nextCat.Replace("_", " ");
				
				//specific cases, hardcoding may eventually be substituted, but html parsing is difficult to dynamically do
				if(!nextCat.Contains ("/") && !secCats.Contains (nextCat) && !nextCat.Equals("Negative") && !nextCat.Equals ("Miscellaneous"))
				{
					//print(nextCat);
					secCats.Add (nextCat);
				}
			}
			catch
			{
			}
			done = true;
			//checks to see if this level is empty, in which case the level skips ahead but the carousel index does not change
			if(secCats.Count == 0)
			{
				level++;
				CrawlLevelThree ();
			}
			
		}
	}
	
	//lowest level of abstraction except for parts themselves. Could skip ahead another level,
	// could come after a skipped level, could be both. All cases must be handled.
	void CrawlLevelThree()
		{
		//print ("got here");
		bool goToFour = false;
		bool check = false;
		secChoice = secChoice.Replace("\n", "_");
		secChoice = secChoice.Replace (" ", "_");
		if( secCats.Count == 0)
			{
			thirdLevel = new WWW(secondLevel.url);
			}
		
		
		else if(UrlIsValid (secondLevel.url + "/" + secChoice))
			thirdLevel = new WWW(secondLevel.url + "/" + secChoice);
		
		else
		{
		thirdLevel = new WWW(secondLevel.url);
		level++;
		}
		
	while(!thirdLevel.isDone)
		{
			Console.WriteLine ("waiting");
		}
		
		
		if(level == 3)
		{
		siteDone = true;
		string sourceCode = thirdLevel.text;
		
		string startPoint;
		string endPoint;
		
		
		if(topChoice.Equals ("Promoters"))
		{
		startPoint = "<li class=\"toclevel-1 tocsection-1\"><a href=";
		endPoint = "</td></tr></table><script>if (window.showTocToggle)";
		}
		
		else
		{
		startPoint = "<!-- start content -->";
		endPoint = "<h2> <span class=\"mw-headline\" id=\"References\">";
		}
		
		
		
		if(sourceCode.Contains(startPoint) && sourceCode.Contains(endPoint))
		sourceCode = sourceCode.Substring(sourceCode.IndexOf(startPoint), sourceCode.IndexOf (endPoint) - sourceCode.IndexOf (startPoint));
	
	
		if(topChoice.Equals ("Promoters"))
			{
				startPoint = "</span> <span class=\"toctext\">";
				endPoint = "</span></a></li>";
			}
			
			else {
				
			//look at this later, originally was out of the else statement
				startPoint = "\"mw-headline\" id=\"";
				endPoint = "\">";
			}
			
			while(! (sourceCode.IndexOf(startPoint) == -1) && sourceCode.IndexOf(endPoint) != -1) {
				sourceCode = sourceCode.Substring(sourceCode.IndexOf(startPoint));
				
				string newCat = sourceCode.Substring(startPoint.Length, sourceCode.IndexOf (endPoint) - sourceCode.IndexOf (startPoint) - startPoint.Length);
				
				
				newCat = newCat.Replace("&", "");
				newCat = newCat.Replace ("<sup>", "");
				newCat = newCat.Replace ("</sup>", "");
				newCat = newCat.Replace (";", " ");
				
				if(!newCat.Contains ("<"))
				{
					
					thirdCats.Add (newCat);
					newCat = newCat.Replace ("_", " ");
					//print (newCat);
				}
				sourceCode = sourceCode.Substring (sourceCode.IndexOf (endPoint) + endPoint.Length);
				
			}
			
			//skip ahead conditions
			done = true;
			//thirdLevel = null;
			if(thirdCats.Count == 0)
			{
				level++;
				CrawlLevelFour ();
			}
		}
		//the case where there is a skipped level and this level is skipped messes with level pretty badly
		if(secCats.Count == 0)
		{
			smallerTree = true;
		}
	}
	
	//the part level ALWAYS - calls this once, then outside code changes the level to 5 so as to avoid calling it again
	void CrawlLevelFour()
	{
		if(thirdCats.Count == 0)
		{
			thirdChoice = secChoice;
		}
	
		string endPoint;
		string sourceCode = thirdLevel.text;
		string lookFor;
		if(thirdChoice.Contains ("sigma") && thirdChoice.Contains("promoter"))
		{
			lookFor = thirdChoice.Substring(thirdChoice.IndexOf ("sigma"), thirdChoice.IndexOf ("promoter") - 1 - thirdChoice.IndexOf ("sigma"));
			lookFor = lookFor.Replace (" ", "");
			lookFor = lookFor.ToLower();
			endPoint = "><TD class='c_6'></TD></TABLE>";
		}
		
		
		
		
		else {
			
		}
		
		thirdChoice = thirdChoice.Replace("\n", "_");
		thirdChoice = thirdChoice.Replace (" ", "_");
		lookFor = "\"mw-headline\" id=\"" + thirdChoice;
		
		endPoint = "</TABLE>";
		
		
		string startPoint = lookFor;
		
		
		if(sourceCode.Contains(startPoint))
		{
			sourceCode = sourceCode.Substring(sourceCode.IndexOf (startPoint));
		}
		if(sourceCode.Contains(startPoint) && sourceCode.Contains(endPoint))
			sourceCode = sourceCode.Substring(sourceCode.IndexOf(startPoint), sourceCode.IndexOf (endPoint) - sourceCode.IndexOf (startPoint));
		
		
		startPoint = "href='http://parts.igem.org/wiki/index.php?title=Part:";
		endPoint = "'>";
		
		
		//startPoint = lookFor;
		while(! (sourceCode.IndexOf(startPoint) == -1) && sourceCode.IndexOf(endPoint) != -1) {
			sourceCode = sourceCode.Substring(sourceCode.IndexOf(startPoint));
			
			string newCat = sourceCode.Substring(startPoint.Length, sourceCode.IndexOf (endPoint) - sourceCode.IndexOf (startPoint) - startPoint.Length);
			fourthCats.Add (newCat);
			//print (newCat);
			sourceCode = sourceCode.Substring (sourceCode.IndexOf (endPoint) + endPoint.Length);
			
		}
		
		done = true;
		//Card.onPartLevel = true;;
	}
	
	// a way of checking whether to skip parts of the above methods.
	//if it is successful, it downloads the site, so this is slow.
	public static bool UrlIsValid(string url)
	{
		//return true;
		
		
		bool br = false;
		WWW test = new WWW(url);
		while(!test.isDone)
		{
			Console.WriteLine("waiting");
		}
		
		try{
			Console.Write(test.bytes[1]);
			//print ("was site");
			br = true;
		}
		catch{
			//print("not site");
			br = false;
		}
		br = true;
		
		try{
			if(test.bytes.Length > 0){
				br = true;
			}else{
				br = false;
			}
		}
		catch{
			br = false;
		}
		return br;
		
		
}

	}