using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class SquareSpawner : MonoBehaviour {
	int layers = 1; 
	// Use this for initialization
	void Start () {
		treeTopSpawner(30);
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	
	void treeTopSpawner(int dataPoints){
		IList<GameObject> cards = new List<GameObject>();
		for (int i = 0; i<dataPoints; i++){
			GameObject dataCard = GameObject.CreatePrimitive(PrimitiveType.Cube);
			
			//text objects
			GameObject textLabel = new GameObject("CardLabel");
			textLabel.transform.parent = dataCard.transform;
			var label = (TextMesh)textLabel.AddComponent("TextMesh");
			var meshRenderer = textLabel.AddComponent("MeshRenderer");
			var fontResource = Resources.Load ("Aller_Rg");
			label.font = (Font)fontResource;
			label.text = "gkffcg";
			label.font.material.color = Color.black;
			label.characterSize = 1.2f/label.text.Length;
			meshRenderer.renderer.material = label.font.material;
			textLabel.transform.Translate(new Vector3(-.47f, .2f, 0f), textLabel.transform.parent); 
			
			//card locations
			dataCard.transform.localScale = new Vector3((2*Mathf.PI*(1/3f))/(1.1f), 1f, .05f);
			dataCard.name = "card";
			cards.Add(dataCard);
			dataCard.transform.RotateAround(new Vector3(0f, 0f, dataPoints/3f), Vector3.up, (360f/dataPoints) *i);
			
		}
	}
		
}
