using UnityEngine;
using System.Collections;

public class MainMenu : MonoBehaviour {
	public GameObject option; 
	// Use this for initialization
	void Start () {
		option = GameObject.CreatePrimitive(PrimitiveType.Cube);
		option.AddComponent<MenuOptions>();
		
		
	}
	
	// Update is called once per frame
	void Update () {

	}
	
	
	
	
}
